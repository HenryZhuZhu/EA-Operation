import { reactive } from 'vue'
import type { EAMetric } from '@/data/eaOverview'

interface MetricState {
  query: string; platform: string; generation: string; filtersOpen: boolean
  selected: string | null; segment: string | null; expanded: string | null; view: string; limit: number
}
const initial = (view: string): MetricState => ({
  query: '', platform: 'all', generation: 'all', filtersOpen: false,
  selected: null, segment: null, expanded: null, view, limit: 40,
})
export const eaMetricState = reactive<Record<EAMetric, MetricState>>({
  closure: initial('cases'), score: initial('cases'), human: initial('tasks'),
})
