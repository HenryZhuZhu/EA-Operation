import { reactive } from 'vue'
import type { PeriodState } from '@/types'

/** 各页面独立的时间维度状态（天/周/月/自定义） */
export const periodState = reactive<Record<'overview' | 'caseScore' | 'behavior' | 'usage' | 'productTraffic', PeriodState>>({
  overview: { period: '月', from: null, to: null },
  caseScore: { period: '月', from: null, to: null },
  behavior: { period: '月', from: null, to: null },
  usage: { period: '月', from: null, to: null },
  productTraffic: { period: '月', from: null, to: null },
})
