import { createRouter, createWebHashHistory } from 'vue-router'
import { findProduct, findSubproduct } from '@/data/products'

const routes = [
  { path: '/', redirect: '/overview' },
  { path: '/overview', name: 'overview', component: () => import('@/pages/OverviewPage.vue') },
  { path: '/overview/closure', name: 'ea-closure', meta: { nav: 'overview' }, component: () => import('@/pages/EAMetricPage.vue') },
  { path: '/overview/score', name: 'ea-score', meta: { nav: 'overview' }, component: () => import('@/pages/EAMetricPage.vue') },
  { path: '/overview/human', name: 'ea-human', meta: { nav: 'overview' }, component: () => import('@/pages/EAMetricPage.vue') },
  { path: '/overview/activity', name: 'ea-activity', meta: { nav: 'overview' }, component: () => import('@/pages/EAActivityPage.vue') },
  { path: '/overview/:metric(closure|score|human)/task/:taskId', name: 'ea-task-sessions', meta: { nav: 'overview' }, component: () => import('@/pages/EATaskSessionsPage.vue') },
  { path: '/overview/:pathMatch(.*)*', redirect: '/overview' },
  {
    path: '/product/:productId/:subproductId?',
    name: 'product-overview',
    component: () => import('@/pages/ProductOverviewPage.vue'),
  },
  { path: '/product/:productId/:subproductId?/activity', name: 'product-activity', component: () => import('@/pages/ProductActivityPage.vue') },
  { path: '/product/:productId/:subproductId?/pageviews', name: 'product-pageviews', component: () => import('@/pages/ProductPageviewsPage.vue') },
  { path: '/case-score', name: 'case-score', component: () => import('@/pages/CaseScorePage.vue') },
  { path: '/case-score/:id/report', name: 'case-score-report', meta: { nav: 'case-score' }, component: () => import('@/pages/CaseScoreReportPage.vue') },
  { path: '/behavior', name: 'behavior', component: () => import('@/pages/BehaviorPage.vue') },
  { path: '/usage', name: 'usage', component: () => import('@/pages/UsagePage.vue') },
  { path: '/usage/user/:name', name: 'user', meta: { nav: 'usage' }, component: () => import('@/pages/UserDetailPage.vue') },
  { path: '/risk', name: 'risk', component: () => import('@/pages/RiskPage.vue') },
  { path: '/risk/:index', name: 'risk-detail', meta: { nav: 'risk' }, component: () => import('@/pages/RiskDetailPage.vue') },
  { path: '/value', name: 'value', component: () => import('@/pages/ValuePage.vue') },
  { path: '/growth', name: 'growth', component: () => import('@/pages/GrowthPage.vue') },
]

export const router = createRouter({
  history: createWebHashHistory(),
  routes,
  scrollBehavior() { return { top: 0 } },
})

router.beforeEach((to) => {
  if (!['product-overview', 'product-activity', 'product-pageviews'].includes(String(to.name))) return
  const product = findProduct(to.params.productId)
  if (!product || product.id === 'ea') return '/overview'
  if (to.params.subproductId && !findSubproduct(product, to.params.subproductId)) {
    return `/product/${product.id}`
  }
})
