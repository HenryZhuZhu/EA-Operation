<script setup lang="ts">
import { computed, nextTick, onMounted, onUnmounted, ref, watch } from 'vue'
import { RouterLink, useRoute } from 'vue-router'
import { findProduct, findSubproduct, products, type ProductId } from '@/data/products'

const route = useRoute()
const root = ref<HTMLElement | null>(null)
const trigger = ref<HTMLButtonElement | null>(null)
const open = ref(false)
const expandedId = ref<ProductId | null>(null)
let hoverTimer: ReturnType<typeof setTimeout> | undefined
const current = computed(() => findProduct(route.params.productId) ?? products[0])
const child = computed(() => findSubproduct(current.value, route.params.subproductId))
const label = computed(() => child.value ? `${current.value.name} / ${child.value.name}` : current.value.name)
const expanded = computed(() => findProduct(expandedId.value))
const productLink = (id: ProductId) => id === 'ea' ? '/overview' : `/product/${id}`

function close(restoreFocus = false) {
  cancelHover()
  open.value = false
  expandedId.value = null
  if (restoreFocus) trigger.value?.focus()
}

async function show(focusRoot = false) {
  open.value = true
  expandedId.value = current.value.subproducts.length ? current.value.id : null
  if (focusRoot) {
    await nextTick()
    root.value?.querySelector<HTMLElement>('.product-picker-roots .selected')?.focus()
  }
}

async function expand(id: ProductId, focusChild = false) {
  cancelHover()
  if (expandedId.value !== id) collapseBranch()
  expandedId.value = id
  if (focusChild) {
    await nextTick()
    const children = root.value?.querySelector('.product-picker-children')
    const target = children?.querySelector<HTMLElement>('a[aria-current="page"]') ?? children?.querySelector<HTMLElement>('a')
    target?.focus()
  }
}

function cancelHover() {
  clearTimeout(hoverTimer)
  hoverTimer = undefined
}

function hoverProduct(id: ProductId | null) {
  cancelHover()
  // 避免斜向移入子菜单时误触途经的其他产品。
  hoverTimer = setTimeout(() => {
    if (id) expand(id)
    else collapseBranch()
  }, 160)
}

function focusParent() {
  root.value?.querySelector<HTMLElement>(`.product-branch[data-product-id="${expandedId.value}"]`)?.focus()
  expandedId.value = null
}

function collapseBranch() {
  const children = root.value?.querySelector('.product-picker-children')
  if (children?.contains(document.activeElement)) trigger.value?.focus()
  expandedId.value = null
}

function moveFocus(event: KeyboardEvent) {
  if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key) || !(event.target instanceof HTMLElement)) return
  const column = event.target.closest('nav')
  if (!column) return
  const items = Array.from(column.querySelectorAll<HTMLElement>('a, button'))
  const index = items.indexOf(event.target)
  if (index < 0) return
  event.preventDefault()
  const next = event.key === 'Home' ? 0 : event.key === 'End' ? items.length - 1
    : (index + (event.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length
  items[next].focus()
}

function onOutside(event: PointerEvent) {
  if (event.target instanceof Node && !root.value?.contains(event.target)) close()
}

function onFocusOut(event: FocusEvent) {
  if (!(event.relatedTarget instanceof Node) || !root.value?.contains(event.relatedTarget)) close()
}

watch(() => route.fullPath, () => close())
onMounted(() => document.addEventListener('pointerdown', onOutside))
onUnmounted(() => {
  cancelHover()
  document.removeEventListener('pointerdown', onOutside)
})
</script>

<template>
  <div ref="root" class="product-switcher" @focusout="onFocusOut" @keydown.esc.stop.prevent="close(true)">
    <button
      ref="trigger"
      type="button"
      class="product-trigger"
      aria-label="切换产品"
      aria-controls="product-picker"
      :aria-expanded="open"
      :title="label"
      @click="open ? close() : show()"
      @keydown.down.prevent="show(true)"
    >
      <span>{{ label }}</span>
      <svg class="product-picker-icon product-chevron" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <path d="m3 4.5 3 3 3-3" />
      </svg>
    </button>
    <div v-if="open" id="product-picker" class="product-picker" @keydown="moveFocus">
      <nav class="product-picker-roots" aria-label="产品与平台">
        <template v-for="product in products" :key="product.id">
          <button
            v-if="product.subproducts.length"
            type="button"
            class="product-option product-branch"
            :data-product-id="product.id"
            :class="{ selected: current.id === product.id, expanded: expandedId === product.id }"
            :aria-expanded="expandedId === product.id"
            aria-controls="product-picker-children"
            @pointerenter="hoverProduct(product.id)"
            @focus="expand(product.id)"
            @click="expand(product.id, true)"
            @keydown.right.prevent="expand(product.id, true)"
          ><span>{{ product.name }}</span>
            <svg class="product-picker-icon product-branch-hint" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
              <path d="m4.5 3 3 3-3 3" />
            </svg>
          </button>
          <RouterLink
            v-else
            class="product-option"
            :class="{ selected: current.id === product.id }"
            :to="productLink(product.id)"
            :aria-current="current.id === product.id ? 'page' : undefined"
            @pointerenter="hoverProduct(null)"
            @focus="expandedId = null"
            @click="close(true)"
          ><span>{{ product.name }}</span>
            <svg v-if="current.id === product.id" class="product-picker-icon" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
              <path d="m2.5 6 2.5 2.5 4.5-5" />
            </svg>
          </RouterLink>
        </template>
      </nav>
      <nav
        v-if="expanded"
        id="product-picker-children"
        class="product-picker-children"
        :aria-label="expanded.name + ' 统计范围'"
        @pointerenter="cancelHover"
        @keydown.left.stop.prevent="focusParent"
      >
        <RouterLink
          class="product-option"
          :to="productLink(expanded.id)"
          :aria-current="current.id === expanded.id && !child ? 'page' : undefined"
          @click="close(true)"
        ><span>平台整体</span>
          <svg v-if="current.id === expanded.id && !child" class="product-picker-icon" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="m2.5 6 2.5 2.5 4.5-5" />
          </svg>
        </RouterLink>
        <RouterLink
          v-for="subproduct in expanded.subproducts"
          :key="subproduct.id"
          class="product-option"
          :to="productLink(expanded.id) + '/' + subproduct.id"
          :aria-current="current.id === expanded.id && child?.id === subproduct.id ? 'page' : undefined"
          @click="close(true)"
        ><span>{{ subproduct.name }}</span>
          <svg v-if="current.id === expanded.id && child?.id === subproduct.id" class="product-picker-icon" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="m2.5 6 2.5 2.5 4.5-5" />
          </svg>
        </RouterLink>
      </nav>
    </div>
  </div>
</template>
