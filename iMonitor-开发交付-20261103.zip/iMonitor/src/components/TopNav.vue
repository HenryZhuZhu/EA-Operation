<script setup lang="ts">
import { RouterLink, useRoute } from 'vue-router'
import { ref, computed, onMounted, onUnmounted, watchEffect } from 'vue'
import { lastUpdated, refreshing, refresh } from '@/data/umami'
import { findProduct, findSubproduct } from '@/data/products'
import ProductSwitcher from '@/components/ProductSwitcher.vue'

const route = useRoute()
const selectedProduct = computed(() => findProduct(route.params.productId)?.id ?? 'ea')
const isEA = computed(() => selectedProduct.value === 'ea')
const productName = computed(() => findProduct(selectedProduct.value)!.name)
const subproductName = computed(() => {
  const product = findProduct(selectedProduct.value)!
  return findSubproduct(product, route.params.subproductId)?.name
})
watchEffect(() => { document.title = `${subproductName.value ? subproductName.value + ' · ' : ''}${productName.value} · iMonitor` })
const nav = [
  { key: 'overview', label: '运营总览' },
  { key: 'case-score', label: 'Case评分' },
  { key: 'behavior', label: '核心行为' },
  { key: 'usage', label: '使用分析' },
  { key: 'risk', label: '风险预警' },
  { key: 'value', label: '价值与收益' },
  { key: 'growth', label: '增长复盘' },
]
// 子页高亮归属父页
const active = (key: string) => (route.meta.nav ?? route.name) === key

// 最后数据更新时间（HH:MM:SS）
const pad = (n: number) => String(n).padStart(2, '0')
const updatedText = computed(() => {
  const d = new Date(lastUpdated.value)
  return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`
})

const menuOpen = ref(false)
const loggedOut = ref(false)
const onDocClick = () => (menuOpen.value = false)
onMounted(() => document.addEventListener('click', onDocClick))
onUnmounted(() => document.removeEventListener('click', onDocClick))
</script>

<template>
  <header class="topbar">
    <div class="bar-inner">
      <div class="brand-top"><div class="logo">iM</div><b>iMonitor</b></div>
      <ProductSwitcher />
      <nav v-if="isEA" class="topnav" aria-label="EA 运营导航">
        <RouterLink v-for="n in nav" :key="n.key" v-slot="{ navigate }" :to="'/' + n.key" custom>
          <button :class="{ active: active(n.key) }" @click="navigate">{{ n.label }}</button>
        </RouterLink>
      </nav>
      <nav v-else class="topnav" aria-label="产品运营导航">
        <RouterLink v-slot="{ navigate }" :to="`/product/${selectedProduct}${route.params.subproductId ? '/' + route.params.subproductId : ''}`" custom>
          <button class="active" :aria-current="route.name === 'product-overview' ? 'page' : undefined" @click="navigate">运营总览</button>
        </RouterLink>
      </nav>
      <div v-if="isEA && (route.meta.nav ?? route.name) !== 'overview'" class="data-fresh" @click.stop>
        <span class="upd">更新于 {{ updatedText }}</span>
        <button
          class="refresh-btn"
          :class="{ spinning: refreshing }"
          :disabled="refreshing"
          :title="refreshing ? '刷新中…' : '刷新数据'"
          @click="refresh"
        >
          <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 12a9 9 0 1 1-2.64-6.36" />
            <polyline points="21 3 21 8 16 8" />
          </svg>
        </button>
      </div>
      <div class="user-area" @click.stop>
        <button class="uav-btn" title="账户" @click="menuOpen = !menuOpen"><span class="uav">KS</span><i class="ustatus"></i></button>
        <div class="user-menu" :class="{ show: menuOpen }">
          <div class="um-head"><b>Kat Shen</b><span>产品运营 · 已登录</span></div>
          <button @click="loggedOut = true; menuOpen = false">退出登录</button>
        </div>
      </div>
    </div>
  </header>

  <div class="login-mask" :class="{ show: loggedOut }">
    <div class="login-card">
      <div class="login-logo">iM</div>
      <h2>iMonitor</h2>
      <p>你已退出登录</p>
      <button class="btn primary" @click="loggedOut = false">重新登录</button>
    </div>
  </div>
</template>
