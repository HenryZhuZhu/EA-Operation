<script setup lang="ts">
import { computed } from 'vue'
import { lastUpdated, refreshing, refresh } from '@/data/umami'

const updated = computed(() => new Date(lastUpdated.value).toLocaleString('sv-SE'))
</script>

<template>
  <div class="overview-freshness">
    <span>数据更新于</span><b>{{ updated }}</b>
    <button class="overview-refresh" :class="{ spinning: refreshing }" type="button" aria-label="刷新数据" :disabled="refreshing" @click="refresh">↻</button>
  </div>
</template>
