<script setup lang="ts">
import { computed } from 'vue'

interface DonutSegment { id: string; label: string; color: string; value: number; detail?: string }
const props = defineProps<{ segments: DonutSegment[]; selected: string | null; label: string; value: string; caption: string }>()
const emit = defineEmits<{ select: [id: string] }>()
const arcs = computed(() => {
  const total = props.segments.reduce((sum, segment) => sum + segment.value, 0)
  let angle = 0
  const point = (radius: number, degrees: number) => {
    const radians = (degrees - 90) * Math.PI / 180
    return `${180 + radius * Math.cos(radians)} ${180 + radius * Math.sin(radians)}`
  }
  return props.segments.filter(segment => segment.value > 0).map(segment => {
    const sweep = segment.value / total * 360, gap = Math.min(0.7, sweep / 4)
    const start = angle + gap, end = angle + sweep - gap, large = end - start > 180 ? 1 : 0
    angle += sweep
    return { ...segment, share: segment.value / total * 100, path: `M ${point(142, end)} A 142 142 0 ${large} 0 ${point(142, start)} L ${point(82, start)} A 82 82 0 ${large} 1 ${point(82, end)} Z` }
  })
})
</script>

<template>
  <div class="ea-donut-chart">
    <div class="ea-donut-wrap">
      <svg viewBox="0 0 360 360" :aria-label="label">
        <path v-for="segment in arcs" :key="segment.id" :d="segment.path" :fill="segment.color" tabindex="0" role="button"
          :aria-label="`${segment.label} ${segment.share.toFixed(1)}%`" :aria-pressed="selected === segment.id"
          :class="{ dimmed: selected && selected !== segment.id, selected: selected === segment.id }"
          @click="emit('select', segment.id)" @keydown.enter="emit('select', segment.id)" @keydown.space.prevent="emit('select', segment.id)">
          <title>{{ segment.label }} {{ segment.share.toFixed(1) }}%{{ segment.detail ? '\n' + segment.detail : '' }}</title>
        </path>
      </svg>
      <div class="ea-donut-center"><span>{{ label }}</span><b>{{ value }}</b><small>{{ caption }}</small></div>
    </div>
    <div class="ea-donut-legend">
      <button v-for="segment in arcs" :key="segment.id" type="button" :aria-pressed="selected === segment.id" @click="emit('select', segment.id)">
        <i :style="{ background: segment.color }"></i>{{ segment.label }}<b>{{ segment.share.toFixed(1) }}%</b>
      </button>
    </div>
  </div>
</template>
