<script setup lang="ts">
import { computed, nextTick, onMounted, onUnmounted, ref } from 'vue'

const props = defineProps<{ modelValue: string }>()
const emit = defineEmits<{ (e: 'update:modelValue', value: string): void }>()
const open = ref(false)
const trigger = ref<HTMLButtonElement | null>(null)
const menu = ref<HTMLDivElement | null>(null)
const position = ref({ left: '0px', top: '0px' })
const options = [{ value: 'all', label: '全部状态' }, { value: 'inactive', label: '未使用' }]
const label = computed(() => options.find(option => option.value === props.modelValue)!.label)
function close(restoreFocus = false) {
  open.value = false
  if (restoreFocus) trigger.value?.focus()
}
function reposition() {
  if (!open.value || !trigger.value || !menu.value) return
  const anchor = trigger.value.getBoundingClientRect(), bounds = menu.value.getBoundingClientRect()
  if (anchor.bottom <= 0 || anchor.top >= window.innerHeight) { close(); return }
  const top = anchor.bottom + 6 + bounds.height > window.innerHeight - 8 ? anchor.top - bounds.height - 6 : anchor.bottom + 6
  position.value = {
    left: `${Math.max(8, Math.min(anchor.left, window.innerWidth - bounds.width - 8))}px`,
    top: `${Math.max(8, top)}px`,
  }
}
async function show(focusOption = false) {
  open.value = true
  await nextTick()
  reposition()
  if (focusOption) menu.value?.querySelector<HTMLButtonElement>('[aria-checked="true"]')?.focus()
}
function select(value: string) { emit('update:modelValue', value); close(true) }
function moveFocus(event: KeyboardEvent) {
  if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key) || !(event.target instanceof HTMLButtonElement)) return
  const buttons = Array.from(menu.value?.querySelectorAll<HTMLButtonElement>('button') ?? [])
  const current = buttons.indexOf(event.target)
  event.preventDefault()
  const index = event.key === 'Home' ? 0 : event.key === 'End' ? buttons.length - 1
    : (current + (event.key === 'ArrowDown' ? 1 : -1) + buttons.length) % buttons.length
  buttons[index]?.focus()
}
function dismiss(event: Event) {
  if (event.target instanceof Node && !trigger.value?.contains(event.target) && !menu.value?.contains(event.target)) close()
}
onMounted(() => {
  document.addEventListener('pointerdown', dismiss)
  document.addEventListener('focusin', dismiss)
  document.addEventListener('scroll', reposition, true)
  window.addEventListener('resize', reposition)
})
onUnmounted(() => {
  document.removeEventListener('pointerdown', dismiss)
  document.removeEventListener('focusin', dismiss)
  document.removeEventListener('scroll', reposition, true)
  window.removeEventListener('resize', reposition)
})
</script>

<template>
  <div class="ea-status-filter">
    <button ref="trigger" type="button" class="ea-status-trigger" aria-label="成员状态筛选" aria-haspopup="menu"
      aria-controls="member-status-menu" :aria-expanded="open"
      @click="open ? close() : show()" @keydown.down.prevent="show(true)" @keydown.up.prevent="show(true)" @keydown.esc.stop.prevent="close(true)">
      <span>{{ label }}</span><span aria-hidden="true">⌄</span>
    </button>
    <Teleport to="body">
      <div v-if="open" id="member-status-menu" ref="menu" class="ea-status-menu" role="menu" aria-label="成员状态筛选"
        :style="position" @keydown="moveFocus" @keydown.esc.stop.prevent="close(true)">
        <button v-for="option in options" :key="option.value" type="button" role="menuitemradio"
          :aria-checked="modelValue === option.value" @click="select(option.value)">
          <span>{{ option.label }}</span><span v-if="modelValue === option.value" aria-hidden="true">✓</span>
        </button>
      </div>
    </Teleport>
  </div>
</template>
