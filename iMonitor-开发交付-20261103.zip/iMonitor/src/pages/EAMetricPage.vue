<script setup lang="ts">
import { computed, toRefs, watch } from 'vue'
import { RouterLink, useRoute } from 'vue-router'
import PeriodControl from '@/components/PeriodControl.vue'
import DataFreshness from '@/components/DataFreshness.vue'
import MetricDonut from '@/components/MetricDonut.vue'
import Sparkline from '@/components/Sparkline.vue'
import { periodState } from '@/stores/period'
import { eaMetricState } from '@/stores/eaOverview'
import { labelFor, sparkDates } from '@/data/compute'
import { liveTick } from '@/data/umami'
import { daysText, eaMetricProducts, eaProductDefinitions, hoursText, metricTrend, metricValue, scoreBands, scorePeople, teamColors } from '@/data/eaOverview'
import type { EACase, EAMetric, EAProductMetric, EATask } from '@/data/eaOverview'

const route = useRoute()
const kind = computed((): EAMetric => route.name === 'ea-closure' ? 'closure' : route.name === 'ea-score' ? 'score' : 'human')
const title = computed(() => ({ closure: '各产品平均结案时间', score: '各产品 Case 平均分', human: '各产品人机比' }[kind.value]))
const st = periodState.overview
const { query, platform, generation, filtersOpen, selected, segment, expanded, view, limit } = toRefs(eaMetricState[kind.value])
const all = computed(() => (liveTick.value, eaMetricProducts(st)))
const platforms = [...new Set(eaProductDefinitions.map(item => item.platform))]
const generations = [...new Set(eaProductDefinitions.map(item => item.generation))]
const rows = computed(() => all.value.filter(row => row.product.toLowerCase().includes(query.value.trim().toLowerCase())
  && (platform.value === 'all' || row.platform === platform.value) && (generation.value === 'all' || row.generation === generation.value))
  .sort((a, b) => metricValue(kind.value, b) - metricValue(kind.value, a)))
watch(rows, rows => {
  if (!rows.some(row => row.product === selected.value)) selected.value = rows[0]?.product ?? null
}, { immediate: true })
watch([selected, segment, view], () => { expanded.value = null; limit.value = 40 })
watch(selected, () => {
  segment.value = null
  if (kind.value === 'closure') view.value = 'cases'
})
const product = computed(() => rows.value.find(row => row.product === selected.value))
const trendLabels = computed(() => {
  if (st.period !== 'custom') return sparkDates(st, 8)
  const start = +new Date(st.from!), end = +new Date(st.to!)
  return Array.from({ length: 8 }, (_, i) => new Date(start + (end - start) * i / 7).toISOString().slice(5, 10))
})
const valueText = (row: EAProductMetric) => kind.value === 'closure' ? hoursText(row.hours) : `${metricValue(kind.value, row)}${kind.value === 'score' ? '分' : '%'}`
function deltaText(row: EAProductMetric) {
  const delta = metricTrend(kind.value, row, st).delta
  return `${delta > 0 ? '▲' : delta < 0 ? '▼' : '—'} ${Math.abs(delta)}${kind.value === 'closure' ? 'h' : kind.value === 'score' ? '分' : '百分点'}`
}
function deltaClass(row: EAProductMetric) {
  const delta = metricTrend(kind.value, row, st).delta
  return !delta ? 'flat' : (kind.value === 'closure' ? delta < 0 : delta > 0) ? 'up' : 'down'
}
const kpis = computed(() => {
  const row = product.value
  if (!row) return []
  if (kind.value === 'closure') return [['平均结案时间', hoursText(row.hours)], ['已结案 Case', row.cases.length.toLocaleString()], ['任务数量', row.tasks.toLocaleString()]]
  if (kind.value === 'score') return [['Case平均分', `${row.average} 分`], ['已评分 Case', row.cases.length.toLocaleString()], ['高分占比', `${row.high}%`]]
  return [['人机比', `${row.ratio}%`], ['AI任务', row.ai.toLocaleString()], ['工程师任务', row.manual.toLocaleString()]]
})
const segments = computed(() => {
  const row = product.value
  if (!row) return []
  if (kind.value === 'closure') return row.teams.map(team => ({
    id: team.id, label: team.id, color: teamColors[team.id], value: team.hours,
    detail: `${team.name}\n团队平均耗时 ${hoursText(team.hours)} · ${team.tasks} 个任务 · ${team.members.length} 人\n${team.members.slice(0, 10).map(member => `${member.name} ${hoursText(member.hours)}`).join('\n')}`,
  }))
  if (kind.value === 'score') return scoreBands.map(band => ({ ...band, value: row.cases.filter(item => item.score >= band.min && item.score < band.max).length }))
  return [{ id: 'ai', label: 'AI任务', color: '#7A3DFF', value: row.ai }, { id: 'manual', label: '工程师任务', color: '#596574', value: row.manual }]
})
const activeSegment = computed(() => segments.value.find(item => item.id === segment.value))
const donutLabel = computed(() => activeSegment.value ? kind.value === 'closure' ? '平均耗时占比' : kind.value === 'score' ? '评分档位' : '任务类型'
  : kind.value === 'closure' ? '产品平均结案耗时' : kind.value === 'score' ? 'Case平均分' : '人机比')
const donutValue = computed(() => {
  const row = product.value, active = activeSegment.value
  if (!row) return ''
  if (!active) return valueText(row)
  if (kind.value === 'score') return active.label
  return `${(active.value / segments.value.reduce((sum, item) => sum + item.value, 0) * 100).toFixed(1)}%`
})
const cases = computed(() => {
  const row = product.value
  if (!row) return []
  if (kind.value !== 'score') return [...row.cases].sort((a, b) => b.days - a.days)
  const band = scoreBands.find(item => item.id === segment.value)
  return row.cases.filter(item => !band || item.score >= band.min && item.score < band.max).sort((a, b) => a.score - b.score)
})
const members = computed(() => product.value?.teams.find(team => team.id === segment.value)?.members ?? [])
const engineers = computed(() => product.value ? scorePeople(product.value) : [])
const tasks = computed(() => product.value?.cases.flatMap(item => item.tasks).filter(task => !segment.value || task.ai === (segment.value === 'ai')).sort((a, b) => b.rawHours - a.rawHours) ?? [])
const tabs = computed(() => kind.value === 'closure' ? [{ id: 'cases', label: '高耗时 Case' }, { id: 'members', label: '成员平均耗时' }]
  : kind.value === 'score' ? [{ id: 'cases', label: '低分 Case' }, { id: 'people', label: '工程师平均分' }] : [])
function reset() { query.value = ''; platform.value = 'all'; generation.value = 'all' }
function chooseSegment(id: string) {
  segment.value = segment.value === id ? null : id
  if (kind.value === 'closure') view.value = segment.value ? 'members' : 'cases'
}
function chooseView(id: string) {
  view.value = id
  if (kind.value === 'closure' && id === 'cases') segment.value = null
}
function toggle(id: string) { expanded.value = expanded.value === id ? null : id }
function participants(item: EACase) {
  const people = new Map<string, { name: string; hours: number; tasks: number }>()
  for (const task of item.tasks) {
    const person = people.get(task.owner) ?? { name: task.owner, hours: 0, tasks: 0 }
    person.hours += task.hours; person.tasks++; people.set(task.owner, person)
  }
  return [...people.values()].map(person => ({ ...person, hours: person.hours / person.tasks })).sort((a, b) => b.hours - a.hours)
}
const memberTasks = (name: string) => product.value?.cases.flatMap(item => item.tasks).filter(task => task.owner === name).sort((a, b) => b.hours - a.hours).slice(0, 20) ?? []
const sessionLink = (task: EATask, manual = false) => `${route.path}/task/${encodeURIComponent(task.id)}${manual ? '?executor=manual' : ''}`
</script>

<template>
  <section class="page active ea-metric-page">
    <RouterLink class="btn ea-back" to="/overview">← 返回运营总览</RouterLink>
    <div class="head"><h1>{{ title }}</h1><PeriodControl target="overview"><DataFreshness /></PeriodControl></div>
    <div class="ea-metric-workspace">
      <aside class="ea-product-sidebar">
        <div class="ea-product-filters">
          <div class="ea-product-search">
            <input v-model="query" type="search" placeholder="搜索产品" aria-label="按产品名称筛选">
            <button type="button" class="btn" :aria-expanded="filtersOpen" @click="filtersOpen = !filtersOpen">筛选</button>
          </div>
          <div v-if="filtersOpen" class="ea-filter-options">
            <label>平台<select v-model="platform" aria-label="平台筛选"><option value="all">全部平台</option><option v-for="item in platforms" :key="item">{{ item }}</option></select></label>
            <label>产品代数<select v-model="generation" aria-label="产品代数筛选"><option value="all">全部代数</option><option v-for="item in generations" :key="item">{{ item }}</option></select></label>
          </div>
          <div class="ea-filter-count"><button type="button" :disabled="!query && platform === 'all' && generation === 'all'" @click="reset">重置筛选</button><span>{{ rows.length }} / {{ all.length }}</span></div>
        </div>
        <div class="ea-product-list">
          <button v-for="row in rows" :key="row.product" type="button" class="ea-product-option" :class="{ active: selected === row.product }" :aria-pressed="selected === row.product" @click="selected = row.product">
            <b>{{ row.product }}</b>
            <Sparkline :series="metricTrend(kind, row, st).series" :labels="trendLabels" :width="180" :height="32" />
            <strong>{{ valueText(row) }}<small v-if="kind === 'closure'" class="duration-days">{{ daysText(row.hours) }}</small><small class="ea-product-delta" :class="deltaClass(row)">{{ deltaText(row) }}</small></strong>
            <small>{{ row.platform }} · {{ row.generation }} · {{ kind === 'human' ? row.tasks.toLocaleString() + ' 任务' : row.cases.length + ' Cases' }}</small>
          </button>
          <p v-if="!rows.length" class="ea-empty" role="status">当前筛选条件下没有产品</p>
        </div>
      </aside>
      <section v-if="product" class="ea-metric-detail">
        <div class="ea-metric-heading">
          <div><h2>{{ product.product }}</h2><p>{{ product.platform }} · {{ product.generation }} · {{ labelFor(st) }}</p></div>
          <div class="ea-detail-kpis"><div v-for="([label, value], index) in kpis" :key="label"><span>{{ label }}</span><b>{{ value }}</b><small v-if="label === '平均结案时间'" class="duration-days">{{ daysText(product.hours) }}</small><small v-if="index === 0" class="ea-product-delta" :class="deltaClass(product)">{{ deltaText(product) }}</small></div></div>
        </div>
        <div class="ea-metric-main">
          <MetricDonut :segments="segments" :selected="segment" :label="donutLabel" :value="donutValue" :caption="activeSegment?.label ?? product.product" @select="chooseSegment" />
          <div class="ea-ranking">
            <div class="ea-ranking-head">
              <div v-if="tabs.length" class="ea-tabs"><button v-for="tab in tabs" :key="tab.id" type="button" :class="{ active: view === tab.id }" @click="chooseView(tab.id)">{{ tab.label }}</button></div>
              <h3 v-else>任务明细</h3>
              <small>{{ kind === 'human' ? tasks.length.toLocaleString() + ' 个任务 · 高耗时优先' : view === 'people' ? engineers.length + ' 名工程师 · 低分优先' : view === 'members' ? members.length + ' 名成员' : cases.length + ' 个 Case' }}</small>
            </div>
            <div class="ea-ranking-list">
              <template v-if="kind === 'human'">
                <RouterLink v-for="(task, index) in tasks.slice(0, limit)" :key="task.id" class="ea-ranking-row" :to="sessionLink(task)">
                  <span class="ea-rank">#{{ index + 1 }}</span><div><b>{{ task.id }}</b><small><i class="ea-badge" :class="{ ai: task.ai }">{{ task.ai ? 'AI' : '工程师' }}</i>{{ task.caseId }} · {{ task.ai ? '执行者 AI' : '负责人 ' + task.owner }}</small></div><strong>{{ hoursText(task.rawHours) }}<small>查看 Session →</small></strong>
                </RouterLink>
                <button v-if="tasks.length > limit" class="ea-load-more" type="button" @click="limit += 40">加载更多任务</button>
              </template>
              <template v-else-if="view === 'people'">
                <div v-for="(person, index) in engineers" :key="person.name" class="ea-ranking-row"><span class="ea-rank">#{{ index + 1 }}</span><div><b>{{ person.name }}</b><small>参与 {{ person.cases }} 个 Case</small></div><strong>{{ person.average }}<small>平均分</small></strong></div>
              </template>
              <template v-else-if="view === 'members'">
                <p v-if="!segment" class="ea-empty">请选择团队，点击饼图查看成员明细。</p>
                <div v-for="(member, index) in members" :key="member.name" class="ea-ranking-entry">
                  <button class="ea-ranking-row" type="button" :aria-expanded="expanded === member.name" @click="toggle(member.name)">
                    <span class="ea-rank">#{{ index + 1 }}</span><div><b>{{ member.name }}</b><small>{{ member.tasks }} 个任务</small></div><strong>{{ hoursText(member.hours) }}<small>平均耗时</small></strong>
                  </button>
                  <div v-if="expanded === member.name" class="ea-expanded">
                    <RouterLink v-for="task in memberTasks(member.name)" :key="task.id" :to="sessionLink(task, true)"><b>{{ task.id }}</b><small>{{ task.caseId }}</small><span>{{ hoursText(task.hours) }} · 查看 Session →</span></RouterLink>
                  </div>
                </div>
              </template>
              <template v-else>
                <div v-for="(item, index) in cases.slice(0, limit)" :key="item.id" class="ea-ranking-entry">
                  <button v-if="kind === 'closure'" class="ea-ranking-row" type="button" :aria-expanded="expanded === item.id" @click="toggle(item.id)">
                    <span class="ea-rank">#{{ index + 1 }}</span><div><b>{{ item.id }}</b><small>主负责人 {{ item.owner }} · {{ item.tasks.length }} 个任务</small></div><strong>{{ hoursText(item.days * 24) }}<small>{{ item.days }}天</small></strong>
                  </button>
                  <div v-else class="ea-ranking-row"><span class="ea-rank">#{{ index + 1 }}</span><div><b>{{ item.id }}</b><small>Owner {{ item.owner }} · {{ item.tasks.length }} 个任务</small><span class="ea-score-track"><i :style="{ width: item.score + '%', background: scoreBands.find(band => item.score >= band.min && item.score < band.max)?.color }"></i></span></div><strong>{{ item.score }}<small>/100</small></strong></div>
                  <div v-if="kind === 'closure' && expanded === item.id" class="ea-expanded">
                    <div v-for="person in participants(item)" :key="person.name"><b>{{ person.name }}</b><small>{{ person.tasks }} 个任务</small><span>平均 {{ hoursText(person.hours) }}</span></div>
                  </div>
                </div>
                <p v-if="!cases.length" class="ea-empty" role="status">当前评分档位暂无 Case</p>
                <button v-if="cases.length > limit" class="ea-load-more" type="button" @click="limit += 40">加载更多 Case</button>
              </template>
            </div>
          </div>
        </div>
      </section>
      <div v-else class="ea-empty" role="status">没有匹配的产品，请调整筛选条件。</div>
    </div>
  </section>
</template>
