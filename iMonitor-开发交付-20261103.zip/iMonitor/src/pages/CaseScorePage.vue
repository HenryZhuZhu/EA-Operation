<script setup lang="ts">
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'
import PeriodControl from '@/components/PeriodControl.vue'
import SectionLabel from '@/components/SectionLabel.vue'
import KpiCard from '@/components/KpiCard.vue'
import Sparkline from '@/components/Sparkline.vue'
import { periodState } from '@/stores/period'
import { kpiView } from '@/data/compute'
import { aiScoringStandards, caseAIAverageKpi, caseRatingRecords, caseRatingsForPeriod, engineerQualityRecords, summarizeCaseAIScores, type AIReviewState, type CaseRatingRecord, type EngineerQualityRecord } from '@/data/caseScore'
import type { KpiTuple } from '@/types'

type ScoreFilter = '全部得分' | '高分' | '良好' | '低分' | '未出分'
type RankFilter = '全部排名' | '前三名' | '前五名' | '后三名' | '未上榜'
type StateFilter = '全部状态' | AIReviewState
type SourceFilter = '全部来源' | CaseRatingRecord['source']
type ScoreView = 'case' | 'engineer'
type EngineerRankFilter = '全部排名' | '前三名' | '前五名' | '需关注' | '样本观察'

const st = periodState.caseScore
const router = useRouter()
const viewMode = ref<ScoreView>('case')
const allTime = ref(false)
const rankFilter = ref<RankFilter>('全部排名')
const scoreFilter = ref<ScoreFilter>('全部得分')
const productFilter = ref('全部产品')
const stateFilter = ref<StateFilter>('全部状态')
const sourceFilter = ref<SourceFilter>('全部来源')
const query = ref('')
const selected = ref<CaseRatingRecord | null>(null)
const engineerSelected = ref<EngineerQualityRecord | null>(null)
const helpOpen = ref(false)
const engineerRankFilter = ref<EngineerRankFilter>('全部排名')
const engineerDepartment = ref('全部部门')
const engineerProduct = ref('全部产品')
const engineerQuery = ref('')
const caseRadarHover = ref<number | null>(null)
const engineerRadarHover = ref<number | null>(null)

const periodRecords = computed(() => caseRatingsForPeriod(st))
const scopeRecords = computed(() => allTime.value ? caseRatingRecords : periodRecords.value)
const products = computed(() => ['全部产品', ...Array.from(new Set(caseRatingRecords.map((record) => record.product))).sort()])
const sources: SourceFilter[] = ['全部来源', '手动', '检查项Fail', 'SPC自动', 'Issue归集', 'fanout验证']
const states: StateFilter[] = ['全部状态', '已完成', '分析中', '待补充数据', '暂不评分']
const scoreOptions: ScoreFilter[] = ['全部得分', '高分', '良好', '低分', '未出分']
const rankOptions: RankFilter[] = ['全部排名', '前三名', '前五名', '后三名', '未上榜']

const rankedRecords = computed(() => scopeRecords.value.slice().sort((a, b) => {
  if (a.aiScore === null && b.aiScore === null) return b.updatedAt.localeCompare(a.updatedAt)
  if (a.aiScore === null) return 1
  if (b.aiScore === null) return -1
  return b.aiScore - a.aiScore || b.updatedAt.localeCompare(a.updatedAt)
}))
const scoredCount = computed(() => rankedRecords.value.filter((record) => record.aiScore !== null).length)
const rankById = computed(() => new Map(rankedRecords.value
  .filter((record) => record.aiScore !== null)
  .map((record, index) => [record.id, index + 1])))

const caseSummary = computed(() => {
  const { highCount, lowCount, spread } = summarizeCaseAIScores(scopeRecords.value)
  const cards: KpiTuple[] = [
    caseAIAverageKpi(scopeRecords.value),
    ['高分 Case', highCount, '', 'AI 得分 ≥ 90', 12],
    ['低分 Case', lowCount, '', 'AI 得分 < 80', -18],
    ['最高 / 最低分差', spread, ' 分', '本期最高分减最低分', -5],
  ]
  return cards.map((item) => kpiView(item, st))
})

const eligibleEngineers = computed(() => engineerQualityRecords.filter((engineer) => engineer.validCases >= 3))
const rankedEngineers = computed(() => eligibleEngineers.value.slice().sort((a, b) => b.qualityScore - a.qualityScore || b.highScoreRate - a.highScoreRate || b.validCases - a.validCases))
const engineerRankById = computed(() => new Map(rankedEngineers.value.map((engineer, index) => [engineer.id, index + 1])))
const engineerDepartments = computed(() => ['全部部门', ...Array.from(new Set(engineerQualityRecords.map((engineer) => engineer.department))).sort()])
const engineerProducts = computed(() => ['全部产品', ...Array.from(new Set(engineerQualityRecords.flatMap((engineer) => engineer.products))).sort()])
const engineerRankOptions: EngineerRankFilter[] = ['全部排名', '前三名', '前五名', '需关注', '样本观察']

const engineerSummary = computed(() => {
  const formal = eligibleEngineers.value
  const average = formal.length ? Math.round(formal.reduce((sum, engineer) => sum + engineer.qualityScore, 0) / formal.length) : 0
  const high = formal.filter((engineer) => engineer.qualityScore >= 90).length
  const attention = formal.filter((engineer) => engineer.qualityScore < 80).length
  return [
    ['工程师平均质量分', average, ' 分', '正式入榜工程师质量均分', 5],
    ['高质量工程师', high, '', '质量分 ≥ 90', 10],
    ['需关注工程师', attention, '', '质量分 < 80', -12],
    ['正式入榜人数', formal.length, '', '有效评分 Case ≥ 3', 8],
  ].map((item) => kpiView(item as [string, number, string, string, number], st))
})

const summary = computed(() => viewMode.value === 'case' ? caseSummary.value : engineerSummary.value)

const filtered = computed(() => {
  const keyword = query.value.trim().toLowerCase()
  return rankedRecords.value.filter((record) => {
    const rank = rankById.value.get(record.id)
    const matchesRank = rankFilter.value === '全部排名'
      || (rankFilter.value === '前三名' && rank !== undefined && rank <= 3)
      || (rankFilter.value === '前五名' && rank !== undefined && rank <= 5)
      || (rankFilter.value === '后三名' && rank !== undefined && rank > Math.max(0, scoredCount.value - 3))
      || (rankFilter.value === '未上榜' && rank === undefined)
    const matchesScore = scoreFilter.value === '全部得分'
      || (scoreFilter.value === '高分' && record.aiScore !== null && record.aiScore >= 90)
      || (scoreFilter.value === '良好' && record.aiScore !== null && record.aiScore >= 80 && record.aiScore < 90)
      || (scoreFilter.value === '低分' && record.aiScore !== null && record.aiScore < 80)
      || (scoreFilter.value === '未出分' && record.aiScore === null)
    const matchesProduct = productFilter.value === '全部产品' || record.product === productFilter.value
    const matchesState = stateFilter.value === '全部状态' || record.aiState === stateFilter.value
    const matchesSource = sourceFilter.value === '全部来源' || record.source === sourceFilter.value
    const text = [record.code, record.title, record.product, record.owner, record.department, record.issueCode, record.checklist, record.fanoutSource].join(' ').toLowerCase()
    return matchesRank && matchesScore && matchesProduct && matchesState && matchesSource && (!keyword || text.includes(keyword))
  })
})

const filteredEngineers = computed(() => {
  const keyword = engineerQuery.value.trim().toLowerCase()
  const source = engineerRankFilter.value === '样本观察'
    ? engineerQualityRecords.filter((engineer) => engineer.validCases < 3)
    : rankedEngineers.value
  return source.filter((engineer) => {
    const rank = engineerRankById.value.get(engineer.id)
    const matchesRank = engineerRankFilter.value === '全部排名'
      || (engineerRankFilter.value === '前三名' && rank !== undefined && rank <= 3)
      || (engineerRankFilter.value === '前五名' && rank !== undefined && rank <= 5)
      || (engineerRankFilter.value === '需关注' && engineer.qualityScore < 80)
      || (engineerRankFilter.value === '样本观察' && engineer.validCases < 3)
    const matchesDepartment = engineerDepartment.value === '全部部门' || engineer.department === engineerDepartment.value
    const matchesProduct = engineerProduct.value === '全部产品' || engineer.products.includes(engineerProduct.value)
    const text = [engineer.name, engineer.department, ...engineer.products, ...engineer.representativeCases.map((item) => `${item.code} ${item.title}`)].join(' ').toLowerCase()
    return matchesRank && matchesDepartment && matchesProduct && (!keyword || text.includes(keyword))
  })
})

const hasActiveFilters = computed(() => rankFilter.value !== '全部排名'
  || scoreFilter.value !== '全部得分'
  || productFilter.value !== '全部产品'
  || stateFilter.value !== '全部状态'
  || sourceFilter.value !== '全部来源'
  || Boolean(query.value.trim()))

function resetFilters() {
  rankFilter.value = '全部排名'
  scoreFilter.value = '全部得分'
  productFilter.value = '全部产品'
  stateFilter.value = '全部状态'
  sourceFilter.value = '全部来源'
  query.value = ''
}

function resetEngineerFilters() {
  engineerRankFilter.value = '全部排名'
  engineerDepartment.value = '全部部门'
  engineerProduct.value = '全部产品'
  engineerQuery.value = ''
}

const engineerFiltersActive = computed(() => engineerRankFilter.value !== '全部排名'
  || engineerDepartment.value !== '全部部门'
  || engineerProduct.value !== '全部产品'
  || Boolean(engineerQuery.value.trim()))

const engineerTrendSeries = (engineer: EngineerQualityRecord) => Array.from({ length: 8 }, (_, index) => {
  const progress = index / 7
  const start = engineer.qualityScore - engineer.trend
  const wobble = index === 0 || index === 7 ? 0 : Math.sin(index * 1.4 + engineer.validCases) * 1.2
  return Math.round(start + engineer.trend * progress + wobble)
})
const engineerTrendLabels = ['W1', 'W2', 'W3', 'W4', 'W5', 'W6', 'W7', '本周']

const drawerRadarCenter = { x: 160, y: 115 }
const drawerRadarRadius = 72
const drawerRadarLabels = ['问题定义', '思路假设', '任务协作', '证据留痕', '推理结论', '闭环复用']
const drawerRadarPoint = (index: number, value = 100, extra = 0) => {
  const angle = -Math.PI / 2 + index * Math.PI / 3
  const radius = drawerRadarRadius * value / 100 + extra
  return {
    x: drawerRadarCenter.x + Math.cos(angle) * radius,
    y: drawerRadarCenter.y + Math.sin(angle) * radius,
  }
}
const drawerPointString = (points: { x: number; y: number }[]) => points
  .map((point) => `${point.x.toFixed(1)},${point.y.toFixed(1)}`)
  .join(' ')
const drawerRadarGrid = [25, 50, 75, 100].map((level) => ({
  level,
  points: drawerPointString(Array.from({ length: 6 }, (_, index) => drawerRadarPoint(index, level))),
}))
const drawerRadarAxes = computed(() => (selected.value?.dimensions ?? []).map((dimension, index) => ({
  axis: drawerRadarPoint(index),
  point: drawerRadarPoint(index, dimension.score),
  label: drawerRadarPoint(index, 100, 20),
  text: drawerRadarLabels[index],
  score: dimension.score,
})))
const drawerRadarData = computed(() => drawerPointString(drawerRadarAxes.value.map((axis) => axis.point)))
const caseRadarHoverDimension = computed(() => caseRadarHover.value === null
  ? null
  : selected.value?.dimensions[caseRadarHover.value] ?? null)
const drawerStrongest = computed(() => selected.value?.dimensions.slice().sort((a, b) => b.score - a.score)[0])
const drawerWeakest = computed(() => selected.value?.dimensions.slice().sort((a, b) => a.score - b.score)[0])
const drawerAbilitySpread = computed(() => drawerStrongest.value && drawerWeakest.value
  ? drawerStrongest.value.score - drawerWeakest.value.score
  : 0)
const engineerRadarAxes = computed(() => (engineerSelected.value?.dimensions ?? []).map((dimension, index) => ({
  axis: drawerRadarPoint(index),
  point: drawerRadarPoint(index, dimension.score),
  label: drawerRadarPoint(index, 100, 20),
  text: drawerRadarLabels[index],
  score: dimension.score,
})))
const engineerRadarData = computed(() => drawerPointString(engineerRadarAxes.value.map((axis) => axis.point)))
const engineerRadarHoverDimension = computed(() => engineerRadarHover.value === null
  ? null
  : engineerSelected.value?.dimensions[engineerRadarHover.value] ?? null)
const engineerRadarHoverStandard = computed(() => engineerRadarHover.value === null
  ? null
  : aiScoringStandards[engineerRadarHover.value] ?? null)
const engineerStrongest = computed(() => engineerSelected.value?.dimensions.slice().sort((a, b) => b.score - a.score)[0])
const engineerWeakest = computed(() => engineerSelected.value?.dimensions.slice().sort((a, b) => a.score - b.score)[0])
const engineerAbilitySpread = computed(() => engineerStrongest.value && engineerWeakest.value
  ? engineerStrongest.value.score - engineerWeakest.value.score
  : 0)
const engineerOwnedCases = computed(() => {
  if (!engineerSelected.value) return []
  return caseRatingRecords
    .filter((record) => record.owner === engineerSelected.value?.name)
    .sort((a, b) => {
      if (a.aiScore === null && b.aiScore !== null) return 1
      if (a.aiScore !== null && b.aiScore === null) return -1
      return (b.aiScore ?? 0) - (a.aiScore ?? 0) || b.updatedAt.localeCompare(a.updatedAt)
    })
})

const aiStateClass = (state: AIReviewState) => ({ '已完成': 'complete', '分析中': 'analyzing', '待补充数据': 'missing', '暂不评分': 'excluded' }[state])
const sourceClass = (source: CaseRatingRecord['source']) => ({ '检查项Fail': 'fail', 'SPC自动': 'spc', 'Issue归集': 'issue', 'fanout验证': 'fanout', '手动': 'manual' }[source])
const taskProgress = (record: CaseRatingRecord) => record.totalTasks ? Math.round(record.completedTasks / record.totalTasks * 100) : 0
const scoreGrade = (score: number | null) => score === null ? '—' : score >= 90 ? '优秀' : score >= 80 ? '良好' : score >= 70 ? '需改进' : '风险'
const actionLabel = (state: AIReviewState) => state === '已完成' ? '查看评分' : state === '分析中' ? '查看进度' : state === '待补充数据' ? '查看缺失项' : '查看原因'

function openResult(record: CaseRatingRecord) { selected.value = record }
function closeResult() { selected.value = null; caseRadarHover.value = null }
function openEngineer(engineer: EngineerQualityRecord) { engineerSelected.value = engineer }
function closeEngineer() { engineerSelected.value = null; engineerRadarHover.value = null }
function openEngineerCase(record: CaseRatingRecord) {
  closeEngineer()
  if (record.aiState === '已完成') router.push(`/case-score/${record.id}/report`)
  else openResult(record)
}
function openReport(record: CaseRatingRecord) {
  closeResult()
  router.push(`/case-score/${record.id}/report`)
}
</script>

<template>
  <section class="page active" id="case-score">
    <div class="head">
      <div>
        <div class="case-score-title-row">
          <h1>Case评分</h1>
          <div class="ai-score-help" @mouseenter="helpOpen = true" @mouseleave="helpOpen = false">
            <button type="button" aria-label="查看 AI 评分标准" @focus="helpOpen = true" @blur="helpOpen = false">?</button>
            <div v-if="helpOpen" class="ai-score-tooltip" role="tooltip">
              <b>AI 评分标准</b>
              <p>AI 评价的是工程师在 Case 中沉淀的工程质量，而不是 Case 难度。六个维度加权计算，满分 100 分。</p>
              <div class="ai-standard-list">
                <span v-for="standard in aiScoringStandards" :key="standard.key">
                  <i>{{ standard.weight }}%</i>
                  <b>{{ standard.label }}</b>
                  <small>{{ standard.criteria }}</small>
                </span>
              </div>
              <div class="ai-scoring-policy">
                <b>评分约束</b>
                <p>· 按当前生命周期归一化：进行中的 Case 不因尚未结案被重复扣分。</p>
                <p>· 无数据、无附件或无验证证据时，相关维度限分；核心信息不足则暂不出分。</p>
                <p>· 只评价可归因于工程师的填写、分析、执行与协作，不把系统自动字段计为个人成果。</p>
              </div>
              <p><strong>90–100 优秀</strong> · 80–89 良好 · 70–79 需改进 · 低于 70 风险</p>
              <small>扣分依据必须对应具体缺失项；核心信息不足时暂不生成评分。</small>
            </div>
          </div>
        </div>
      </div>
      <PeriodControl v-if="viewMode === 'case'" target="caseScore" allow-all :all-selected="allTime" @all-change="allTime = $event" />
      <div v-else class="engineer-scope-badge"><span>统计范围</span><b>累计（全部）</b></div>
    </div>

    <div class="score-view-tabs">
      <button :class="{ active: viewMode === 'case' }" @click="viewMode = 'case'">Case 天梯</button>
      <button :class="{ active: viewMode === 'engineer' }" @click="viewMode = 'engineer'">工程师天梯</button>
    </div>

    <SectionLabel>{{ viewMode === 'case' ? 'AI 评分概览' : '工程师质量概览' }}</SectionLabel>
    <div class="kpis rating-summary">
      <KpiCard v-for="k in summary" :key="k.label" :label="k.label" :value="k.value" :calc="k.calc" :series="k.series" :trend="k.trend" :labels="k.labels" :unit="k.unit" />
    </div>

    <SectionLabel
      style="margin-top:24px"
      :small="viewMode === 'case' ? '按 AI 综合得分降序排列，未出分 Case 位于榜单末尾' : '累计贡献快照；有效评分 Case ≥ 3 才进入正式名次，样本不足显示观察中'"
    >{{ viewMode === 'case' ? 'AI 评分天梯' : '工程师质量天梯' }}</SectionLabel>
    <div v-if="viewMode === 'case'" class="rating-filter-panel">
      <div class="rating-filter-row">
        <span class="rating-filter-label">筛选</span>
        <select v-model="rankFilter" class="rating-select" aria-label="按天梯排名筛选">
          <option v-for="option in rankOptions" :key="option" :value="option">{{ option }}</option>
        </select>
        <select v-model="scoreFilter" class="rating-select" aria-label="按得分筛选">
          <option v-for="option in scoreOptions" :key="option" :value="option">{{ option === '高分' ? '高分（≥90）' : option === '良好' ? '良好（80–89）' : option === '低分' ? '低分（<80）' : option }}</option>
        </select>
        <select v-model="productFilter" class="rating-select product" aria-label="按产品筛选">
          <option v-for="product in products" :key="product" :value="product">{{ product }}</option>
        </select>
        <select v-model="stateFilter" class="rating-select" aria-label="按 AI 状态筛选">
          <option v-for="state in states" :key="state" :value="state">{{ state }}</option>
        </select>
        <select v-model="sourceFilter" class="rating-select" aria-label="按来源筛选">
          <option v-for="source in sources" :key="source" :value="source">{{ source }}</option>
        </select>
        <input v-model="query" class="rating-search" placeholder="搜索 Case、产品、Owner、Issue" />
        <button class="rating-reset" :disabled="!hasActiveFilters" @click="resetFilters">重置</button>
        <span class="rating-result">{{ filtered.length }} / {{ scopeRecords.length }} 个 Case</span>
      </div>
    </div>

    <div v-else class="rating-filter-panel">
      <div class="rating-filter-row">
        <span class="rating-filter-label">筛选</span>
        <select v-model="engineerRankFilter" class="rating-select" aria-label="按工程师排名筛选">
          <option v-for="option in engineerRankOptions" :key="option" :value="option">{{ option }}</option>
        </select>
        <select v-model="engineerDepartment" class="rating-select" aria-label="按部门筛选">
          <option v-for="department in engineerDepartments" :key="department" :value="department">{{ department }}</option>
        </select>
        <select v-model="engineerProduct" class="rating-select product" aria-label="按工程师产品筛选">
          <option v-for="product in engineerProducts" :key="product" :value="product">{{ product }}</option>
        </select>
        <input v-model="engineerQuery" class="rating-search" placeholder="搜索工程师、产品、Case" />
        <button class="rating-reset" :disabled="!engineerFiltersActive" @click="resetEngineerFilters">重置</button>
        <span class="rating-result">{{ filteredEngineers.length }} / {{ engineerRankFilter === '样本观察' ? engineerQualityRecords.length - eligibleEngineers.length : eligibleEngineers.length }} 人</span>
      </div>
    </div>

    <div v-if="viewMode === 'case'" class="rating-list">
      <article v-for="record in filtered" :key="record.id" class="rating-card">
        <div class="rating-card-head">
          <span class="rating-state ai" :class="aiStateClass(record.aiState)">{{ record.aiState === '已完成' ? 'AI 已评分' : record.aiState }}</span>
          <span class="rating-level">{{ record.level }}</span>
          <span class="rating-urgency">{{ record.urgency }}</span>
          <span class="rating-source" :class="sourceClass(record.source)">{{ record.source }}</span>
          <span class="rating-code">{{ record.code }}</span>
          <span class="rating-updated">更新 {{ record.updatedAt.slice(5) }}</span>
        </div>
        <div class="rating-card-body">
          <div class="ladder-rank" :class="{ top: (rankById.get(record.id) ?? 99) <= 3, unranked: !rankById.has(record.id) }">
            <small>名次</small><b>{{ rankById.get(record.id) ? '#' + rankById.get(record.id) : '—' }}</b>
          </div>
          <div class="rating-case-main">
            <h3>{{ record.title }}</h3>
            <div class="rating-meta"><span>{{ record.product }}</span><span>Owner {{ record.owner }}</span><span>{{ record.department }}</span><span>{{ record.lifecycle }}</span></div>
            <div v-if="record.issueCode || record.checklist || record.fanoutSource" class="rating-relations">
              <span v-if="record.issueCode">Issue {{ record.issueCode }}</span>
              <span v-if="record.checklist">Checklist {{ record.checklist }}</span>
              <span v-if="record.fanoutSource">源 Case {{ record.fanoutSource }}</span>
            </div>
          </div>
          <div class="rating-task-progress"><div class="rating-column-label">任务完成</div><div class="rating-progress-line"><i :style="{ width: taskProgress(record) + '%' }"></i></div><b>{{ record.completedTasks }}/{{ record.totalTasks }}</b></div>
          <div class="rating-number score ai"><span>AI 得分</span><b>{{ record.aiScore ?? '—' }}<small v-if="record.aiScore !== null">/100</small></b></div>
          <div class="rating-number generated"><span>生成时间</span><b>{{ record.generatedAt?.slice(5) ?? '等待生成' }}</b></div>
          <button class="rating-action" @click="openResult(record)">{{ actionLabel(record.aiState) }}</button>
        </div>
      </article>
      <div v-if="!filtered.length" class="rating-empty">当前筛选条件下没有 Case</div>
    </div>

    <div v-else class="engineer-ladder-list">
      <article v-for="engineer in filteredEngineers" :key="engineer.id" class="engineer-ladder-row">
        <div class="ladder-rank" :class="{ top: (engineerRankById.get(engineer.id) ?? 99) <= 3, unranked: !engineerRankById.has(engineer.id) }">
          <small>{{ engineerRankById.has(engineer.id) ? '名次' : '样本' }}</small>
          <b>{{ engineerRankById.get(engineer.id) ? '#' + engineerRankById.get(engineer.id) : '观察' }}</b>
        </div>
        <div class="engineer-identity">
          <span class="engineer-avatar">{{ engineer.name.slice(0, 1) }}</span>
          <div><h3>{{ engineer.name }}</h3><p>{{ engineer.department }} · {{ engineer.products.join(' / ') }}</p></div>
        </div>
        <div class="engineer-counts">
          <span>有效 Case <b>{{ engineer.validCases }}</b></span>
          <span>牵头 / 参与 <b>{{ engineer.leadCases }} / {{ engineer.participatedCases }}</b></span>
        </div>
        <div class="engineer-trend">
          <Sparkline :series="engineerTrendSeries(engineer)" :trend="engineer.trend" :labels="engineerTrendLabels" unit=" 分" />
        </div>
        <div class="engineer-quality-score">
          <span>质量分</span><b>{{ engineer.qualityScore }}</b>
          <small :class="engineer.trend >= 0 ? 'up' : 'down'">{{ engineer.trend >= 0 ? '▲' : '▼' }} {{ Math.abs(engineer.trend) }}</small>
        </div>
        <div class="engineer-high-rate"><span>高分占比</span><b>{{ engineer.highScoreRate }}%</b></div>
        <button class="rating-action" @click="openEngineer(engineer)">查看质量概览</button>
      </article>
      <div v-if="!filteredEngineers.length" class="rating-empty">当前筛选条件下没有工程师</div>
    </div>

    <div v-if="selected" class="rating-mask" @click.self="closeResult">
      <div class="rating-drawer">
        <div class="rating-drawer-head"><div><span>{{ selected.code }}</span><h2>{{ selected.title }}</h2></div><button title="关闭" @click="closeResult">×</button></div>
        <div class="rating-drawer-body">
          <div class="rating-context">
            <div><span>产品</span><b>{{ selected.product }}</b></div><div><span>Owner</span><b>{{ selected.owner }} · {{ selected.department }}</b></div>
            <div><span>Case 状态</span><b>{{ selected.lifecycle }}</b></div><div><span>AI 状态</span><b>{{ selected.aiState }}</b></div>
          </div>

          <div v-if="selected.aiState === '已完成'" class="ai-result-hero">
            <div class="ai-score-main"><span>AI 综合评分</span><b>{{ selected.aiScore }}</b><small>/ 100 · {{ scoreGrade(selected.aiScore) }}</small></div>
            <div class="ai-generated-at"><span>评分生成时间</span><b>{{ selected.generatedAt }}</b></div>
          </div>

          <div class="ai-summary-block"><span>AI 评分摘要</span><p>{{ selected.aiSummary }}</p></div>

          <template v-if="selected.aiState === '已完成'">
            <div class="ai-detail-title">六维能力图</div>
            <div class="drawer-radar-layout">
              <div class="drawer-radar-chart" @mouseleave="caseRadarHover = null">
                <svg class="drawer-radar" viewBox="0 0 320 235" role="img" aria-label="Case 六维能力雷达图">
                  <polygon v-for="grid in drawerRadarGrid" :key="grid.level" :points="grid.points" class="report-radar-grid" />
                  <line v-for="(axis, index) in drawerRadarAxes" :key="'axis-' + index" :x1="drawerRadarCenter.x" :y1="drawerRadarCenter.y" :x2="axis.axis.x" :y2="axis.axis.y" class="report-radar-axis" />
                  <polygon :points="drawerRadarData" class="report-radar-data" />
                  <circle v-for="(axis, index) in drawerRadarAxes" :key="'point-' + index" :cx="axis.point.x" :cy="axis.point.y" r="3" class="report-radar-point" />
                  <g v-for="(axis, index) in drawerRadarAxes" :key="'label-' + index">
                    <text :x="axis.label.x" :y="axis.label.y" text-anchor="middle" class="report-radar-label">{{ axis.text }}</text>
                    <text :x="axis.label.x" :y="axis.label.y + 11" text-anchor="middle" class="report-radar-score">{{ axis.score }}</text>
                  </g>
                  <circle
                    v-for="(axis, index) in drawerRadarAxes"
                    :key="'hit-' + index"
                    :cx="axis.point.x"
                    :cy="axis.point.y"
                    r="17"
                    class="drawer-radar-hit"
                    tabindex="0"
                    :aria-label="`${selected.dimensions[index].label} ${axis.score} 分`"
                    @mouseenter="caseRadarHover = index"
                    @focus="caseRadarHover = index"
                    @blur="caseRadarHover = null"
                  />
                </svg>
                <div
                  v-if="caseRadarHover !== null && caseRadarHoverDimension"
                  class="drawer-radar-tip"
                  :class="{ below: drawerRadarAxes[caseRadarHover]?.point.y < 80 }"
                  :style="{ left: `${(drawerRadarAxes[caseRadarHover]?.point.x ?? 0) / 3.2}%`, top: `${(drawerRadarAxes[caseRadarHover]?.point.y ?? 0) / 2.35}%` }"
                >
                  <div><b>{{ caseRadarHoverDimension.label }}</b><strong>{{ caseRadarHoverDimension.score }}</strong></div>
                  <small v-if="caseRadarHoverDimension.weight">权重 {{ caseRadarHoverDimension.weight }}%</small>
                  <p>{{ caseRadarHoverDimension.finding }}</p>
                </div>
              </div>
              <div class="drawer-radar-insights">
                <div><span>最强维度</span><b>{{ drawerStrongest?.label }}</b><strong>{{ drawerStrongest?.score }}</strong></div>
                <div><span>优先提升</span><b>{{ drawerWeakest?.label }}</b><strong>{{ drawerWeakest?.score }}</strong></div>
                <div><span>能力差值</span><b>最高分 − 最低分</b><strong>{{ drawerAbilitySpread }}</strong></div>
              </div>
            </div>
            <div class="ai-detail-title">扣分依据</div>
            <div class="ai-deduction-list">
              <div v-for="deduction in selected.deductions" :key="deduction.label" class="ai-deduction-row">
                <div><b>{{ deduction.label }}</b><p>{{ deduction.detail }}</p></div><span>-{{ deduction.points }}</span>
              </div>
            </div>
          </template>

          <div class="rating-evidence">
            <div><span>任务完成情况</span><b>{{ selected.completedTasks }} / {{ selected.totalTasks }}</b></div>
            <div v-if="selected.issueCode"><span>关联 Issue</span><b>{{ selected.issueCode }}</b></div>
            <div v-if="selected.checklist"><span>来源 Checklist</span><b>{{ selected.checklist }}</b></div>
            <div v-if="selected.fanoutSource"><span>Fanout 源 Case</span><b>{{ selected.fanoutSource }}</b></div>
          </div>
        </div>
        <div class="rating-drawer-foot">
          <button v-if="selected.aiState === '已完成'" class="btn rating-report-link" @click="openReport(selected)">查看评分报告</button>
          <button class="btn primary" @click="closeResult">关闭</button>
        </div>
      </div>
    </div>

    <div v-if="engineerSelected" class="rating-mask" @click.self="closeEngineer">
      <div class="rating-drawer engineer-drawer">
        <div class="rating-drawer-head">
          <div><span>{{ engineerSelected.department }} · 工程师质量概览</span><h2>{{ engineerSelected.name }}</h2></div>
          <button title="关闭" @click="closeEngineer">×</button>
        </div>
        <div class="rating-drawer-body">
          <div class="engineer-detail-hero">
            <div><span>工程质量分</span><b>{{ engineerSelected.qualityScore }}</b></div>
            <div><span>正式名次</span><b>{{ engineerRankById.get(engineerSelected.id) ? '#' + engineerRankById.get(engineerSelected.id) : '样本观察中' }}</b></div>
            <div><span>有效评分 Case</span><b>{{ engineerSelected.validCases }}</b></div>
            <div><span>高分 Case 占比</span><b>{{ engineerSelected.highScoreRate }}%</b></div>
          </div>
          <div class="ai-detail-title">六维能力图</div>
          <div class="drawer-radar-layout">
            <div class="drawer-radar-chart" @mouseleave="engineerRadarHover = null">
              <svg class="drawer-radar" viewBox="0 0 320 235" role="img" :aria-label="`${engineerSelected.name} 六维能力雷达图`">
                <polygon v-for="grid in drawerRadarGrid" :key="grid.level" :points="grid.points" class="report-radar-grid" />
                <line v-for="(axis, index) in engineerRadarAxes" :key="'engineer-axis-' + index" :x1="drawerRadarCenter.x" :y1="drawerRadarCenter.y" :x2="axis.axis.x" :y2="axis.axis.y" class="report-radar-axis" />
                <polygon :points="engineerRadarData" class="report-radar-data" />
                <circle v-for="(axis, index) in engineerRadarAxes" :key="'engineer-point-' + index" :cx="axis.point.x" :cy="axis.point.y" r="3" class="report-radar-point" />
                <g v-for="(axis, index) in engineerRadarAxes" :key="'engineer-label-' + index">
                  <text :x="axis.label.x" :y="axis.label.y" text-anchor="middle" class="report-radar-label">{{ axis.text }}</text>
                  <text :x="axis.label.x" :y="axis.label.y + 11" text-anchor="middle" class="report-radar-score">{{ axis.score }}</text>
                </g>
                <circle
                  v-for="(axis, index) in engineerRadarAxes"
                  :key="'engineer-hit-' + index"
                  :cx="axis.point.x"
                  :cy="axis.point.y"
                  r="17"
                  class="drawer-radar-hit"
                  tabindex="0"
                  :aria-label="`${engineerSelected.dimensions[index].label} ${axis.score} 分`"
                  @mouseenter="engineerRadarHover = index"
                  @focus="engineerRadarHover = index"
                  @blur="engineerRadarHover = null"
                />
              </svg>
              <div
                v-if="engineerRadarHover !== null && engineerRadarHoverDimension"
                class="drawer-radar-tip"
                :class="{ below: engineerRadarAxes[engineerRadarHover]?.point.y < 80 }"
                :style="{ left: `${(engineerRadarAxes[engineerRadarHover]?.point.x ?? 0) / 3.2}%`, top: `${(engineerRadarAxes[engineerRadarHover]?.point.y ?? 0) / 2.35}%` }"
              >
                <div><b>{{ engineerRadarHoverDimension.label }}</b><strong>{{ engineerRadarHoverDimension.score }}</strong></div>
                <small>权重 {{ engineerRadarHoverStandard?.weight }}%</small>
                <p>{{ engineerRadarHoverStandard?.criteria }}</p>
              </div>
            </div>
            <div class="drawer-radar-insights">
              <div><span>最强维度</span><b>{{ engineerStrongest?.label }}</b><strong>{{ engineerStrongest?.score }}</strong></div>
              <div><span>优先提升</span><b>{{ engineerWeakest?.label }}</b><strong>{{ engineerWeakest?.score }}</strong></div>
              <div><span>能力差值</span><b>最高分 − 最低分</b><strong>{{ engineerAbilitySpread }}</strong></div>
            </div>
          </div>
          <div class="ai-detail-title engineer-owned-title"><span>负责的 Case</span><small>Owner 为 {{ engineerSelected.name }} · {{ engineerOwnedCases.length }} 个</small></div>
          <div v-if="engineerOwnedCases.length" class="engineer-owned-case-list">
            <button v-for="record in engineerOwnedCases" :key="record.id" type="button" class="engineer-owned-case" @click="openEngineerCase(record)">
              <span class="engineer-owned-case-code">{{ record.code }}</span>
              <b>{{ record.title }}</b>
              <span class="engineer-owned-case-meta">{{ record.product }} · {{ record.lifecycle }}</span>
              <strong :class="{ pending: record.aiScore === null }">{{ record.aiScore ?? record.aiState }}</strong>
              <small>{{ record.aiState === '已完成' ? '查看评分报告' : actionLabel(record.aiState) }}</small>
            </button>
          </div>
          <div v-else class="engineer-owned-empty">当前评分工作集中没有由该工程师担任 Owner 的 Case</div>
          <div class="ai-detail-title">代表性贡献 Case</div>
          <div class="engineer-case-list">
            <div v-for="item in engineerSelected.representativeCases" :key="item.code">
              <span>{{ item.code }}</span><b>{{ item.title }}</b><strong>{{ item.score }}</strong>
            </div>
          </div>
          <div class="engineer-attribution-note">质量分按字段、任务、附件和结论的实际贡献归因聚合，不将整个 Case 分数直接归给 Owner。</div>
        </div>
        <div class="rating-drawer-foot"><button class="btn primary" @click="closeEngineer">关闭</button></div>
      </div>
    </div>
  </section>
</template>