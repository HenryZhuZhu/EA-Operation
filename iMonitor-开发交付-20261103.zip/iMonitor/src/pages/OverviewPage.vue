<script setup lang="ts">
import { computed } from 'vue'
import PeriodControl from '@/components/PeriodControl.vue'
import DataFreshness from '@/components/DataFreshness.vue'
import KpiCard from '@/components/KpiCard.vue'
import Panel from '@/components/Panel.vue'
import HoursChart from '@/components/HoursChart.vue'
import { periodState } from '@/stores/period'
import { tele } from '@/data/mock'
import { ovDataFor, factorFor, labelFor } from '@/data/compute'
import { overviewKpi } from '@/data/eaOverview'
import { caseAIAverageKpi, caseRatingsForPeriod } from '@/data/caseScore'
import { liveTick } from '@/data/umami'
import { trafficMetricLabels } from '@/data/metrics'

const st = periodState.overview

const quality = computed(() => {
  liveTick.value
  const aiAverage = caseAIAverageKpi(caseRatingsForPeriod(st))
  const paths = ['closure', 'score', 'human']
  const detailLabels = ['查看各产品结案效率详情', '查看各产品 Case 平均分详情', '查看各产品人机比详情']
  return ovDataFor(st).quality.map((kpi, index) => ({
    ...overviewKpi(index === 1 ? aiAverage : kpi, st),
    to: `/overview/${paths[index]}`, detailLabel: detailLabels[index],
  }))
})
const access = computed(() => (liveTick.value, ovDataFor(st).access.map((k) => ({
  ...overviewKpi(k, st),
  to: k[0] === trafficMetricLabels.uv || k[0] === '编辑内容用户' ? '/overview/activity' : undefined,
  detailLabel: k[0] === trafficMetricLabels.uv ? '查看用户活跃明细' : k[0] === '编辑内容用户' ? '查看内容编辑用户明细' : undefined,
}))))
const factor = computed(() => factorFor(st))
const label = computed(() => labelFor(st))
</script>

<template>
  <section class="page active" id="overview">
    <div class="head">
      <div>
        <h1>运营总览</h1>
      </div>
      <PeriodControl target="overview"><DataFreshness /></PeriodControl>
    </div>

    <div class="overview-split">
      <section class="overview-case-results">
        <div class="overview-column-head"><h3>核心指标</h3></div>
        <div class="overview-result-kpis">
          <KpiCard v-for="k in quality" :key="k.label" v-bind="k" />
        </div>
      </section>
      <section class="overview-platform">
        <div class="overview-column-head"><h3>平台使用</h3></div>
        <div class="overview-usage-kpis">
          <KpiCard v-for="k in access" :key="k.label" v-bind="k" />
        </div>
        <Panel class="hours-panel" title="访问时段分布" :small="label + ' · 按小时'">
          <HoursChart :hours="tele.hoursBase" :factor="factor" />
        </Panel>
      </section>
    </div>
  </section>
</template>
