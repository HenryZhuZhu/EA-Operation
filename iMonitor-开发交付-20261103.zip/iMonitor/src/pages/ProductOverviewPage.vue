<script setup lang="ts">
import { computed } from 'vue'
import { RouterLink, useRoute } from 'vue-router'
import PeriodControl from '@/components/PeriodControl.vue'
import KpiCard from '@/components/KpiCard.vue'
import Panel from '@/components/Panel.vue'
import Sparkline from '@/components/Sparkline.vue'
import HoursChart from '@/components/HoursChart.vue'
import { findProduct, findSubproduct, productTraffic, trafficCoverage } from '@/data/products'
import { periodState } from '@/stores/period'
import { activeUserDefinition, trafficMetricLabels } from '@/data/metrics'

const route = useRoute()
const product = computed(() => findProduct(route.params.productId)!)
const subproduct = computed(() => findSubproduct(product.value, route.params.subproductId))
const isPlatform = computed(() => product.value.subproducts.length > 0 && !subproduct.value)
const scopeKind = computed(() => product.value.id === 'product-space' ? '模块' : '子产品')
const scopeName = computed(() => subproduct.value?.name ?? product.value.name)
const traffic = computed(() => productTraffic(product.value, periodState.productTraffic, subproduct.value?.id))
const scopeLink = (id?: string) => `/product/${product.value.id}${id ? '/' + id : ''}`
const labels = computed(() => traffic.value.selected.map((day) => day.date))
const metrics = computed(() => {
  const t = traffic.value
  return [
    { label: trafficMetricLabels.uv, value: t.uv, calc: activeUserDefinition, to: scopeLink(subproduct.value?.id) + '/activity', detailLabel: '查看用户活跃明细' },
    { label: trafficMetricLabels.pv, value: t.pv, calc: '所选区间内页面浏览总次数', to: scopeLink(subproduct.value?.id) + '/pageviews', detailLabel: '查看页面浏览明细' },
    { label: '访问会话', value: t.visits, calc: isPlatform.value ? `${scopeKind.value}会话数之和，会话按${scopeKind.value}独立划分` : '连续 30 分钟无操作后计为新会话' },
    { label: trafficMetricLabels.averageDuration, value: `${t.avgMinutes}<small> 分</small>`, calc: '所选区间总访问时长 / 会话数' },
    { label: '日活粘性 DAU / MAU', value: t.dauMau === null ? '—' : `${t.dauMau}<small>%</small>`, calc: '截至区间末日，近 30 天平均 DAU / MAU' },
    { label: '周活粘性 WAU / MAU', value: t.wauMau === null ? '—' : `${t.wauMau}<small>%</small>`, calc: '截至区间末日，近 7 天 WAU / 近 30 天 MAU' },
  ]
})
</script>

<template>
  <section class="page active product-overview">
    <div class="head">
      <div>
        <h1>{{ scopeName }} {{ isPlatform ? '平台总览' : '运营总览' }}</h1>
      </div>
      <PeriodControl target="productTraffic" />
    </div>
    <div v-if="traffic.partial" class="src-note" role="status">
      所选区间超出可用数据范围，仅统计有数据的日期；缺少完整 30 天窗口时，粘性显示为「—」。
    </div>

    <template v-if="traffic.selected.length">
      <div class="kpis product-kpis">
        <KpiCard v-for="metric in metrics" :key="metric.label" v-bind="metric" />
      </div>

      <div class="product-charts">
        <Panel class="product-visit-trend" title="访问趋势" :small="`${traffic.selected.length} 天 · 按日统计`">
          <div class="traffic-trend" v-for="metric in (['uv', 'pv'] as const)" :key="metric">
            <div class="traffic-trend-head">
              <span>{{ trafficMetricLabels[metric] }}</span>
              <b class="tn">{{ traffic[metric].toLocaleString() }}</b>
            </div>
            <Sparkline v-if="traffic.selected.length > 1" :series="traffic.selected.map(day => metric === 'uv' ? day.users.length : day.pv)" :labels="labels" :width="600" :height="90" />
            <p v-else class="traffic-single-day">当日 UV {{ traffic.uv }} · PV {{ traffic.pv }}，切换周 / 月查看多日趋势。</p>
          </div>
          <div class="traffic-axis"><span>{{ labels[0] }}</span><span>{{ labels[labels.length - 1] }}</span></div>
          <p class="traffic-note">UV 总量按区间去重，不等于每日 UV 相加；趋势线支持悬停查看。</p>
        </Panel>
        <Panel title="用户活跃结构" small="截至所选区间末日 · 滚动窗口">
          <div class="active-user-row"><span>DAU · 末日活跃用户</span><b class="tn">{{ traffic.dau }}</b></div>
          <div class="active-user-row"><span>WAU · 近 7 天活跃用户</span><b class="tn">{{ traffic.wau }}</b></div>
          <div class="active-user-row"><span>MAU · 近 30 天活跃用户</span><b class="tn">{{ traffic.mau }}</b></div>
          <div class="active-user-row"><span>近 30 天平均 DAU</span><b class="tn">{{ traffic.averageDAU }}</b></div>
          <p class="traffic-note">活跃指至少发生一次访问。粘性越高，表示用户回访越频繁；未覆盖完整窗口时不展示粘性比率。</p>
        </Panel>
      </div>

      <Panel v-if="isPlatform" class="product-subproducts" :title="scopeKind + '运营对比'" :small="`所选区间 · ${product.subproducts.length} 个${scopeKind}`">
        <div class="subproduct-traffic-scroll" role="region" :aria-label="scopeKind + '运营对比表'" tabindex="0">
        <table class="subproduct-traffic-table">
          <thead><tr><th>{{ scopeKind }}</th><th>{{ trafficMetricLabels.uv }}</th><th>{{ trafficMetricLabels.pv }}</th><th>会话数</th><th>{{ trafficMetricLabels.averageDuration }}</th><th>日活粘性</th><th>周活粘性</th><th>PV 占比</th></tr></thead>
          <tbody>
            <tr v-for="child in traffic.subproducts" :key="child.id">
              <td><RouterLink :to="scopeLink(child.id)">{{ child.name }} ↗</RouterLink></td>
              <td class="tn"><RouterLink :to="scopeLink(child.id) + '/activity'" :aria-label="`查看 ${child.name} 用户活跃明细`">{{ child.uv.toLocaleString() }}</RouterLink></td>
              <td class="tn"><RouterLink :to="scopeLink(child.id) + '/pageviews'" :aria-label="`查看 ${child.name} 页面浏览明细`">{{ child.pv.toLocaleString() }}</RouterLink></td>
              <td class="tn">{{ child.visits.toLocaleString() }}</td>
              <td class="tn">{{ child.avgMinutes }} 分</td>
              <td class="tn">{{ child.dauMau === null ? '—' : child.dauMau + '%' }}</td>
              <td class="tn">{{ child.wauMau === null ? '—' : child.wauMau + '%' }}</td>
              <td><div class="subproduct-share"><span :style="{ width: child.share + '%' }"></span></div><b class="tn">{{ child.share }}%</b></td>
            </tr>
          </tbody>
        </table>
        </div>
        <p class="traffic-note">点击{{ scopeKind }}名称查看独立统计。各{{ scopeKind }} UV 不可直接相加；日活 / 周活粘性使用各自的滚动活跃窗口，不做简单平均。</p>
      </Panel>

      <Panel title="访问时段分布" small="所选区间 · 按小时累计 PV">
        <HoursChart :hours="traffic.hours" />
      </Panel>
    </template>
    <div v-else class="traffic-empty" role="status">
      <h2>所选区间暂无数据</h2>
      <p>请选择 {{ trafficCoverage.from }} 至 {{ trafficCoverage.to }} 内的日期，或切换天 / 周 / 月。</p>
    </div>
  </section>
</template>
