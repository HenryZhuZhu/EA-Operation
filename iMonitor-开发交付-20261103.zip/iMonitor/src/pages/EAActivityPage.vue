<script setup lang="ts">
import { computed, reactive, ref } from 'vue'
import { RouterLink } from 'vue-router'
import PeriodControl from '@/components/PeriodControl.vue'
import DataFreshness from '@/components/DataFreshness.vue'
import KpiCard from '@/components/KpiCard.vue'
import MemberStatusFilter from '@/components/MemberStatusFilter.vue'
import { periodState } from '@/stores/period'
import { liveTick } from '@/data/umami'
import { activityStats, eaActivity, eaTeams, hoursText, teamChildren, teamPath } from '@/data/eaOverview'
import type { ActivityRow, EATeam } from '@/data/eaOverview'
import { activeUserDefinition, trafficMetricLabels } from '@/data/metrics'

const st = periodState.overview
const rows = computed(() => (liveTick.value, eaActivity(st)))
const stats = computed(() => activityStats(rows.value))
const departments = computed(() => [...new Set(rows.value.filter(row => row.logged).map(row => teamPath(row.user.teamId)[0]))])
const query = ref(''), performance = ref('all'), memberMode = ref('all'), activeTeam = ref<string | null>(null)
const expanded = reactive(new Set<string>())
const limits = reactive(new Map<string, number>())
type SortKey = 'durationMinutes' | 'casesCreated' | 'casesModified' | 'tasksEdited' | 'lastUse'
const sorts = reactive(new Map<string, { key: SortKey; ascending: boolean }>())
const columns: { key: SortKey; label: string }[] = [
  { key: 'durationMinutes', label: '使用时长' }, { key: 'casesCreated', label: '创建 Case' },
  { key: 'casesModified', label: '修改 Case' }, { key: 'tasksEdited', label: '编辑任务' }, { key: 'lastUse', label: '最后使用' },
]
const byTeam = computed(() => {
  const map = new Map(eaTeams.map(team => [team.id, [] as ActivityRow[]]))
  const parents = new Map(eaTeams.map(team => [team.id, team.parentId]))
  for (const row of rows.value) {
    let id: string | null = row.user.teamId
    while (id) { map.get(id)!.push(row); id = parents.get(id) ?? null }
  }
  return map
})
type Stats = ReturnType<typeof activityStats>
interface TeamNode { team: EATeam; depth: number; stats: Stats; members: ActivityRow[]; children: TeamNode[] }
const tree = computed(() => {
  const q = query.value.trim().toLowerCase()
  function build(parent: string | null, depth: number): TeamNode[] {
    return teamChildren(parent).flatMap(team => {
      const members = byTeam.value.get(team.id)!, stats = activityStats(members), children = build(team.id, depth + 1)
      const teamMatches = !q || teamPath(team.id).join(' ').toLowerCase().includes(q)
      const matching = teamMatches ? members : members.filter(row => `${row.user.name} ${row.user.id}`.toLowerCase().includes(q))
      const performanceMatches = performance.value === 'all' || (performance.value === 'low-active' ? stats.loginRate < 50
        : performance.value === 'low-edit' ? stats.editRate < 25 : stats.loginRate >= 50)
      return children.length || matching.length && performanceMatches ? [{ team, depth, stats, members: matching, children }] : []
    })
  }
  return build(null, 0)
})
const filtering = computed(() => Boolean(query.value.trim()) || performance.value !== 'all')
const nodes = computed(() => {
  const flat: TeamNode[] = []
  function visit(items: TeamNode[]) {
    for (const item of items) {
      flat.push(item)
      if (expanded.has(item.team.id) || filtering.value) visit(item.children)
    }
  }
  visit(tree.value)
  return flat
})
const isLeaf = (id: string) => !teamChildren(id).length
const isExpanded = (node: TeamNode) => expanded.has(node.team.id) || filtering.value && (node.children.length > 0 || Boolean(query.value.trim()))
function toggle(node: TeamNode) {
  if (expanded.has(node.team.id)) {
    expanded.delete(node.team.id)
    if (activeTeam.value === node.team.id) activeTeam.value = null
  } else {
    expanded.add(node.team.id)
    if (isLeaf(node.team.id)) activeTeam.value = node.team.id
  }
}
function members(node: TeamNode) {
  const result = node.members.filter(row => memberMode.value !== 'inactive' || !row.logged)
  const sort = sorts.get(node.team.id)
  return result.sort((a, b) => {
    if (!sort) return Number(b.logged) - Number(a.logged) || a.user.name.localeCompare(b.user.name, 'zh-CN')
    const av = a[sort.key] ?? '', bv = b[sort.key] ?? ''
    const compare = typeof av === 'number' && typeof bv === 'number' ? av - bv : String(av).localeCompare(String(bv))
    return compare * (sort.ascending ? 1 : -1) || a.user.name.localeCompare(b.user.name, 'zh-CN')
  })
}
function sortMembers(key: SortKey) {
  if (!activeTeam.value) return
  const current = sorts.get(activeTeam.value)
  sorts.set(activeTeam.value, { key, ascending: current?.key === key ? !current.ascending : false })
  limits.set(activeTeam.value, 12)
}
const activeTeamName = computed(() => eaTeams.find(team => team.id === activeTeam.value)?.name)
function sortArrow(key: SortKey) {
  const sort = activeTeam.value ? sorts.get(activeTeam.value) : null
  return sort?.key === key ? sort.ascending ? '↑' : '↓' : '↕'
}
</script>

<template>
  <section class="page active ea-activity-page">
    <RouterLink class="btn ea-back" to="/overview">← 返回运营总览</RouterLink>
    <div class="head"><h1>用户活跃明细</h1><PeriodControl target="overview"><DataFreshness /></PeriodControl></div>
    <div class="ea-activity-summary kpis trio">
      <KpiCard :label="trafficMetricLabels.uv" :value="`${stats.logged.toLocaleString()}<small> / ${stats.total.toLocaleString()} 人</small>`" :calc="`${activeUserDefinition} · 活跃率 ${stats.loginRate}%`" />
      <KpiCard label="编辑内容用户" :value="`${stats.edited.toLocaleString()}<small> / ${stats.logged.toLocaleString()} 人</small>`" :calc="`占${trafficMetricLabels.uv} ${stats.editRate}%`" />
      <KpiCard label="覆盖部门" :value="`${departments.length}<small> 个</small>`" :calc="departments.join(' / ') || '—'" />
    </div>
    <div class="ea-activity-panel">
      <div class="ea-activity-toolbar">
        <input v-model="query" type="search" placeholder="搜索团队或成员" aria-label="搜索团队或成员">
        <select v-model="performance" aria-label="团队使用率筛选"><option value="all">全部团队</option><option value="low-active">低使用率团队</option><option value="low-edit">低编辑率团队</option><option value="high-active">高使用率团队</option></select>
      </div>
      <div class="ea-team-table">
        <div class="ea-team-grid ea-team-header">
          <span>团队 / 姓名 <small v-if="activeTeamName">{{ activeTeamName }}</small></span>
          <MemberStatusFilter v-model="memberMode" />
          <button v-for="column in columns" :key="column.key" type="button" :disabled="!activeTeam" :title="activeTeam ? `排序 ${activeTeamName} 成员` : '请先展开一个末级团队'" @click="sortMembers(column.key)">{{ column.label }} {{ sortArrow(column.key) }}</button>
        </div>
        <div class="ea-team-list">
          <template v-for="node in nodes" :key="node.team.id">
            <button type="button" class="ea-team-grid ea-team-row" :class="{ low: node.stats.loginRate < 50 }" :style="{ '--depth': node.depth }" :aria-label="`${isExpanded(node) ? '收起' : '展开'} ${node.team.name}`" :aria-expanded="isExpanded(node)" @click="toggle(node)">
              <span class="ea-team-name"><i :class="{ expanded: isExpanded(node) }">›</i><b>{{ node.team.name }}</b><span><strong>{{ node.stats.logged.toLocaleString() }}</strong> / {{ node.stats.total.toLocaleString() }}</span><small>{{ node.stats.loginRate }}%</small></span>
              <span class="ea-member-state" :class="{ inactive: node.stats.loginRate < 50 }">{{ node.stats.loginRate < 50 ? '低使用' : '正常' }}</span>
              <span>{{ hoursText(node.stats.avgMinutes / 60) }}<small>人均</small></span>
              <span>{{ node.stats.casesCreated.toLocaleString() }}</span><span>{{ node.stats.casesModified.toLocaleString() }}</span><span>{{ node.stats.tasksEdited.toLocaleString() }}</span><span>{{ node.stats.lastUse?.slice(5) ?? '—' }}</span>
            </button>
            <div v-if="isLeaf(node.team.id) && isExpanded(node)" class="ea-member-panel" :class="{ selected: activeTeam === node.team.id }" @click="activeTeam = node.team.id">
              <div v-for="row in members(node).slice(0, limits.get(node.team.id) ?? 12)" :key="row.user.id" class="ea-team-grid ea-member-row" :style="{ '--depth': node.depth }">
                <span class="ea-member-name"><b>{{ row.user.name }}</b><small>{{ row.user.id }}</small></span>
                <span class="ea-member-state" :class="{ inactive: !row.logged }">{{ row.logged ? '活跃' : '未使用' }}</span>
                <span>{{ hoursText(row.durationMinutes / 60) }}</span><span>{{ row.casesCreated.toLocaleString() }}</span><span>{{ row.casesModified.toLocaleString() }}</span><span>{{ row.tasksEdited.toLocaleString() }}</span><span>{{ row.lastUse?.slice(5) ?? '—' }}</span>
              </div>
              <p v-if="!members(node).length" class="ea-empty" role="status">没有匹配成员</p>
              <button v-if="members(node).length > (limits.get(node.team.id) ?? 12)" class="ea-load-more" type="button" @click="limits.set(node.team.id, (limits.get(node.team.id) ?? 12) + 12)">加载更多 · 还有 {{ members(node).length - (limits.get(node.team.id) ?? 12) }} 人</button>
            </div>
          </template>
          <p v-if="!nodes.length" class="ea-empty" role="status">未找到匹配团队或成员</p>
        </div>
      </div>
    </div>
  </section>
</template>
