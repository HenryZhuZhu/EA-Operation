<script setup lang="ts">
import { computed, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { caseRatingRecords } from '@/data/caseScore'

const route = useRoute()
const router = useRouter()
const shareStatus = ref('')
const radarHover = ref<number | null>(null)
const record = computed(() => caseRatingRecords.find((item) => item.id === route.params.id))

const grade = computed(() => {
  const score = record.value?.aiScore
  if (score === null || score === undefined) return '未出分'
  return score >= 90 ? '优秀' : score >= 80 ? '良好' : score >= 70 ? '需改进' : '风险'
})

const weightedRows = computed(() => (record.value?.dimensions ?? []).map((dimension) => ({
  ...dimension,
  weighted: +(dimension.score * ((dimension.weight ?? 0) / 100)).toFixed(2),
})))

const radarCenter = { x: 210, y: 150 }
const radarRadius = 102
const radarPoint = (index: number, value = 100, extra = 0) => {
  const angle = -Math.PI / 2 + index * Math.PI / 3
  const radius = radarRadius * value / 100 + extra
  return { x: radarCenter.x + Math.cos(angle) * radius, y: radarCenter.y + Math.sin(angle) * radius }
}
const pointString = (points: { x: number; y: number }[]) => points.map((point) => `${point.x.toFixed(1)},${point.y.toFixed(1)}`).join(' ')
const radarGrid = computed(() => [20, 40, 60, 80, 100].map((level) => ({
  level,
  points: pointString(Array.from({ length: 6 }, (_, index) => radarPoint(index, level))),
})))
const radarAxes = computed(() => (record.value?.dimensions ?? []).map((dimension, index) => {
  const axis = radarPoint(index)
  const point = radarPoint(index, dimension.score)
  const label = radarPoint(index, 100, 27)
  const labels = ['问题定义', '思路假设', '任务协作', '证据留痕', '推理结论', '闭环复用']
  return { axis, point, label, text: labels[index], score: dimension.score }
}))
const radarData = computed(() => pointString(radarAxes.value.map((axis) => axis.point)))
const radarHoverRow = computed(() => radarHover.value === null ? null : weightedRows.value[radarHover.value] ?? null)
const strongest = computed(() => record.value?.dimensions.slice().sort((a, b) => b.score - a.score)[0])
const weakest = computed(() => record.value?.dimensions.slice().sort((a, b) => a.score - b.score)[0])
const abilitySpread = computed(() => strongest.value && weakest.value ? strongest.value.score - weakest.value.score : 0)

const recommendations = computed(() => {
  if (!record.value) return []
  const deductionActions = record.value.deductions.map((deduction) => `补齐「${deduction.label}」：${deduction.detail}`)
  const dimensionActions = record.value.dimensions
    .filter((dimension) => dimension.score < 85)
    .sort((a, b) => a.score - b.score)
    .slice(0, 3)
    .map((dimension) => `提升「${dimension.label}」：${dimension.finding}`)
  return [...deductionActions, ...dimensionActions].slice(0, 6)
})

function back() { router.push('/case-score') }
async function shareReport() {
  if (!record.value) return
  const shareData = {
    title: `${record.value.code} · Case AI 评分报告`,
    text: `${record.value.title}，AI 综合评分 ${record.value.aiScore}/100`,
    url: window.location.href,
  }
  try {
    if (navigator.share) {
      await navigator.share(shareData)
      shareStatus.value = '已分享'
    } else {
      await navigator.clipboard.writeText(shareData.url)
      shareStatus.value = '链接已复制'
    }
  } catch (error) {
    if ((error as Error).name !== 'AbortError') shareStatus.value = '分享失败'
  }
  if (shareStatus.value) window.setTimeout(() => (shareStatus.value = ''), 1800)
}
</script>

<template>
  <section class="page active score-report-page">
    <template v-if="record && record.aiState === '已完成'">
      <div class="report-top-actions">
        <button class="btn back-link" @click="back">← 返回 Case评分</button>
        <span v-if="shareStatus" class="report-share-status">{{ shareStatus }}</span>
        <button class="btn report-share" @click="shareReport">分享</button>
      </div>

      <header class="score-report-header">
        <div class="score-report-heading">
          <span>AI CASE QUALITY REPORT</span>
          <h1>Case AI 评分报告</h1>
          <p>{{ record.code }} · {{ record.title }}</p>
        </div>
        <div class="score-report-result">
          <span>AI 综合评分</span>
          <b>{{ record.aiScore }}</b>
          <small>/ 100 · {{ grade }}</small>
        </div>
      </header>

      <div class="report-meta-grid">
        <div><span>产品</span><b>{{ record.product }}</b></div>
        <div><span>Owner / 部门</span><b>{{ record.owner }} / {{ record.department }}</b></div>
        <div><span>Case 状态</span><b>{{ record.lifecycle }}</b></div>
        <div><span>层级 / 紧急度</span><b>{{ record.level }} / {{ record.urgency }}</b></div>
        <div><span>评分生成时间</span><b>{{ record.generatedAt }}</b></div>
        <div><span>AI 状态</span><b>{{ record.aiState }}</b></div>
      </div>

      <section class="report-section report-summary">
        <div class="report-section-title"><span>01</span><h2>综合结论</h2></div>
        <p>{{ record.aiSummary }}</p>
        <div class="report-trace-row">
          <span>任务 {{ record.completedTasks }} / {{ record.totalTasks }}</span>
          <span v-if="record.issueCode">Issue {{ record.issueCode }}</span>
          <span v-if="record.checklist">Checklist {{ record.checklist }}</span>
          <span v-if="record.fanoutSource">Fanout 源 Case {{ record.fanoutSource }}</span>
          <span>来源 {{ record.source }}</span>
        </div>
      </section>

      <section class="report-section">
        <div class="report-section-title"><span>02</span><h2>六维能力雷达</h2><small>Hover 数据点查看权重、加权得分与逐项评价</small></div>
        <div class="report-radar-layout">
          <div class="report-radar-chart" @mouseleave="radarHover = null">
            <svg class="report-radar" viewBox="0 0 420 310" role="img" aria-label="六维能力雷达图">
              <polygon v-for="grid in radarGrid" :key="grid.level" :points="grid.points" class="report-radar-grid" />
              <line v-for="(axis, index) in radarAxes" :key="'axis-' + index" :x1="radarCenter.x" :y1="radarCenter.y" :x2="axis.axis.x" :y2="axis.axis.y" class="report-radar-axis" />
              <polygon :points="radarData" class="report-radar-data" />
              <circle v-for="(axis, index) in radarAxes" :key="'point-' + index" :cx="axis.point.x" :cy="axis.point.y" r="3.5" class="report-radar-point" />
              <g v-for="(axis, index) in radarAxes" :key="'label-' + index">
                <text :x="axis.label.x" :y="axis.label.y" text-anchor="middle" class="report-radar-label">{{ axis.text }}</text>
                <text :x="axis.label.x" :y="axis.label.y + 13" text-anchor="middle" class="report-radar-score">{{ axis.score }}</text>
              </g>
              <circle
                v-for="(axis, index) in radarAxes"
                :key="'hit-' + index"
                :cx="axis.point.x"
                :cy="axis.point.y"
                r="20"
                class="report-radar-hit"
                tabindex="0"
                :aria-label="`${weightedRows[index].label} ${axis.score} 分`"
                @mouseenter="radarHover = index"
                @focus="radarHover = index"
                @blur="radarHover = null"
              />
            </svg>
            <div
              v-if="radarHover !== null && radarHoverRow"
              class="report-radar-tip"
              :class="{ below: radarAxes[radarHover]?.point.y < 105 }"
              :style="{ left: `${(radarAxes[radarHover]?.point.x ?? 0) / 4.2}%`, top: `${(radarAxes[radarHover]?.point.y ?? 0) / 3.1}%` }"
            >
              <div><b>{{ radarHoverRow.label }}</b><strong>{{ radarHoverRow.score }}</strong></div>
              <div class="report-radar-tip-metrics">
                <span>权重 <b>{{ radarHoverRow.weight }}%</b></span>
                <span>加权得分 <b>{{ radarHoverRow.weighted.toFixed(2) }}</b></span>
              </div>
              <p>{{ radarHoverRow.finding }}</p>
            </div>
          </div>
          <div class="report-radar-insights">
            <div><span>最强维度</span><b>{{ strongest?.label }}</b><strong>{{ strongest?.score }}</strong></div>
            <div><span>优先提升</span><b>{{ weakest?.label }}</b><strong>{{ weakest?.score }}</strong></div>
            <div><span>能力差值</span><b>最高分 − 最低分</b><strong>{{ abilitySpread }}</strong></div>
          </div>
        </div>
      </section>

      <section class="report-section report-two-columns">
        <div>
          <div class="report-section-title"><span>03</span><h2>具体失分依据</h2></div>
          <div class="report-deduction-list">
            <div v-for="deduction in record.deductions" :key="deduction.label">
              <span>-{{ deduction.points }}</span><article><h3>{{ deduction.label }}</h3><p>{{ deduction.detail }}</p></article>
            </div>
          </div>
        </div>
        <div>
          <div class="report-section-title"><span>04</span><h2>改进建议</h2></div>
          <ol class="report-recommendations"><li v-for="item in recommendations" :key="item">{{ item }}</li></ol>
        </div>
      </section>

      <footer class="score-report-footer">
        <span>本报告由 EA AI 根据 Case 当前快照自动生成</span>
        <span>评分只评价可归因的工程内容</span>
      </footer>
    </template>

    <div v-else class="report-not-found">
      <h1>暂无可查看的评分报告</h1>
      <p>该 Case 尚未完成 AI 评分，或 Case 不存在。</p>
      <button class="btn primary" @click="back">返回 Case评分</button>
    </div>
  </section>
</template>