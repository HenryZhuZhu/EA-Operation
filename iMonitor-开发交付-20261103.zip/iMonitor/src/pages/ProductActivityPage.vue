<script setup lang="ts">
import { computed, reactive, ref } from 'vue'
import { RouterLink, useRoute } from 'vue-router'
import PeriodControl from '@/components/PeriodControl.vue'
import KpiCard from '@/components/KpiCard.vue'
import MemberStatusFilter from '@/components/MemberStatusFilter.vue'
import { findProduct, findSubproduct, productTrafficDetails, trafficCoverage } from '@/data/products'
import type { ProductTrafficUser } from '@/data/products'
import { teams, teamChildren, teamPath } from '@/data/teams'
import type { Team } from '@/data/teams'
import { activeUserDefinition, trafficMetricLabels } from '@/data/metrics'
import { periodState } from '@/stores/period'

const route = useRoute()
const product = computed(() => findProduct(route.params.productId)!)
const subproduct = computed(() => findSubproduct(product.value, route.params.subproductId))
const overviewPath = computed(() => `/product/${product.value.id}${subproduct.value ? '/' + subproduct.value.id : ''}`)
const detail = computed(() => productTrafficDetails(product.value, periodState.productTraffic, subproduct.value?.id))
const traffic = computed(() => detail.value.traffic)
const query = ref(''), performance = ref('all'), memberMode = ref('all'), activeTeam = ref<string | null>(null)
const expanded = reactive(new Set<string>())
const limits = reactive(new Map<string, number>())
type SortKey = 'pv' | 'visits' | 'minutes' | 'lastUse'
const sorts = reactive(new Map<string, { key: SortKey; ascending: boolean }>())
const columns: { key: SortKey; label: string }[] = [
  { key: 'pv', label: trafficMetricLabels.pv }, { key: 'visits', label: '访问会话' },
  { key: 'minutes', label: '累计访问时长' }, { key: 'lastUse', label: '最后访问' },
]
function summarize(users: ProductTrafficUser[]) {
  const active = users.filter(user => user.pv > 0).length
  return {
    total: users.length, active, rate: users.length ? Math.round(active / users.length * 100) : 0,
    pv: users.reduce((sum, user) => sum + user.pv, 0), visits: users.reduce((sum, user) => sum + user.visits, 0),
    minutes: users.reduce((sum, user) => sum + user.minutes, 0),
    lastUse: users.reduce<string | null>((last, user) => user.lastUse && (!last || user.lastUse > last) ? user.lastUse : last, null),
  }
}
const stats = computed(() => summarize(detail.value.users))
const departments = computed(() => [...new Set(detail.value.users.filter(user => user.pv > 0).map(user => teamPath(user.teamId)[0]))])
const byTeam = computed(() => {
  const map = new Map(teams.map(team => [team.id, [] as ProductTrafficUser[]]))
  const parents = new Map(teams.map(team => [team.id, team.parentId]))
  for (const user of detail.value.users) {
    let id: string | null = user.teamId
    while (id) { map.get(id)!.push(user); id = parents.get(id) ?? null }
  }
  return map
})
interface TeamNode { team: Team; depth: number; stats: ReturnType<typeof summarize>; members: ProductTrafficUser[]; children: TeamNode[] }
const tree = computed(() => {
  const q = query.value.trim().toLowerCase()
  function build(parent: string | null, depth: number): TeamNode[] {
    return teamChildren(parent).flatMap(team => {
      const users = byTeam.value.get(team.id)!, stats = summarize(users), children = build(team.id, depth + 1)
      const matchesTeam = !q || teamPath(team.id).join(' ').toLowerCase().includes(q)
      const members = matchesTeam ? users : users.filter(user => `${user.name} ${user.id}`.toLowerCase().includes(q))
      const matchesRate = performance.value === 'all' || (performance.value === 'low-active' ? stats.rate < 50 : stats.rate >= 50)
      return children.length || members.length && matchesRate ? [{ team, depth, stats, members, children }] : []
    })
  }
  return build(null, 0)
})
const filtering = computed(() => Boolean(query.value.trim()) || performance.value !== 'all')
const nodes = computed(() => {
  const result: TeamNode[] = []
  function visit(items: TeamNode[]) {
    for (const item of items) {
      result.push(item)
      if (expanded.has(item.team.id) || filtering.value) visit(item.children)
    }
  }
  visit(tree.value)
  return result
})
const isLeaf = (id: string) => !teamChildren(id).length
const isExpanded = (node: TeamNode) => expanded.has(node.team.id) || filtering.value && (node.children.length > 0 || Boolean(query.value.trim()))
function toggle(node: TeamNode) {
  if (expanded.has(node.team.id)) {
    expanded.delete(node.team.id)
    if (activeTeam.value === node.team.id) activeTeam.value = null
  } else {
    expanded.add(node.team.id)
    if (isLeaf(node.team.id)) activeTeam.value = node.team.id
  }
}
function members(node: TeamNode) {
  const result = node.members.filter(user => memberMode.value !== 'inactive' || user.pv === 0)
  const sort = sorts.get(node.team.id)
  return result.sort((a, b) => {
    if (!sort) return Number(b.pv > 0) - Number(a.pv > 0) || a.id.localeCompare(b.id)
    const av = a[sort.key] ?? '', bv = b[sort.key] ?? ''
    const compare = typeof av === 'number' && typeof bv === 'number' ? av - bv : String(av).localeCompare(String(bv))
    return compare * (sort.ascending ? 1 : -1) || a.id.localeCompare(b.id)
  })
}
function sortMembers(key: SortKey) {
  if (!activeTeam.value) return
  const current = sorts.get(activeTeam.value)
  sorts.set(activeTeam.value, { key, ascending: current?.key === key ? !current.ascending : false })
  limits.set(activeTeam.value, 12)
}
function sortArrow(key: SortKey) {
  const sort = activeTeam.value ? sorts.get(activeTeam.value) : null
  return sort?.key === key ? sort.ascending ? '↑' : '↓' : '↕'
}
const activeTeamName = computed(() => teams.find(team => team.id === activeTeam.value)?.name)
const duration = (minutes: number) => `${+(minutes / 60).toFixed(2)}h`
</script>

<template>
  <section class="page active ea-activity-page product-activity-page">
    <RouterLink class="btn ea-back" :to="overviewPath">← 返回运营总览</RouterLink>
    <div class="head"><h1>{{ trafficMetricLabels.uv }}</h1><PeriodControl target="productTraffic" /></div>
    <div v-if="traffic.partial" class="src-note" role="status">所选区间超出可用数据范围，仅统计有数据的日期。</div>
    <template v-if="traffic.selected.length">
      <div class="ea-activity-summary kpis trio">
        <KpiCard :label="trafficMetricLabels.uv" :value="`${stats.active.toLocaleString()}<small> / ${stats.total.toLocaleString()} 人</small>`" :calc="`${activeUserDefinition} · 活跃率 ${stats.rate}%`" />
        <KpiCard label="未使用用户" :value="stats.total - stats.active" :calc="`当前范围用户总数 - ${trafficMetricLabels.uv}`" />
        <KpiCard label="覆盖部门" :value="`${departments.length}<small> 个</small>`" :calc="departments.join(' / ') || '—'" />
      </div>
      <div class="ea-activity-panel">
        <div class="ea-activity-toolbar">
          <input v-model="query" type="search" placeholder="搜索团队或成员" aria-label="搜索团队或成员">
          <select v-model="performance" aria-label="团队使用率筛选"><option value="all">全部团队</option><option value="low-active">低使用率团队</option><option value="high-active">高使用率团队</option></select>
        </div>
        <div class="ea-team-table" role="region" aria-label="团队与成员访问明细" tabindex="0">
          <div class="ea-team-grid product-team-grid ea-team-header">
            <span>团队 / 姓名 <small v-if="activeTeamName">{{ activeTeamName }}</small></span>
            <MemberStatusFilter v-model="memberMode" />
            <button v-for="column in columns" :key="column.key" type="button" :disabled="!activeTeam" :title="activeTeam ? `排序 ${activeTeamName} 成员` : '请先展开一个末级团队'" @click="sortMembers(column.key)">{{ column.label }} {{ sortArrow(column.key) }}</button>
          </div>
          <div class="ea-team-list">
            <template v-for="node in nodes" :key="node.team.id">
              <button type="button" class="ea-team-grid product-team-grid ea-team-row" :class="{ low: node.stats.rate < 50 }" :style="{ '--depth': node.depth }" :aria-label="`${isExpanded(node) ? '收起' : '展开'} ${node.team.name}`" :aria-expanded="isExpanded(node)" @click="toggle(node)">
                <span class="ea-team-name"><i :class="{ expanded: isExpanded(node) }">›</i><b>{{ node.team.name }}</b><span><strong>{{ node.stats.active.toLocaleString() }}</strong> / {{ node.stats.total.toLocaleString() }}</span><small>{{ node.stats.rate }}%</small></span>
                <span class="ea-member-state" :class="{ inactive: node.stats.rate < 50 }">{{ node.stats.rate < 50 ? '低使用' : '正常' }}</span>
                <span>{{ node.stats.pv.toLocaleString() }}</span><span>{{ node.stats.visits.toLocaleString() }}</span><span>{{ duration(node.stats.minutes) }}</span><span>{{ node.stats.lastUse ?? '—' }}</span>
              </button>
              <div v-if="isLeaf(node.team.id) && isExpanded(node)" class="ea-member-panel" :class="{ selected: activeTeam === node.team.id }" @click="activeTeam = node.team.id">
                <div v-for="user in members(node).slice(0, limits.get(node.team.id) ?? 12)" :key="user.id" class="ea-team-grid product-team-grid ea-member-row" :style="{ '--depth': node.depth }">
                  <span class="ea-member-name"><b>{{ user.name }}</b><small>{{ user.id }}</small></span>
                  <span class="ea-member-state" :class="{ inactive: !user.pv }">{{ user.pv ? '活跃' : '未使用' }}</span>
                  <span>{{ user.pv.toLocaleString() }}</span><span>{{ user.visits.toLocaleString() }}</span><span>{{ duration(user.minutes) }}</span><span>{{ user.lastUse ?? '—' }}</span>
                </div>
                <p v-if="!members(node).length" class="ea-empty" role="status">没有匹配成员</p>
                <button v-if="members(node).length > (limits.get(node.team.id) ?? 12)" class="ea-load-more" type="button" @click="limits.set(node.team.id, (limits.get(node.team.id) ?? 12) + 12)">加载更多 · 还有 {{ members(node).length - (limits.get(node.team.id) ?? 12) }} 人</button>
              </div>
            </template>
            <p v-if="!nodes.length" class="ea-empty" role="status">未找到匹配团队或成员</p>
          </div>
        </div>
      </div>
    </template>
    <div v-else class="traffic-empty" role="status"><h2>所选区间暂无数据</h2><p>请选择 {{ trafficCoverage.from }} 至 {{ trafficCoverage.to }} 内的日期，或切换天 / 周 / 月。</p></div>
  </section>
</template>
