<script setup lang="ts">
import { computed, ref } from 'vue'
import { RouterLink, useRoute } from 'vue-router'
import PeriodControl from '@/components/PeriodControl.vue'
import KpiCard from '@/components/KpiCard.vue'
import Panel from '@/components/Panel.vue'
import Sparkline from '@/components/Sparkline.vue'
import { findProduct, findSubproduct, productTrafficDetails, trafficCoverage } from '@/data/products'
import { trafficMetricLabels } from '@/data/metrics'
import { periodState } from '@/stores/period'

const route = useRoute()
const product = computed(() => findProduct(route.params.productId)!)
const subproduct = computed(() => findSubproduct(product.value, route.params.subproductId))
const overviewPath = computed(() => `/product/${product.value.id}${subproduct.value ? '/' + subproduct.value.id : ''}`)
const detail = computed(() => productTrafficDetails(product.value, periodState.productTraffic, subproduct.value?.id))
const traffic = computed(() => detail.value.traffic)
const query = ref(''), scopeFilter = ref(''), pageId = ref<string | null>(null)
const averagePagePV = computed(() => detail.value.pages.length ? (traffic.value.pv / detail.value.pages.length).toFixed(1) : '0.0')
type SortKey = 'pv' | 'uv' | 'lastUse'
const sortKey = ref<SortKey>('pv'), ascending = ref(false)
const columns: { key: SortKey; label: string }[] = [
  { key: 'pv', label: trafficMetricLabels.pv }, { key: 'uv', label: trafficMetricLabels.uv }, { key: 'lastUse', label: '最后访问' },
]
const pages = computed(() => {
  const q = query.value.trim().toLowerCase()
  return detail.value.pages.filter(page => (!scopeFilter.value || page.scopeId === scopeFilter.value)
    && `${page.name} ${page.path}`.toLowerCase().includes(q)).sort((a, b) => {
      const av = a[sortKey.value] ?? '', bv = b[sortKey.value] ?? ''
      const compare = typeof av === 'number' && typeof bv === 'number' ? av - bv : String(av).localeCompare(String(bv))
      return compare * (ascending.value ? 1 : -1) || a.id.localeCompare(b.id)
    })
})
const selectedPage = computed(() => pages.value.find(page => page.id === pageId.value))
const labels = computed(() => traffic.value.selected.map(day => day.date))
const series = computed(() => selectedPage.value?.dailyPV ?? traffic.value.selected.map(day => day.pv))
function sort(key: SortKey) {
  ascending.value = sortKey.value === key ? !ascending.value : false
  sortKey.value = key
}
function select(id: string) { pageId.value = pageId.value === id ? null : id }
</script>

<template>
  <section class="page active ea-activity-page product-pageviews-page">
    <RouterLink class="btn ea-back" :to="overviewPath">← 返回运营总览</RouterLink>
    <div class="head"><h1>{{ trafficMetricLabels.pv }}</h1><PeriodControl target="productTraffic" /></div>
    <div v-if="traffic.partial" class="src-note" role="status">所选区间超出可用数据范围，仅统计有数据的日期。</div>
    <template v-if="traffic.selected.length">
      <div class="ea-activity-summary kpis trio">
        <KpiCard :label="trafficMetricLabels.pv" :value="traffic.pv" calc="所选区间内页面浏览总次数" />
        <KpiCard label="访问页面 / 功能" :value="`${detail.pages.length}<small> 个</small>`" calc="所选区间内发生访问的页面 / 功能数" />
        <KpiCard label="平均每页浏览量" :value="`${averagePagePV}<small> 次 / 页</small>`" calc="页面浏览总次数 / 有访问的页面或功能数" />
      </div>
      <Panel title="页面访问趋势" :small="selectedPage?.name ?? '全部页面 / 功能'">
        <template #ph-extra><button v-if="selectedPage" type="button" class="btn product-trend-reset" @click="pageId = null">显示全部页面</button></template>
        <Sparkline v-if="series.length > 1" :series="series" :labels="labels" :width="1000" :height="130" />
        <p v-else class="traffic-single-day">当日 PV {{ series[0]?.toLocaleString() ?? 0 }}，切换周 / 月查看多日趋势。</p>
        <div class="traffic-axis"><span>{{ labels[0] }}</span><span>{{ labels[labels.length - 1] }}</span></div>
      </Panel>
      <div class="ea-activity-panel product-pages-panel">
        <div class="ea-activity-toolbar">
          <input v-model="query" type="search" placeholder="搜索页面或功能" aria-label="搜索页面或功能">
          <select v-if="product.subproducts.length && !subproduct" v-model="scopeFilter" :aria-label="product.id === 'product-space' ? '模块筛选' : '子产品筛选'">
            <option value="">{{ product.id === 'product-space' ? '全部模块' : '全部子产品' }}</option>
            <option v-for="scope in product.subproducts" :key="scope.id" :value="scope.id">{{ scope.name }}</option>
          </select>
        </div>
        <div class="product-detail-scroll" role="region" aria-label="页面与功能访问明细" tabindex="0">
          <table class="subproduct-traffic-table product-pages-table">
            <thead><tr>
              <th>页面 / 功能</th>
              <th v-for="column in columns" :key="column.key" :aria-sort="sortKey === column.key ? ascending ? 'ascending' : 'descending' : 'none'">
                <button type="button" class="product-sort-button" @click="sort(column.key)">{{ column.label }} {{ sortKey === column.key ? ascending ? '↑' : '↓' : '↕' }}</button>
              </th>
              <th>PV 占比</th>
            </tr></thead>
            <tbody><tr v-for="page in pages" :key="page.id" :class="{ 'product-page-selected': selectedPage?.id === page.id }">
              <td><button class="product-page-link" type="button" :aria-pressed="selectedPage?.id === page.id" :aria-label="`查看 ${page.name} 访问趋势`" @click="select(page.id)">{{ page.name }} ↗</button><small class="product-page-path">{{ page.path }}</small></td>
              <td class="tn">{{ page.pv.toLocaleString() }}</td><td class="tn">{{ page.uv.toLocaleString() }}</td><td>{{ page.lastUse }}</td>
              <td><div class="product-page-share"><b class="tn">{{ page.share }}%</b><div class="subproduct-share"><span :style="{ width: page.share + '%' }"></span></div></div></td>
            </tr></tbody>
          </table>
          <p v-if="!pages.length" class="ea-empty" role="status">未找到匹配页面或功能</p>
        </div>
      </div>
    </template>
    <div v-else class="traffic-empty" role="status"><h2>所选区间暂无数据</h2><p>请选择 {{ trafficCoverage.from }} 至 {{ trafficCoverage.to }} 内的日期，或切换天 / 周 / 月。</p></div>
  </section>
</template>
