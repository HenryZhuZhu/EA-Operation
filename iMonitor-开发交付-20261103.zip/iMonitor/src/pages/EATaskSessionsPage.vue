<script setup lang="ts">
import { computed, onUnmounted, ref, watch } from 'vue'
import { RouterLink, useRoute } from 'vue-router'
import { periodState } from '@/stores/period'
import { eaMetricProducts, hoursText, taskSessions } from '@/data/eaOverview'

const route = useRoute()
const source = computed(() => route.path.slice(0, route.path.indexOf('/task/')))
const context = computed(() => {
  for (const product of eaMetricProducts(periodState.overview)) {
    for (const item of product.cases) {
      const task = item.tasks.find(task => task.id === route.params.taskId)
      if (task) return { product: product.product, task }
    }
  }
  return undefined
})
const task = computed(() => {
  const current = context.value?.task
  return current && source.value === '/overview/closure' ? { ...current, ai: false } : current
})
const sessions = computed(() => task.value ? taskSessions(task.value) : [])
const index = ref(0), position = ref(0), speed = ref(1), playing = ref(false)
const session = computed(() => sessions.value[index.value])
const activeEvent = computed(() => session.value?.events.filter(event => event.at <= position.value).slice(-1)[0])
let timer: ReturnType<typeof setInterval> | undefined
function stop() { if (timer !== undefined) clearInterval(timer); timer = undefined; playing.value = false }
function choose(value: number) { stop(); index.value = value; position.value = 0 }
function play() {
  if (playing.value) { stop(); return }
  if (!session.value) return
  if (position.value >= session.value.duration) position.value = 0
  playing.value = true
  timer = setInterval(() => {
    position.value = Math.min(session.value!.duration, position.value + 0.25 * speed.value)
    if (position.value >= session.value!.duration) stop()
  }, 250)
}
function clock(seconds: number) {
  const value = Math.floor(seconds)
  return `${String(Math.floor(value / 3600)).padStart(2, '0')}:${String(Math.floor(value % 3600 / 60)).padStart(2, '0')}:${String(value % 60).padStart(2, '0')}`
}
watch(sessions, () => choose(0))
onUnmounted(stop)
</script>

<template>
  <section class="page active ea-sessions-page">
    <RouterLink class="btn ea-back" :to="source">← 返回指标详情</RouterLink>
    <div class="head"><div><h1>{{ task?.id ?? '任务不存在' }}</h1><p v-if="task">{{ context?.product }} · {{ task.caseId }} · {{ task.ai ? '执行者 AI' : '负责人 ' + task.owner }}</p></div></div>
    <p class="traffic-note">以下为原型中的 Session 行为演示，并非真实操作录像；尚未连接真实回放服务。</p>
    <div v-if="task" class="ea-session-workspace">
      <aside class="ea-session-list">
        <h3>任务关联 Session <small>{{ sessions.length }} 段</small></h3>
        <button v-for="(item, i) in sessions" :key="item.id" type="button" :class="{ active: index === i }" @click="choose(i)"><b>{{ item.id }}</b><span>{{ item.start.toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false }) }}</span><small>{{ hoursText(item.duration / 3600) }} · {{ item.events.length }} 个关键行为</small><strong>▶ 回放</strong></button>
      </aside>
      <div v-if="session" class="ea-session-player">
        <div class="ea-session-url">{{ session.url }}</div>
        <div class="ea-session-canvas">
          <div class="ea-session-screen"><small>Session 行为演示</small><h2>{{ activeEvent?.page ?? '准备回放' }}</h2><p>{{ activeEvent?.action ?? '点击播放查看关键行为' }}</p><code>{{ clock(position) }} / {{ clock(session.duration) }}</code></div>
        </div>
        <div class="ea-session-controls">
          <button type="button" class="btn" :aria-label="playing ? '暂停回放' : '播放回放'" @click="play">{{ playing ? '暂停' : '播放' }}</button>
          <span>{{ clock(position) }}</span><input v-model.number="position" type="range" min="0" :max="session.duration" aria-label="回放进度"><span>{{ clock(session.duration) }}</span>
          <select v-model.number="speed" aria-label="回放速度"><option :value="1">1×</option><option :value="2">2×</option><option :value="4">4×</option><option :value="8">8×</option></select>
        </div>
        <div class="ea-session-events"><button v-for="event in session.events" :key="event.at" type="button" :class="{ active: activeEvent === event }" @click="position = event.at"><code>{{ clock(event.at) }}</code><b>{{ event.action }}</b><small>{{ event.page }}</small></button></div>
      </div>
      <div v-else class="ea-empty" role="status"><h2>该任务无用户 Session 录像</h2><p>这是 AI 执行任务，可查看系统 Trace，但不存在工程师操作回放。</p></div>
    </div>
    <div v-else class="ea-empty" role="alert">未找到该任务，请返回指标详情重新选择。</div>
  </section>
</template>
