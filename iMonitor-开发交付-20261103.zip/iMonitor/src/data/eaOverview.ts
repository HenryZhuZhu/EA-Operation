import type { KpiTuple, PeriodState } from '@/types'
import { TODAY } from './mock'
import { ovDataFor, sparkDates, sparkSeries, trendHTML } from './compute'
import { trafficMetricLabels } from './metrics'
import { teamPath } from './teams'
export { teams as eaTeams, teamChildren, teamPath } from './teams'
export type { Team as EATeam } from './teams'

export type EAMetric = 'closure' | 'score' | 'human'
export interface EAPerson { name: string; teamId: string }
export interface EATask { id: string; caseId: string; owner: string; hours: number; rawHours: number; ai: boolean }
export interface EACase { id: string; days: number; score: number; owner: string; tasks: EATask[] }
export interface EAMember extends EAPerson { hours: number; tasks: number }
export interface EATeamMetric { id: string; name: string; hours: number; tasks: number; members: EAMember[] }
export interface EAProductMetric {
  product: string; platform: string; generation: string
  cases: EACase[]; hours: number; average: number; high: number
  tasks: number; ai: number; manual: number; ratio: number; teams: EATeamMetric[]
}

const leafSizes: Record<string, number> = { CP: 36, FT1: 20, FT2: 20, EFA1: 20, EFA2: 20, DA1: 16, DA2: 16, QA1: 18, QA2: 18, SAE: 36 }
const seeds: EAPerson[] = [
  { name: '王芳', teamId: 'CP' }, { name: '张伟', teamId: 'CP' }, { name: '刘洋', teamId: 'CP' }, { name: '周杰', teamId: 'CP' },
  { name: '郑洁', teamId: 'FT1' }, { name: '赵敏', teamId: 'FT2' }, { name: '陈磊', teamId: 'EFA1' }, { name: '吴昊', teamId: 'EFA2' },
  { name: '高洁', teamId: 'DA1' }, { name: '李娜', teamId: 'DA2' }, { name: '孙楠', teamId: 'SAE' }, { name: '林峰', teamId: 'SAE' },
]
const people = Object.entries(leafSizes).flatMap(([teamId, size]) => {
  const known = seeds.filter(person => person.teamId === teamId)
  return [...known, ...Array.from({ length: size - known.length }, (_, i) => ({ name: `${teamId}成员${String(i + 1).padStart(3, '0')}`, teamId }))]
})
const personByName = new Map(people.map(person => [person.name, person]))
const leafIds = Object.keys(leafSizes)
const teamBase: Record<string, number> = { CP: 24, FT1: 37, FT2: 24, EFA1: 48, EFA2: 40, DA1: 16, DA2: 27, QA1: 32, QA2: 38, SAE: 43 }
export const teamColors: Record<string, string> = { CP: '#0052D9', FT1: '#3B82F6', FT2: '#16A3C7', EFA1: '#008F6B', EFA2: '#55A630', DA1: '#E6A11A', DA2: '#E87522', QA1: '#D44C45', QA2: '#A95C4A', SAE: '#596574' }
export const eaProductDefinitions = [
  { product: 'Atlas-D4-3200', platform: 'G4', generation: 'DDR4', days: 10.8 },
  { product: 'Atlas-D4-3600', platform: 'G4B', generation: 'DDR4', days: 11.6 },
  { product: 'Nova-D5-5600', platform: 'G4B', generation: 'DDR5', days: 13.1 },
  { product: 'Nova-D5-6400', platform: 'G5', generation: 'DDR5', days: 14.8 },
  { product: 'Orion-D6-7200', platform: 'G5', generation: 'DDR6', days: 16.2 },
  { product: 'Orion-D6-8400', platform: 'V1', generation: 'DDR6', days: 17.4 },
  { product: 'Mobile-L4-4266', platform: 'G4', generation: 'LPDDR4', days: 9.2 },
  { product: 'Mobile-L4X-4266', platform: 'G4B', generation: 'LPDDR4', days: 10.1 },
  { product: 'Mobile-L5-6400', platform: 'G4B', generation: 'LPDDR5', days: 12.3 },
  { product: 'Mobile-L5X-7500', platform: 'G5', generation: 'LPDDR5', days: 13.6 },
  { product: 'Mobile-L7-9600', platform: 'V1', generation: 'LPDDR7', days: 15.7 },
  { product: 'Mobile-L7X-10667', platform: 'V1', generation: 'LPDDR7', days: 16.5 },
]
export const scoreBands = [
  { id: 'excellent', label: '优秀', color: '#30d158', min: 90, max: 101 },
  { id: 'good', label: '良好', color: '#3B82F6', min: 80, max: 90 },
  { id: 'improve', label: '需改进', color: '#E6A11A', min: 70, max: 80 },
  { id: 'risk', label: '风险', color: '#D44C45', min: 0, max: 70 },
]
const noise = (seed: number) => {
  const value = Math.sin(seed * 12.9898 + 78.233) * 43758.5453
  return value - Math.floor(value)
}
const seedOf = (value: string) => [...value].reduce((sum, char) => sum + char.charCodeAt(0), 0)
const round = (value: number) => +value.toFixed(1)
export const hoursText = (hours: number) => `${+hours.toFixed(2)}h`
export const daysText = (hours: number) => hours > 0 && hours / 24 < 0.01 ? '<0.01天' : `${+(hours / 24).toFixed(2)}天`

export function overviewKpi(kpi: KpiTuple, state: PeriodState) {
  const hours = kpi[0] === '平均结案时间' ? round(kpi[1] * 24)
    : kpi[0] === trafficMetricLabels.averageDuration ? +(kpi[1] / 60).toFixed(2) : null
  const value = hours ?? kpi[1]
  return {
    label: kpi[0], unit: hours === null ? kpi[2] : 'h', trend: kpi[4],
    value: `${value}<small>${hours === null ? kpi[2] : 'h'}</small>${hours === null ? '' : `<i class="duration-days">${daysText(hours).replace('<', '&lt;')}</i>`}${trendHTML(kpi[4])}`,
    calc: `<code>${kpi[3]}</code> · 同比`,
    series: sparkSeries(value, kpi[4], seedOf(kpi[0])), labels: sparkDates(state),
  }
}

function makeProduct(definition: typeof eaProductDefinitions[number], productIndex: number) {
  let taskIndex = 0
  return Array.from({ length: 205 + productIndex * 7 % 24 }, (_, caseIndex) => {
    const id = `${definition.product}-C${String(caseIndex + 1).padStart(3, '0')}`
    const owners = [
      (caseIndex * 7 + productIndex * 3) % people.length,
      0, 0, 0,
    ]
    owners[1] = (owners[0] + 3 + caseIndex % 3) % people.length
    owners[2] = (owners[0] + 6 + productIndex % 3) % people.length
    owners[3] = (owners[0] + 9 + caseIndex % 2) % people.length
    return {
      id, days: round(definition.days + ((caseIndex * 17 + productIndex * 11) % 41 - 20) / 10),
      owner: people[owners[0]].name,
      tasks: Array.from({ length: 101 + (caseIndex * 5 + productIndex * 3) % 12 }, (_, offset) => {
        taskIndex++
        const ownerIndex = owners[offset % 10 < 5 ? 0 : offset % 10 < 8 ? 1 : offset % 10 === 8 ? 2 : 3]
        const person = people[ownerIndex], teamIndex = leafIds.indexOf(person.teamId)
        const hours = round(Math.max(2, teamBase[person.teamId]
          + (noise((productIndex + 1) * 101 + teamIndex + 1) - 0.5) * 14
          + (noise(ownerIndex + 1) - 0.5) * 8
          + (noise((productIndex + 1) * 1000 + caseIndex + 1) - 0.5) * 8
          + (noise((productIndex + 1) * 1000000 + (caseIndex + 1) * 1000 + offset + 1) - 0.5) * 12))
        return { id: `${definition.product}-T${String(taskIndex).padStart(5, '0')}`, caseId: id, owner: person.name, hours, sequence: taskIndex }
      }),
    }
  })
}
let baseProducts: ReturnType<typeof makeProduct>[] | undefined
let metricCache: { key: string; rows: EAProductMetric[] } | undefined

export function eaMetricProducts(state: PeriodState): EAProductMetric[] {
  const key = `${state.period}:${state.from}:${state.to}:${ovDataFor(state).quality[0][1]}`
  if (metricCache?.key === key) return metricCache.rows
  baseProducts ??= eaProductDefinitions.map(makeProduct)
  const scale = ovDataFor(state).quality[0][1] / 12.6
  const adjust = { 天: 1, 周: 0, 月: -1, custom: 0 }[state.period]
  const bump = { 天: 0.05, 周: 0.03, 月: 0, custom: 0.01 }[state.period]
  const rows = eaProductDefinitions.map((definition, index) => {
    const base = baseProducts![index]
    const averageDays = base.reduce((sum, item) => sum + item.days, 0) / base.length
    const members = new Map<string, { person: EAPerson; hours: number; tasks: number }>()
    let taskCount = 0, ai = 0
    const cases: EACase[] = base.map((item, caseIndex) => ({
      id: item.id, days: round(item.days * scale), owner: item.owner,
      score: Math.max(58, Math.min(98, Math.round(87 + adjust + (noise((index + 1) * 9000 + caseIndex * 31) - 0.5) * 28 - (item.days - averageDays) * 0.55))),
      tasks: item.tasks.map(task => {
        const isAI = noise((index + 1) * 100000 + task.sequence * 13) < Math.min(0.9, 0.55 + noise((index + 1) * 777) * 0.27 + bump)
        taskCount++
        if (isAI) ai++
        const person = personByName.get(task.owner)!
        const member = members.get(task.owner) ?? { person, hours: 0, tasks: 0 }
        member.hours += task.hours
        member.tasks++
        members.set(task.owner, member)
        return { ...task, hours: round(task.hours * scale), rawHours: task.hours, ai: isAI }
      }),
    }))
    const teams = leafIds.map(id => {
      const teamMembers = [...members.values()].filter(member => member.person.teamId === id)
      const tasks = teamMembers.reduce((sum, member) => sum + member.tasks, 0)
      return {
        id, name: teamPath(id).join(' / '), tasks,
        hours: tasks ? round(teamMembers.reduce((sum, member) => sum + member.hours, 0) / tasks * scale) : 0,
        members: teamMembers.map(member => ({ ...member.person, hours: round(member.hours / member.tasks * scale), tasks: member.tasks })).sort((a, b) => b.hours - a.hours),
      }
    }).filter(team => team.tasks)
    return {
      ...definition, cases, hours: round(averageDays * scale) * 24,
      average: Math.round(cases.reduce((sum, item) => sum + item.score, 0) / cases.length),
      high: Math.round(cases.filter(item => item.score >= 90).length / cases.length * 100),
      tasks: taskCount, ai, manual: taskCount - ai, ratio: Math.round(ai / taskCount * 100), teams,
    }
  })
  metricCache = { key, rows }
  return rows
}

export const metricValue = (kind: EAMetric, product: EAProductMetric) =>
  kind === 'closure' ? product.hours : kind === 'score' ? product.average : product.ratio
export function metricTrend(kind: EAMetric, product: EAProductMetric, state: PeriodState) {
  const value = metricValue(kind, product), range = { closure: 43.2, score: 4, human: 8 }[kind]
  const seed = seedOf(`${kind}-${product.product}-${state.period === 'custom' ? `custom-${state.from}-${state.to}` : state.period}`)
  const delta = round((noise(seed) * 2 - 1) * range)
  return { delta, series: Array.from({ length: 8 }, (_, i) => i === 7 ? value : round(value - delta + delta * i / 7 + (noise(seed + i * 37) - 0.5) * range * 0.35)) }
}
export function scorePeople(product: EAProductMetric) {
  const members = new Map<string, { name: string; total: number; cases: number }>()
  for (const item of product.cases) {
    for (const name of new Set(item.tasks.map(task => task.owner))) {
      const member = members.get(name) ?? { name, total: 0, cases: 0 }
      member.total += item.score
      member.cases++
      members.set(name, member)
    }
  }
  return [...members.values()].map(member => ({ ...member, average: round(member.total / member.cases) })).sort((a, b) => a.average - b.average || b.cases - a.cases || a.name.localeCompare(b.name, 'zh-CN'))
}

export interface ActivityUser extends EAPerson { id: string }
export interface ActivityRow {
  user: ActivityUser; logged: boolean; edited: boolean
  durationMinutes: number; casesCreated: number; casesModified: number; tasksEdited: number
  lastUse: string | null
}
const activitySizes: Record<string, number> = { CP: 3518, FT1: 3139, FT2: 2963, EFA1: 2720, EFA2: 2679, DA1: 2828, DA2: 2598, QA1: 2638, QA2: 2436, SAE: 3481 }
const activityUsers: ActivityUser[] = Object.entries(activitySizes).flatMap(([teamId, size], index) => {
  const known = people.filter(person => person.teamId === teamId)
  return Array.from({ length: size }, (_, i) => ({
    id: `EA${String(index + 1).padStart(2, '0')}${String(i + 1).padStart(4, '0')}`,
    name: known[i]?.name ?? `${teamId}成员${String(i + 1).padStart(4, '0')}`, teamId,
  }))
})
export function activityDates(state: PeriodState): string[] {
  const end = state.period === 'custom' ? state.to : TODAY
  const start = state.period === 'custom' ? state.from : null
  if (!end || (state.period === 'custom' && !start)) throw new Error('EA activity range requires start and end dates')
  const last = new Date(`${end}T12:00:00`), first = start ? new Date(`${start}T12:00:00`) : new Date(last)
  if (!start) first.setDate(first.getDate() - ({ 天: 0, 周: 6, 月: 29, custom: 0 }[state.period]))
  if (!Number.isFinite(+first) || !Number.isFinite(+last) || first > last) throw new Error('Invalid EA activity range')
  const dates: string[] = []
  for (const date = new Date(first); date <= last; date.setDate(date.getDate() + 1)) {
    dates.push(`${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`)
  }
  return dates
}
let activityCache: { key: string; rows: ActivityRow[] } | undefined
export function eaActivity(state: PeriodState): ActivityRow[] {
  const dates = activityDates(state), key = dates.join(',')
  if (activityCache?.key === key) return activityCache.rows
  const days = dates.map(date => ({
    date, seed: Number(date.replace(/-/g, '')), weekday: new Date(`${date}T12:00:00`).getDay(),
  }))
  const rows = activityUsers.map((user, index) => {
    const row: ActivityRow = { user, logged: false, edited: false, durationMinutes: 0, casesCreated: 0, casesModified: 0, tasksEdited: 0, lastUse: null }
    const teamIndex = leafIds.indexOf(user.teamId)
    const adopted = noise(index * 53 + teamIndex * 113 + 19) < 0.86 + teamIndex * 0.006
    const editor = noise(index * 67 + teamIndex * 127 + 29) < 0.52 + teamIndex % 4 * 0.025
    for (const { date, seed: daySeed, weekday } of days) {
      const seed = daySeed + index * 31 + teamIndex * 997
      if (!adopted || noise(seed) >= (weekday === 0 || weekday === 6 ? 0.2 : 0.62)) continue
      row.logged = true
      row.durationMinutes += 18 + Math.floor(noise(seed + 419) * 93)
      const login = 480 + Math.floor(noise(seed + 307) * 610)
      const last = Math.min(1245, login + 22 + Math.floor(noise(seed + 401) * 230))
      row.lastUse = `${date} ${String(Math.floor(last / 60)).padStart(2, '0')}:${String(last % 60).padStart(2, '0')}`
      if (editor && noise(seed + 7001) < 0.44) {
        row.edited = true
        row.casesCreated += noise(seed + 503) < 0.22 ? 1 + Math.floor(noise(seed + 509) * 2) : 0
        row.casesModified += Math.floor(noise(seed + 601) * 4)
        row.tasksEdited += 1 + Math.floor(noise(seed + 701) * 7)
      }
    }
    return row
  })
  activityCache = { key, rows }
  return rows
}
export function activityStats(rows: ActivityRow[]) {
  const logged = rows.filter(row => row.logged).length, edited = rows.filter(row => row.edited).length
  const lastUse = rows.reduce<string | null>((last, row) => row.lastUse && (!last || row.lastUse > last) ? row.lastUse : last, null)
  return {
    total: rows.length, logged, edited, loginRate: rows.length ? Math.round(logged / rows.length * 100) : 0,
    editRate: logged ? Math.round(edited / logged * 100) : 0,
    avgMinutes: logged ? Math.round(rows.reduce((sum, row) => sum + row.durationMinutes, 0) / logged) : 0,
    casesCreated: rows.reduce((sum, row) => sum + row.casesCreated, 0),
    casesModified: rows.reduce((sum, row) => sum + row.casesModified, 0),
    tasksEdited: rows.reduce((sum, row) => sum + row.tasksEdited, 0),
    lastUse,
  }
}

export function taskSessions(task: EATask) {
  if (task.ai) return []
  const seed = seedOf(task.id)
  const actions = ['打开任务详情', '查看所属 Case', '查看历史与附件', '编辑分析记录', '上传证据', '补充任务结论', '提交任务结果']
  return Array.from({ length: 1 + Math.floor(noise(seed) * 4) }, (_, index) => {
    const duration = 360 + Math.floor(noise(seed + index * 97) * 1500)
    const count = 4 + Math.floor(noise(seed + index * 131) * 3)
    return {
      id: `HDX-${String(seed % 100000).padStart(5, '0')}-${index + 1}`, duration,
      start: new Date(2026, 7, 12 - Math.floor(noise(seed + index * 43) * 8), 8 + Math.floor(noise(seed + index * 59) * 10), Math.floor(noise(seed + index * 71) * 60)),
      url: `/case/${task.caseId}/task/${task.id}`,
      events: Array.from({ length: count }, (_, i) => ({
        at: Math.round((i + 0.35) / (count + 0.1) * duration),
        action: actions[(seed + index + i * 2) % actions.length],
        page: i === 0 ? '任务详情' : i % 3 === 1 ? 'Case 详情' : '分析工作区',
      })),
    }
  })
}
