import assert from 'node:assert/strict'
import test from 'node:test'
import { moduleUrl } from './testLoader.mjs'

const { activityDates, activityStats, daysText, eaActivity, eaMetricProducts, eaProductDefinitions, eaTeams,
  metricTrend, overviewKpi, scorePeople, taskSessions, teamChildren, teamPath } =
  await import(await moduleUrl(new URL('./eaOverview.ts', import.meta.url)))
const { ovDataFor } = await import(await moduleUrl(new URL('./compute.ts', import.meta.url)))
const { trafficMetricLabels, activeUserDefinition } = await import(await moduleUrl(new URL('./metrics.ts', import.meta.url)))
const { growth } = await import(await moduleUrl(new URL('./mock.ts', import.meta.url)))
const state = (period, from = null, to = null) => ({ period, from, to })
const sum = (rows, key) => rows.reduce((total, row) => total + row[key], 0)

test('all EA periods and growth use shared traffic labels without changing metric values', () => {
  assert.deepEqual(trafficMetricLabels, { uv: '活跃用户 UV', pv: '页面浏览 PV', averageDuration: '平均访问时长' })
  for (const [period, uv, pv, minutes] of [['天', 38, 210, 7.9], ['周', 96, 940, 8.4], ['月', 142, 1860, 8.7]]) {
    const data = ovDataFor(state(period))
    assert.deepEqual(data.access.filter((_, index) => [0, 1, 5].includes(index)).map(item => item[0]),
      [trafficMetricLabels.uv, trafficMetricLabels.pv, trafficMetricLabels.averageDuration])
    assert.equal(data.access[0][1], uv)
    assert.equal(data.access[0][3], activeUserDefinition)
    assert.equal(data.access[1][1], pv)
    assert.equal(data.access[5][1], minutes)
    assert.equal(overviewKpi(data.access[5], state(period)).unit, 'h')
  }
  assert.equal(growth.metrics.find(metric => metric.key === 'active').label, trafficMetricLabels.uv)
})

test('EA uses the prototype two-column overview metrics and hours/day units', () => {
  const day = state('天'), data = ovDataFor(day)
  assert.equal(data.access[2][0], '编辑内容用户')
  assert.equal(overviewKpi(data.quality[0], day).value, '283.2<small>h</small><i class="duration-days">11.8天</i><span class="trend down" title="同比上一周期">▼ 4%</span>')
  const duration = overviewKpi(data.access[5], day)
  assert.equal(duration.unit, 'h')
  assert.equal(duration.series[duration.series.length - 1], 0.13)
  assert.ok(duration.value.includes('&lt;0.01天'))
  assert.equal(daysText(0), '0天')
  const custom = ovDataFor(state('custom', '2026-07-01', '2026-07-16'))
  assert.equal(custom.access[2][1], 24, 'distinct editors must not be multiplied by date count')
  assert.equal(custom.access[1][1], 210 * 16)
})

test('all twelve EA product snapshots retain the original HTML sample results', () => {
  const fixtures = [
    { period: '天', hours: 242.4, average: 88, high: 48, ai: 14925, ratio: 68, teamHours: 20.8 },
    { period: '月', hours: 259.2, average: 86, high: 39, ai: 13853, ratio: 63, teamHours: 22.2 },
  ]
  for (const fixture of fixtures) {
    const rows = eaMetricProducts(state(fixture.period)), row = rows[0]
    assert.equal(rows.length, 12)
    assert.deepEqual(rows.map(row => row.product), eaProductDefinitions.map(row => row.product))
    for (const key of ['hours', 'average', 'high', 'ai', 'ratio']) assert.ok(Math.abs(row[key] - fixture[key]) < 1e-8, key)
    assert.equal(row.cases.length, 205)
    assert.equal(row.tasks, 21827)
    assert.equal(row.teams[0].id, 'CP')
    assert.equal(row.teams[0].hours, fixture.teamHours)
    assert.equal(row.teams[0].tasks, 3878)
    assert.equal(row.teams[0].members[0].name, 'CP成员020')
  }
})

test('product case/task/team totals and AI classifications stay consistent', () => {
  const rows = eaMetricProducts(state('周'))
  for (const row of rows) {
    const tasks = row.cases.flatMap(item => item.tasks)
    assert.equal(tasks.length, row.tasks)
    assert.equal(new Set(tasks.map(task => task.id)).size, row.tasks)
    assert.equal(tasks.filter(task => task.ai).length, row.ai)
    assert.equal(row.ai + row.manual, row.tasks)
    assert.equal(sum(row.teams, 'tasks'), row.tasks)
    assert.equal(sum(row.teams.flatMap(team => team.members), 'tasks'), row.tasks)
    assert.ok(tasks.every(task => task.caseId && task.owner && task.rawHours > 0 && task.hours > 0))
    assert.ok(row.cases.every(item => item.tasks.every(task => task.caseId === item.id)))
  }
})

test('score ranking includes every case participant rather than only the primary owner', () => {
  const product = eaMetricProducts(state('月'))[0], members = scorePeople(product)
  assert.ok(members.length > 10)
  for (const person of members) {
    const cases = product.cases.filter(item => item.tasks.some(task => task.owner === person.name))
    assert.equal(person.cases, cases.length)
    assert.equal(person.average, +(sum(cases, 'score') / cases.length).toFixed(1))
  }
  assert.ok(members.every((member, index) => !index || member.average >= members[index - 1].average))
})

test('EA trends are deterministic and end at the selected metric', () => {
  const st = state('周'), row = eaMetricProducts(st)[0]
  for (const [kind, value] of [['closure', row.hours], ['score', row.average], ['human', row.ratio]]) {
    const trend = metricTrend(kind, row, st)
    assert.deepEqual(trend, metricTrend(kind, row, st))
    assert.equal(trend.series.length, 8)
    assert.equal(trend.series[7], value)
  }
})

test('activity summaries exactly match the prototype for 29,000 deduplicated users', () => {
  const fixtures = [
    { period: '天', logged: 15910, edited: 3818, loginRate: 55, editRate: 24, casesCreated: 1218, casesModified: 5638, tasksEdited: 15435 },
    { period: '月', logged: 25752, edited: 14154, loginRate: 89, editRate: 55, casesCreated: 30798, casesModified: 141801, tasksEdited: 380822 },
  ]
  for (const fixture of fixtures) {
    const rows = eaActivity(state(fixture.period)), stats = activityStats(rows)
    assert.equal(rows.length, 29000)
    assert.equal(new Set(rows.map(row => row.user.id)).size, 29000)
    for (const key of ['logged', 'edited', 'loginRate', 'editRate', 'casesCreated', 'casesModified', 'tasksEdited']) assert.equal(stats[key], fixture[key], key)
    assert.ok(rows.every(row => !row.edited || row.logged))
    assert.ok(rows.every(row => row.logged || !row.lastUse && !row.durationMinutes))
    assert.ok(rows.every(row => !row.logged || row.lastUse <= '2026-07-16 23:59'))
  }
})

test('activity dates are inclusive and invalid ranges fail explicitly', () => {
  assert.equal(activityDates(state('天')).length, 1)
  assert.equal(activityDates(state('周')).length, 7)
  assert.equal(activityDates(state('月')).length, 30)
  assert.deepEqual(activityDates(state('custom', '2026-07-15', '2026-07-16')), ['2026-07-15', '2026-07-16'])
  const custom = eaActivity(state('custom', '2026-07-16', '2026-07-16'))
  assert.deepEqual(custom, eaActivity(state('天')))
  assert.throws(() => activityDates(state('custom')), /requires/)
  assert.throws(() => activityDates(state('custom', '2026-07-17', '2026-07-16')), /Invalid/)
  assert.equal(activityStats([]).loginRate, 0)
  assert.equal(activityStats([]).lastUse, null)
})

test('department ancestry retains the prototype deep team hierarchy', () => {
  assert.deepEqual(teamPath('DA2'), ['DA', 'Data', 'Analysis', 'Model', 'Insight', 'DA2'])
  assert.deepEqual(teamChildren(null).map(team => team.id), ['PTE', 'EFA', 'DA', 'QA', 'SAE'])
  for (const team of eaTeams) assert.ok(teamPath(team.id).length > 0)
  assert.throws(() => teamPath('unknown'), /Unknown team/)
})

test('session demonstration has bounded events and never invents human replay for AI tasks', () => {
  const tasks = eaMetricProducts(state('月'))[0].cases.flatMap(item => item.tasks)
  assert.deepEqual(taskSessions(tasks.find(task => task.ai)), [])
  const task = tasks.find(task => !task.ai), sessions = taskSessions(task)
  assert.deepEqual(sessions, taskSessions(task))
  assert.ok(sessions.length >= 1 && sessions.length <= 4)
  for (const session of sessions) {
    assert.ok(session.url.includes(task.id))
    assert.ok(session.events.length >= 4)
    assert.ok(session.events.every((event, index) => event.at >= 0 && event.at <= session.duration && (!index || event.at >= session.events[index - 1].at)))
  }
})
