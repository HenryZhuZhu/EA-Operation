import type { KpiTuple, PeriodState } from '@/types'
import { TODAY } from './mock'

export type CaseLevel = 'L0' | 'L1' | 'L2' | 'L3' | 'L4' | 'L5'
export type CaseUrgency = '非常紧急' | '紧急' | '一般' | '不紧急'
export type CaseLifecycle = '待处理' | '进行中' | '已准备好解决方案' | '解决方案验证中' | '已结案'
export type CaseSource = '手动' | '检查项Fail' | 'SPC自动' | 'Issue归集' | 'fanout验证'
export type AIReviewState = '已完成' | '分析中' | '待补充数据' | '暂不评分'

export interface AIScoreDimension {
  label: string
  weight?: number
  score: number
  finding: string
}

export interface AIScoringStandard {
  key: string
  label: string
  weight: number
  criteria: string
}

/** V1.0.4 工程过程对应的六维 AI 评分标准，权重合计 100%。 */
export const aiScoringStandards: AIScoringStandard[] = [
  { key: 'definition', label: '问题定义与表达规范', weight: 15, criteria: '背景、现象、影响、边界、目标及内容书写是否完整、清楚、专业。' },
  { key: 'thinking', label: '思路与假设树', weight: 20, criteria: '思维导图是否结构清晰，假设是否互斥且覆盖充分，验证顺序是否合理。' },
  { key: 'execution', label: '任务拆解与协作执行', weight: 15, criteria: '任务、Owner、期限、判定标准、跨部门分工与推进时效是否合理。' },
  { key: 'evidence', label: '证据与过程留痕', weight: 20, criteria: '数据、附件、状态历史、有效/无效路径和关键决策是否可追溯。' },
  { key: 'reasoning', label: '分析推理与结论可信度', weight: 20, criteria: '结论是否由证据支撑，是否排除反例，并说明适用边界与风险。' },
  { key: 'closure', label: '闭环与经验复用', weight: 10, criteria: '方案验证、Issue/Checklist 回写、Fanout 和知识沉淀是否完成。' },
]

export interface AIScoreDeduction {
  label: string
  points: number
  detail: string
}

export interface CaseRatingRecord {
  id: string
  code: string
  title: string
  product: string
  owner: string
  department: string
  level: CaseLevel
  urgency: CaseUrgency
  lifecycle: CaseLifecycle
  source: CaseSource
  completedTasks: number
  totalTasks: number
  issueCode?: string
  checklist?: string
  fanoutSource?: string
  updatedAt: string
  aiState: AIReviewState
  aiScore: number | null
  aiSummary: string
  dimensions: AIScoreDimension[]
  deductions: AIScoreDeduction[]
  generatedAt: string | null
}

export interface EngineerQualityRecord {
  id: string
  name: string
  department: string
  validCases: number
  leadCases: number
  participatedCases: number
  qualityScore: number
  highScoreRate: number
  trend: number
  products: string[]
  dimensions: { label: string; score: number }[]
  representativeCases: { code: string; title: string; score: number }[]
}

type AIResult = Pick<CaseRatingRecord, 'aiState' | 'aiScore' | 'aiSummary' | 'dimensions' | 'deductions' | 'generatedAt'>
type LegacyAIResult = AIResult & { confidence?: number | null }

const aiResultById: Record<string, LegacyAIResult> = {
  c001: { aiState: '已完成', aiScore: 88, confidence: 0.92, aiSummary: '问题背景和验证路径完整，已形成明确的 Pattern 与工艺双方向判断；EFA 物理验证和最终闭环材料仍可补强。', dimensions: [{ label: '问题定义', score: 94, finding: '影响范围、客户风险与失效条件描述完整。' }, { label: '分析过程', score: 89, finding: 'Pattern、Shmoo 与 EFA 路径清晰且可追溯。' }, { label: '结论可信度', score: 84, finding: '当前结论有数据支撑，但物理验证尚未完全收口。' }, { label: '经验复用', score: 90, finding: '可沉淀为低压 Pattern margin 检查经验。' }, { label: '闭环质量', score: 82, finding: '仍有执行任务未完成。' }], deductions: [{ label: '闭环材料未齐', points: 6, detail: 'EFA 物理验证和最终方案验证尚未完成。' }, { label: '任务完成度偏低', points: 6, detail: '当前完成 2 / 6 个任务。' }], generatedAt: '2026-07-16 16:42' },
  c002: { aiState: '分析中', aiScore: null, confidence: null, aiSummary: 'Case 仍在执行阶段，AI 正在等待 Retest bin 分析与 Socket 对照实验结果。', dimensions: [], deductions: [], generatedAt: null },
  c003: { aiState: '已完成', aiScore: 93, confidence: 0.96, aiSummary: '自动触发、根因定位、Recipe 修正和 Checklist 回写形成完整闭环，结论可复用性高。', dimensions: [{ label: '问题定义', score: 91, finding: 'SPC 触发条件与影响阶段明确。' }, { label: '分析过程', score: 92, finding: '历史趋势和工艺参数定位过程完整。' }, { label: '结论可信度', score: 96, finding: '修正后数据收敛，验证充分。' }, { label: '经验复用', score: 95, finding: '已回写 Checklist 并完成跨产品 Fanout。' }, { label: '闭环质量', score: 93, finding: 'Issue、Case 与回写记录完整。' }], deductions: [{ label: '初始影响描述较简略', points: 3, detail: '自动建案阶段的业务影响信息较少。' }, { label: '附件索引可补充', points: 4, detail: '建议补充 Recipe 变更前后对照文件索引。' }], generatedAt: '2026-07-15 18:03' },
  c004: { aiState: '已完成', aiScore: 76, confidence: 0.84, aiSummary: 'SOP 更新目标明确，但属于规范维护类 Case，分析证据与可量化验证较少。', dimensions: [{ label: '问题定义', score: 82, finding: '更新目标清晰。' }, { label: '分析过程', score: 70, finding: '主要为文档对照，分析过程较轻。' }, { label: '结论可信度', score: 78, finding: '已产出草案，尚待评审。' }, { label: '经验复用', score: 84, finding: '规范更新具备团队复用价值。' }, { label: '闭环质量', score: 66, finding: '评审任务尚未完成。' }], deductions: [{ label: '缺少验证结果', points: 12, detail: '当前只有草案产出，未记录评审结论。' }, { label: '闭环未完成', points: 12, detail: '仍有 1 个任务待处理。' }], generatedAt: '2026-07-15 14:13' },
  c005: { aiState: '已完成', aiScore: 95, confidence: 0.97, aiSummary: 'L0 客退 Case 的影响、跨部门分析、8D 根因与客户闭环信息完整，是高质量复杂 Case。', dimensions: [{ label: '问题定义', score: 98, finding: '客户、批次、影响与交付风险清晰。' }, { label: '分析过程', score: 96, finding: '8D、EFA、回片复测路径完整。' }, { label: '结论可信度', score: 95, finding: '根因与改善方案具备多方证据。' }, { label: '经验复用', score: 94, finding: '可形成退货分析与 screening 经验。' }, { label: '闭环质量', score: 92, finding: '结案资料完整，但部分子任务记录仍可细化。' }], deductions: [{ label: '子任务记录颗粒度不一致', points: 5, detail: '个别跨部门任务的最终附件索引不完整。' }], generatedAt: '2026-07-14 11:05' },
  'c-dimm-parent': { aiState: '已完成', aiScore: 86, confidence: 0.9, aiSummary: '母案拆分逻辑和子 Case 追溯关系完整，但最终共性结论仍依赖各子案回收。', dimensions: [{ label: '问题定义', score: 93, finding: '客户、工单和三类失效颗粒定义完整。' }, { label: '分析过程', score: 86, finding: '按颗粒拆案合理，子案关系清晰。' }, { label: '结论可信度', score: 78, finding: '母案尚未汇总最终根因。' }, { label: '经验复用', score: 88, finding: '按颗粒拆案方式可复用。' }, { label: '闭环质量', score: 82, finding: '仍处于解决方案验证阶段。' }], deductions: [{ label: '母案结论未汇总', points: 8, detail: '各子 Case 结论尚未统一回收。' }, { label: '验证仍在进行', points: 6, detail: '解决方案验证未结束。' }], generatedAt: '2026-07-14 09:34' },
  'c-dimm-child-1': { aiState: '待补充数据', aiScore: null, confidence: null, aiSummary: '缺少 FSA 最终结果、Bitmap 附件和有效结论，暂时无法生成可靠评分。', dimensions: [], deductions: [], generatedAt: null },
  'c-dimm-child-2': { aiState: '已完成', aiScore: 81, confidence: 0.87, aiSummary: 'EMMI 分析路径明确且任务已完成，但证据附件与结论描述仍偏简略。', dimensions: [{ label: '问题定义', score: 86, finding: 'Leakage 颗粒和条件明确。' }, { label: '分析过程', score: 84, finding: 'EFA 路径匹配问题类型。' }, { label: '结论可信度', score: 76, finding: '最终物理证据说明不足。' }, { label: '经验复用', score: 80, finding: '可复用为 DIMM Leakage 分析路径。' }, { label: '闭环质量', score: 79, finding: '任务已完成，附件索引可补强。' }], deductions: [{ label: '证据附件不足', points: 11, detail: '缺少 EMMI 图像与切片结果索引。' }, { label: '结论描述偏短', points: 8, detail: '未充分说明排除项和适用边界。' }], generatedAt: '2026-07-13 16:15' },
  'c-dimm-child-3': { aiState: '已完成', aiScore: 89, confidence: 0.93, aiSummary: '问题边界、X-Ray 验证和结案记录清晰，可作为 Open 类问题的标准子案。', dimensions: [{ label: '问题定义', score: 90, finding: '颗粒、温度和失效类型明确。' }, { label: '分析过程', score: 88, finding: 'X-Ray 与接触电阻验证路径合理。' }, { label: '结论可信度', score: 91, finding: '证据和结论一致。' }, { label: '经验复用', score: 88, finding: '可复用至焊点与接触类失效。' }, { label: '闭环质量', score: 88, finding: '已结案并回收到母案。' }], deductions: [{ label: '影响范围说明有限', points: 6, detail: '建议补充批次扩散性判断。' }, { label: '复用标签不足', points: 5, detail: '知识标签可以更细化。' }], generatedAt: '2026-07-12 16:25' },
  'c-fanout-demo': { aiState: '暂不评分', aiScore: null, confidence: null, aiSummary: '该 Case 为 Fanout 验证任务，需在验证结束并回填结果后再由 AI 评分。', dimensions: [], deductions: [], generatedAt: null },
  'c006': { aiState: '已完成', aiScore: 91, confidence: 0.94, aiSummary: 'eMMC 寿命衰减问题的失效边界、加速验证和改善结论完整，具备较高复用价值。', dimensions: [{ label: '问题定义', score: 92, finding: '寿命指标、批次与使用条件清晰。' }, { label: '分析过程', score: 91, finding: '加速老化与数据分层验证完整。' }, { label: '结论可信度', score: 93, finding: '改善前后数据形成闭环。' }, { label: '经验复用', score: 92, finding: '可复用至同类寿命衰减分析。' }, { label: '闭环质量', score: 87, finding: '附件索引仍可继续标准化。' }], deductions: [{ label: '附件索引不统一', points: 5, detail: '部分验证文件未使用统一命名。' }, { label: '复用标签可细化', points: 4, detail: '建议补充寿命模型和工艺条件标签。' }], generatedAt: '2026-06-09 09:35' },
  'c007': { aiState: '已完成', aiScore: 78, confidence: 0.85, aiSummary: 'WLCSP 焊球桥连问题已结案，但关键过程记录和量化验证证据偏少。', dimensions: [{ label: '问题定义', score: 84, finding: '失效对象和影响范围基本完整。' }, { label: '分析过程', score: 72, finding: '分析步骤记录较少。' }, { label: '结论可信度', score: 80, finding: '结论合理，但量化证据不足。' }, { label: '经验复用', score: 76, finding: '尚未形成标准检查项。' }, { label: '闭环质量', score: 78, finding: '已结案，附件和回写记录不充分。' }], deductions: [{ label: '过程记录不足', points: 10, detail: '关键排查步骤没有完整留痕。' }, { label: '量化证据不足', points: 7, detail: '缺少改善前后缺陷率对比。' }, { label: '未形成回写', points: 5, detail: '未同步为 Checklist 或复用经验。' }], generatedAt: '2026-05-28 17:20' },
}

const engineeringAssessment = (
  scores: number[],
  findings: string[],
  deductions: AIScoreDeduction[],
): Pick<AIResult, 'aiScore' | 'dimensions' | 'deductions'> => {
  // 输入保留细粒度原始观察项；在输出层合并为更聚焦的六维模型。
  const mergedScores = [
    Math.round(scores[0] * 0.65 + scores[5] * 0.35),
    scores[1],
    Math.round(scores[2] * 0.7 + scores[6] * 0.3),
    scores[3],
    scores[4],
    scores[7],
  ]
  const mergedFindings = [
    `${findings[0]} ${findings[5]}`,
    findings[1],
    `${findings[2]} ${findings[6]}`,
    findings[3],
    findings[4],
    findings[7],
  ]
  const dimensions = aiScoringStandards.map((standard, index) => ({
    label: standard.label,
    weight: standard.weight,
    score: mergedScores[index],
    finding: mergedFindings[index],
  }))
  const aiScore = Math.round(dimensions.reduce((sum, dimension) =>
    sum + dimension.score * (dimension.weight / 100), 0))
  return { aiScore, dimensions, deductions }
}

/** 已完成 Case 的工程质量细评；总分由六维加权计算，扣分项用于解释失分来源。 */
const engineeringAssessmentById: Record<string, Pick<AIResult, 'aiScore' | 'dimensions' | 'deductions'>> = {
  c001: engineeringAssessment(
    [94, 92, 82, 88, 85, 90, 84, 78],
    ['背景、客户影响、失效条件和目标清楚。', '思维导图形成 Pattern 与工艺两条主假设，验证顺序合理。', '任务覆盖 PTE、DA、EFA，但部分任务缺少明确的验收判定。', 'Shmoo、Pattern bisect 和 EFA 过程可追溯，仍缺最终物理验证材料。', '阶段性结论与证据一致，但尚未完全排除工艺漂移边界。', '标题和分析描述专业，关键信息表达清楚。', '跨部门分工清晰，但 2 / 6 的完成度影响推进质量。', '已关联 Issue 与 Checklist，最终方案验证和经验回写尚未完成。'],
    [{ label: '最终证据未收口', points: 5, detail: 'EFA 物理验证与改善后数据未形成最终闭环。' }, { label: '任务验收标准不完整', points: 4, detail: '部分执行任务只有动作描述，缺少明确通过/失败条件。' }, { label: '闭环完成度不足', points: 4, detail: '仍有 4 个任务未完成，暂未完成经验回写。' }],
  ),
  c003: engineeringAssessment(
    [90, 94, 90, 95, 96, 88, 90, 97],
    ['SPC 触发条件和影响阶段明确，业务影响描述略简。', '从趋势异常到工艺参数的假设路径清晰。', '认领、影响评估和验证任务具备明确目标。', '历史趋势、Recipe 变更和验证结果完整留痕。', 'Recipe 修正后数据收敛，根因结论可信。', '系统建案文本简洁，结案内容完整规范。', 'Owner 与相关部门响应及时，无明显超时或重复转办。', '已完成 Issue 结案、Checklist 回写和跨产品 Fanout。'],
    [{ label: '初始影响说明偏简', points: 3, detail: '自动建案阶段未充分描述潜在良率与交付影响。' }, { label: '附件命名可统一', points: 2, detail: 'Recipe 变更前后文件建议使用统一索引。' }, { label: '初始任务拆解较少', points: 2, detail: '早期仅有影响评估任务，可补充验证判定项。' }],
  ),
  c004: engineeringAssessment(
    [80, 68, 72, 65, 72, 78, 80, 70],
    ['SOP 更新目标明确，但未说明具体风险和验收基线。', '以文档对照为主，缺少结构化假设和差异分析树。', '有草案与评审任务，但验收标准和责任边界较弱。', '缺少新旧规范差异表、评审意见和验证附件。', '当前只有“待评审”阶段性结论，不能证明更新有效。', '文案基本规范，但关键变更点未结构化呈现。', 'Owner 和评审人明确，推进时效尚可。', '尚未完成评审、发布和适用范围回写。'],
    [{ label: '分析思路不足', points: 10, detail: '未形成变更原因、风险、差异和验证方式的结构化思路。' }, { label: '证据材料不足', points: 8, detail: '缺少差异表、评审记录和应用验证。' }, { label: '结论未完成', points: 6, detail: 'SOP 仍待评审，尚无最终结论。' }, { label: '闭环未完成', points: 4, detail: '未记录正式发布、通知和生效范围。' }],
  ),
  c005: engineeringAssessment(
    [98, 96, 94, 96, 96, 92, 94, 94],
    ['客户、批次、现场失效、影响和交付风险完整。', '8D、回片复测、EFA 与 Pattern 验证形成清晰假设树。', '跨部门任务拆解完整，Owner、期限和目标明确。', '分析数据、状态历史、有效路径和无效方向均可追溯。', '根因、改善方案和客户验证结果相互印证。', '报告结构专业，结论、过程和附件表达规范。', 'L0 Case 跨部门协同清晰，响应与推进符合紧急度。', '已结案并形成方案、Issue 归集和可复用 screening 经验。'],
    [{ label: '子任务颗粒度不一致', points: 3, detail: '个别跨部门任务的验收口径和附件索引不一致。' }, { label: '复用标签可进一步标准化', points: 2, detail: '建议补充客户场景和 screening 规则标签。' }],
  ),
  'c-dimm-parent': engineeringAssessment(
    [92, 89, 90, 84, 79, 88, 90, 72],
    ['客户、工单、颗粒和三类失效模式定义完整。', '按颗粒拆分子案的思路清楚，关系结构合理。', '子 Case Owner 与分析方向明确，母案汇总任务可进一步细化。', '子案过程可追溯，但母案尚未收齐全部证据。', '当前只能形成阶段性判断，尚无统一共性根因。', '母子案命名规范，背景与关联关系表达清楚。', 'PTE、FT、EFA 分工合理，子案推进节奏清晰。', '仍在方案验证阶段，母案结论和经验回写未完成。'],
    [{ label: '母案结论未汇总', points: 7, detail: '各子 Case 的证据和结论尚未统一回收到母案。' }, { label: '共性根因未确认', points: 5, detail: '暂时无法判断多颗粒是否同源。' }, { label: '闭环与回写未完成', points: 3, detail: '解决方案验证、Issue 结案和复用沉淀仍在进行。' }],
  ),
  'c-dimm-child-2': engineeringAssessment(
    [88, 82, 84, 80, 76, 78, 82, 78],
    ['Leakage 颗粒、条件和来源母案明确。', 'EMMI/OBIRCH 的分析方向合理，但排除路径记录不充分。', '任务类型和 Owner 明确，缺少结果判定边界。', '任务已完成，但 EMMI 图像和切片附件索引不完整。', '结论方向合理，物理证据和适用范围说明不足。', '内容简洁但结论描述偏短，缺少排除项。', 'EFA 与母案协作顺畅，未见明显延误。', '已完成子案任务，尚未形成标准分析模板或回写。'],
    [{ label: '物理证据附件不足', points: 8, detail: '缺少 EMMI 图像、切片位置和关键测量结果索引。' }, { label: '推理过程不完整', points: 6, detail: '未记录排除其他漏电路径的过程。' }, { label: '结论书写偏简略', points: 5, detail: '缺少适用边界、风险和下一步建议。' }],
  ),
  'c-dimm-child-3': engineeringAssessment(
    [90, 88, 86, 90, 92, 88, 86, 91],
    ['颗粒、低温条件和 Open 失效边界明确。', 'X-Ray 与接触电阻验证路径清楚。', '执行任务目标明确，拆解颗粒度适中。', '关键检查结果、状态和母案关系可追溯。', '证据与焊接/接触类结论一致。', '标题、背景和结论表达规范。', 'FT 侧推进及时，但跨部门复核记录较少。', '已结案并回收到母案，复用标签仍可补充。'],
    [{ label: '影响范围判断不足', points: 5, detail: '未充分说明是否存在批次扩散风险。' }, { label: '跨部门复核不足', points: 3, detail: '缺少封装或 EFA 侧的独立复核记录。' }, { label: '复用标签不足', points: 3, detail: '建议补充低温 Open、焊点和接触阻抗标签。' }],
  ),
  c006: engineeringAssessment(
    [94, 92, 90, 91, 93, 88, 90, 91],
    ['寿命指标、批次、写入条件与影响范围完整。', '从介质退化到工艺和使用条件的假设路径清晰。', '加速老化、数据分层与改善验证任务设计合理。', '原始数据、加速实验和改善前后结果完整留痕。', '寿命模型与验证结果支持最终根因和改善结论。', '内容专业，但附件命名与索引不完全统一。', 'QA、PTE 与 FT 协作顺畅，任务全部按期完成。', '已结案并具备同类寿命问题的复用价值。'],
    [{ label: '附件索引不统一', points: 4, detail: '部分验证文件未使用统一命名和版本号。' }, { label: '复用标签可细化', points: 4, detail: '建议补充寿命模型、写入条件和工艺版本标签。' }],
  ),
  c007: engineeringAssessment(
    [82, 70, 72, 74, 77, 72, 80, 73],
    ['失效对象和桥连现象明确，影响范围描述一般。', '缺少焊球、钢网、回流参数等假设树和排除顺序。', '任务数量有限，验收标准与责任边界不够清楚。', '关键排查步骤、图片和参数对比留痕不足。', '结论合理，但缺少改善前后缺陷率和独立复核。', '内容可读，但过程和结论书写不够完整规范。', 'Owner 明确，协作记录较少。', '虽已结案，但未形成 Checklist 回写和标准复现方法。'],
    [{ label: '思路结构不清晰', points: 8, detail: '未建立完整假设树，排查顺序与排除逻辑不可见。' }, { label: '过程证据不足', points: 7, detail: '缺少图片、工艺参数和复现数据对照。' }, { label: '书写不完整', points: 5, detail: '分析过程、结论边界和风险说明不足。' }, { label: '缺少经验回写', points: 5, detail: '未沉淀 Checklist、标准复现步骤或复用标签。' }],
  ),
}

const caseRecord = (input: Omit<CaseRatingRecord, keyof AIResult>): CaseRatingRecord => {
  const { confidence: _legacyConfidence, ...aiResult } = aiResultById[input.id]
  return { ...input, ...aiResult, ...engineeringAssessmentById[input.id] }
}

/** 与 V1.0.4 Case / Issue / Checklist / Fanout 示例一致的评分工作集。 */
export const caseRatingRecords: CaseRatingRecord[] = [
  caseRecord({ id: 'c001', code: 'EA-260511000001', title: 'DDR5 X-die CP1 yield drop @Site A', product: 'DDR5-X-6400', owner: '张伟', department: 'PTE', level: 'L1', urgency: '非常紧急', lifecycle: '已准备好解决方案', source: '检查项Fail', completedTasks: 2, totalTasks: 6, issueCode: 'ISS-20260415', checklist: '首片程式验证单 · ICC / Leakage 分布收敛', updatedAt: '2026-07-16 16:40' }),
  caseRecord({ id: 'c002', code: 'EA-260511000002', title: 'LPDDR5 FT Retest Rate 偏高', product: 'LPDDR5-7500', owner: '刘洋', department: 'PTE', level: 'L2', urgency: '紧急', lifecycle: '进行中', source: 'Issue归集', completedTasks: 0, totalTasks: 4, issueCode: 'ISS-20260601', updatedAt: '2026-07-16 15:20' }),
  caseRecord({ id: 'c003', code: 'EA-260511000003', title: 'SPC 自动触发：WAT Vth 漂移', product: 'Flash-N', owner: '张伟', department: 'PTE', level: 'L3', urgency: '一般', lifecycle: '已结案', source: 'SPC自动', completedTasks: 1, totalTasks: 1, issueCode: 'ISS-20260220', checklist: '良率基线检查单 · Bin 分布无异常', updatedAt: '2026-07-15 18:00' }),
  caseRecord({ id: 'c004', code: 'EA-260511000004', title: '站点 A 探针台校准规范更新', product: '通用', owner: '周杰', department: 'PTE', level: 'L3', urgency: '不紧急', lifecycle: '已准备好解决方案', source: '手动', completedTasks: 1, totalTasks: 2, updatedAt: '2026-07-15 14:10' }),
  caseRecord({ id: 'c005', code: 'EA-260511000005', title: 'DDR4 Lot 退货影响分析', product: 'DDR4-3200', owner: '孙楠', department: 'QA', level: 'L0', urgency: '非常紧急', lifecycle: '已结案', source: 'Issue归集', completedTasks: 2, totalTasks: 7, issueCode: 'ISS-20260530', checklist: '量产放行单 · 客退率 ≤ 目标', updatedAt: '2026-07-14 11:00' }),
  caseRecord({ id: 'c-dimm-parent', code: 'EA-260607000090', title: 'DIMM 模组客退批量 FT 失效', product: 'DMJFC', owner: '张伟', department: 'PTE', level: 'L1', urgency: '紧急', lifecycle: '解决方案验证中', source: 'Issue归集', completedTasks: 1, totalTasks: 4, issueCode: 'ISS-20260607', checklist: '客户样品验证单 · FT Retest Rate ≤ 目标', updatedAt: '2026-07-14 09:30' }),
  caseRecord({ id: 'c-dimm-child-1', code: 'EA-260607000090.C01', title: 'DIMM 模组客退 · Bit Fail（MC-D01）', product: 'DMJFC', owner: '赵敏', department: 'FT', level: 'L2', urgency: '紧急', lifecycle: '进行中', source: 'Issue归集', completedTasks: 0, totalTasks: 1, issueCode: 'ISS-20260607', updatedAt: '2026-07-13 17:20' }),
  caseRecord({ id: 'c-dimm-child-2', code: 'EA-260607000090.C02', title: 'DIMM 模组客退 · Leakage（MC-D02）', product: 'DMJFC', owner: '陈磊', department: 'EFA', level: 'L2', urgency: '一般', lifecycle: '已准备好解决方案', source: 'Issue归集', completedTasks: 1, totalTasks: 1, issueCode: 'ISS-20260607', updatedAt: '2026-07-13 16:10' }),
  caseRecord({ id: 'c-dimm-child-3', code: 'EA-260607000090.C03', title: 'DIMM 模组客退 · Open（MC-D03）', product: 'DMJFC', owner: '赵敏', department: 'FT', level: 'L3', urgency: '一般', lifecycle: '已结案', source: 'Issue归集', completedTasks: 1, totalTasks: 1, issueCode: 'ISS-20260607', updatedAt: '2026-07-12 16:20' }),
  caseRecord({ id: 'c-fanout-demo', code: 'EA-M-260723000220', title: '【Fanout 验证】LPDDR5 FT Retest Rate 偏高 · DDR5-X-6400', product: 'DDR5-X-6400', owner: '张伟', department: 'PTE', level: 'L2', urgency: '紧急', lifecycle: '待处理', source: 'fanout验证', completedTasks: 0, totalTasks: 0, fanoutSource: 'EA-260511000002', updatedAt: '2026-07-12 09:40' }),
  caseRecord({ id: 'c006', code: 'EA-260511000006', title: 'eMMC 写入寿命衰减异常分析', product: 'eMMC-128G', owner: '孙楠', department: 'QA', level: 'L1', urgency: '紧急', lifecycle: '已结案', source: '手动', completedTasks: 5, totalTasks: 5, updatedAt: '2026-06-09 09:30' }),
  caseRecord({ id: 'c007', code: 'EA-260511000007', title: 'WLCSP 焊球桥连失效复现', product: 'WLCSP-A1', owner: '张伟', department: 'PTE', level: 'L2', urgency: '紧急', lifecycle: '已结案', source: '手动', completedTasks: 2, totalTasks: 3, updatedAt: '2026-05-28 17:15' }),
]

export function caseRatingsForPeriod(state: PeriodState, allTime = false) {
  if (allTime) return caseRatingRecords
  if (state.period === 'custom') {
    return caseRatingRecords.filter((record) => {
      const date = record.updatedAt.slice(0, 10)
      return date >= state.from! && date <= state.to!
    })
  }
  const days = state.period === '天' ? 0 : state.period === '周' ? 6 : 29
  const start = new Date(+new Date(TODAY) - days * 864e5).toISOString().slice(0, 10)
  return caseRatingRecords.filter((record) => {
    const date = record.updatedAt.slice(0, 10)
    return date >= start && date <= TODAY
  })
}

export function summarizeCaseAIScores(records: CaseRatingRecord[]) {
  const completed = records.filter((record) => record.aiState === '已完成' && record.aiScore !== null)
  const scores = completed.map((record) => record.aiScore as number)
  return {
    completed,
    average: scores.length ? Math.round(scores.reduce((sum, score) => sum + score, 0) / scores.length) : 0,
    highCount: scores.filter((score) => score >= 90).length,
    lowCount: scores.filter((score) => score < 80).length,
    spread: scores.length ? Math.max(...scores) - Math.min(...scores) : 0,
  }
}

export function caseAIAverageKpi(records: CaseRatingRecord[]): KpiTuple {
  return ['Case平均分', summarizeCaseAIScores(records).average, ' 分', '本期已完成 AI 评分均值', 6]
}

const engineerDimensions = (scores: number[]) => aiScoringStandards.map((standard, index) => ({
  label: standard.label,
  score: scores[index],
}))

/** 工程师累计质量快照：按字段、任务、附件与结论贡献归因聚合；不足 3 个有效 Case 不进入正式排名。 */
export const engineerQualityRecords: EngineerQualityRecord[] = [
  { id: 'sun-nan', name: '孙楠', department: 'QA', validCases: 5, leadCases: 3, participatedCases: 7, qualityScore: 93, highScoreRate: 80, trend: 3, products: ['DDR4-3200', 'eMMC-128G'], dimensions: engineerDimensions([95, 92, 94, 93, 94, 90]), representativeCases: [{ code: 'EA-260511000005', title: 'DDR4 Lot 退货影响分析', score: 96 }, { code: 'EA-260511000006', title: 'eMMC 写入寿命衰减异常分析', score: 92 }] },
  { id: 'zhang-wei', name: '张伟', department: 'PTE', validCases: 6, leadCases: 4, participatedCases: 9, qualityScore: 89, highScoreRate: 50, trend: 2, products: ['DDR5-X-6400', 'Flash-N', 'WLCSP-A1'], dimensions: engineerDimensions([91, 93, 84, 89, 88, 82]), representativeCases: [{ code: 'EA-260511000003', title: 'SPC 自动触发：WAT Vth 漂移', score: 94 }, { code: 'EA-260511000001', title: 'DDR5 X-die CP1 yield drop', score: 87 }] },
  { id: 'liu-yang', name: '刘洋', department: 'PTE', validCases: 4, leadCases: 2, participatedCases: 6, qualityScore: 87, highScoreRate: 50, trend: 4, products: ['LPDDR5-7500', 'DDR5-X-6400'], dimensions: engineerDimensions([88, 90, 87, 86, 88, 82]), representativeCases: [{ code: 'EA-260511000003', title: 'WAT Vth 漂移复测贡献', score: 89 }, { code: 'EA-260511000001', title: 'ICC2 全温域扩展复测贡献', score: 86 }] },
  { id: 'chen-lei', name: '陈磊', department: 'EFA', validCases: 3, leadCases: 1, participatedCases: 5, qualityScore: 85, highScoreRate: 33, trend: 1, products: ['DMJFC', 'DDR5-X-6400'], dimensions: engineerDimensions([84, 86, 82, 91, 87, 78]), representativeCases: [{ code: 'EA-260607000090.C02', title: 'DIMM Leakage 子案', score: 81 }, { code: 'EA-260511000001', title: 'EFA 物理切片验证贡献', score: 88 }] },
  { id: 'zhao-min', name: '赵敏', department: 'FT', validCases: 5, leadCases: 2, participatedCases: 8, qualityScore: 84, highScoreRate: 20, trend: -1, products: ['DMJFC', 'DDR4-3200'], dimensions: engineerDimensions([86, 82, 85, 87, 84, 79]), representativeCases: [{ code: 'EA-260607000090.C03', title: 'DIMM Open 子案', score: 89 }, { code: 'EA-260607000090', title: 'DIMM 客退验证贡献', score: 82 }] },
  { id: 'wang-fang', name: '王芳', department: 'CP', validCases: 3, leadCases: 1, participatedCases: 5, qualityScore: 78, highScoreRate: 0, trend: -2, products: ['DDR5-X-6400', 'DMJFC'], dimensions: engineerDimensions([82, 77, 81, 79, 76, 72]), representativeCases: [{ code: 'EA-260511000001', title: 'CP Guardband 调整贡献', score: 80 }, { code: 'EA-260607000090', title: 'DIMM FT 客退协作', score: 76 }] },
  { id: 'li-na', name: '李娜', department: 'DA', validCases: 2, leadCases: 1, participatedCases: 4, qualityScore: 90, highScoreRate: 50, trend: 5, products: ['DDR5-X-6400', 'Flash-N'], dimensions: engineerDimensions([90, 92, 86, 93, 91, 85]), representativeCases: [{ code: 'EA-260511000001', title: 'Shmoo 与边缘 Die 分析贡献', score: 92 }] },
  { id: 'zhou-jie', name: '周杰', department: 'PTE', validCases: 1, leadCases: 1, participatedCases: 2, qualityScore: 86, highScoreRate: 0, trend: 1, products: ['Flash-N', '通用'], dimensions: engineerDimensions([88, 84, 82, 87, 85, 90]), representativeCases: [{ code: 'EA-260511000004', title: '探针台校准规范更新', score: 71 }] },
]
