export const trafficMetricLabels = {
  uv: '活跃用户 UV',
  pv: '页面浏览 PV',
  averageDuration: '平均访问时长',
} as const

export const activeUserDefinition = '所选区间内至少访问一次的去重用户'
