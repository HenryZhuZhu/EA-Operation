export interface Team { id: string; name: string; parentId: string | null }

export const teams: Team[] = [
  { id: 'PTE', name: 'PTE', parentId: null }, { id: 'CP', name: 'CP', parentId: 'PTE' },
  { id: 'FT', name: 'FT', parentId: 'PTE' }, { id: 'FT1', name: 'FT1', parentId: 'FT' }, { id: 'FT2', name: 'FT2', parentId: 'FT' },
  { id: 'EFA', name: 'EFA', parentId: null }, { id: 'LAB', name: 'Lab', parentId: 'EFA' },
  { id: 'EFA1', name: 'EFA1', parentId: 'LAB' }, { id: 'EFA2', name: 'EFA2', parentId: 'LAB' },
  { id: 'DA', name: 'DA', parentId: null }, { id: 'DATA', name: 'Data', parentId: 'DA' },
  { id: 'DA1', name: 'DA1', parentId: 'DATA' }, { id: 'DA_ANALYSIS', name: 'Analysis', parentId: 'DATA' },
  { id: 'DA_MODEL', name: 'Model', parentId: 'DA_ANALYSIS' }, { id: 'DA_INSIGHT', name: 'Insight', parentId: 'DA_MODEL' },
  { id: 'DA2', name: 'DA2', parentId: 'DA_INSIGHT' },
  { id: 'QA', name: 'QA', parentId: null }, { id: 'CUSTOMER', name: 'Customer', parentId: 'QA' },
  { id: 'QA1', name: 'QA1', parentId: 'CUSTOMER' }, { id: 'QA2', name: 'QA2', parentId: 'CUSTOMER' },
  { id: 'SAE', name: 'SAE', parentId: null },
]

export const teamChildren = (id: string | null) => teams.filter(team => team.parentId === id)
export function teamPath(id: string): string[] {
  const team = teams.find(item => item.id === id)
  if (!team) throw new Error(`Unknown team: ${id}`)
  return [...(team.parentId ? teamPath(team.parentId) : []), team.name]
}
