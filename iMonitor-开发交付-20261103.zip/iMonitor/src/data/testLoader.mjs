import { readFile } from 'node:fs/promises'
import ts from 'typescript'

const modules = new Map()
export async function moduleUrl(url) {
  if (modules.has(url.href)) return modules.get(url.href)
  const source = await readFile(url, 'utf8')
  let { outputText } = ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2020 },
  })
  for (const match of [...outputText.matchAll(/from ['"]([^'"]+)['"]/g)]) {
    const specifier = match[1]
    const dependency = specifier.startsWith('@/') ? new URL(`../${specifier.slice(2)}.ts`, import.meta.url) : new URL(`${specifier}.ts`, url)
    outputText = outputText.replace(match[0], `from '${await moduleUrl(dependency)}'`)
  }
  const result = `data:text/javascript;base64,${Buffer.from(outputText).toString('base64')}`
  modules.set(url.href, result)
  return result
}
