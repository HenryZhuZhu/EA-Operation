import type { PeriodState } from '@/types'
import { teams, teamChildren } from './teams'

export type ProductId = 'ea' | 'itest' | 'de-wbs' | 'dh-e-wbs' | 'product-space'

export interface Subproduct {
  id: string
  name: string
}

export interface Product {
  id: ProductId
  name: string
  description: string
  audience: number
  dailyUsers: number
  pagesPerVisit: number
  minutesPerVisit: number
  subproducts: Subproduct[]
}

export const products: Product[] = [
  { id: 'ea', name: 'EA', description: '访问、活跃与交付质量', audience: 300, dailyUsers: 70, pagesPerVisit: 5, minutesPerVisit: 8.7, subproducts: [] },
  {
    id: 'itest', name: 'iTest', description: '四个子产品的整体访问、活跃与用户粘性',
    audience: 920, dailyUsers: 238, pagesPerVisit: 6.4, minutesPerVisit: 12.8,
    subproducts: [
      { id: 'condition-table', name: 'Condition Table' },
      { id: 'fuse-control-table', name: 'Fuse Control Table' },
      { id: 'test-methods', name: 'Test Methods' },
      { id: 'test-management', name: 'Test Management' },
    ],
  },
  { id: 'de-wbs', name: 'DE-WBS', description: 'DE-WBS 的访问与用户粘性', audience: 540, dailyUsers: 112, pagesPerVisit: 4.8, minutesPerVisit: 9.6, subproducts: [] },
  { id: 'dh-e-wbs', name: 'DH E-WBS', description: 'DH E-WBS 的访问与用户粘性', audience: 380, dailyUsers: 86, pagesPerVisit: 5.2, minutesPerVisit: 10.4, subproducts: [] },
  {
    id: 'product-space', name: 'Product Space', description: '七个模块的整体访问、活跃与用户粘性',
    audience: 1280, dailyUsers: 326, pagesPerVisit: 3.6, minutesPerVisit: 6.2,
    subproducts: [
      { id: 'personal-workspace', name: '个人工作台' },
      { id: 'department-dashboard', name: '部门看板' },
      { id: 'product-dashboard', name: '产品看板' },
      { id: 'product-info', name: '产品信息总览' },
      { id: 'project-members', name: '项目成员管理' },
      { id: 'sample-management', name: '送样管理' },
      { id: 'mbo', name: 'MBO' },
    ],
  },
]

export function findProduct(id: unknown) {
  return products.find((product) => product.id === id)
}

export function findSubproduct(product: Product, id: unknown) {
  return product.subproducts.find((subproduct) => subproduct.id === id)
}

function dateKey(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`
}

function offsetDate(date: Date, days: number) {
  const result = new Date(date)
  result.setDate(result.getDate() + days)
  return result
}

const today = new Date()
today.setHours(0, 0, 0, 0)
export const trafficCoverage = {
  from: dateKey(offsetDate(today, -119)),
  to: dateKey(today),
}

interface TrafficSlice {
  users: number[]
  visits: number
  pv: number
  minutes: number
  hours: number[]
}

interface DailyTraffic extends TrafficSlice {
  date: string
}

interface TrafficDay extends DailyTraffic {
  subproducts: TrafficSlice[]
}

const hourlyWeights = [1, 1, 1, 1, 1, 2, 4, 12, 35, 62, 76, 64, 34, 48, 72, 80, 68, 42, 22, 14, 9, 6, 3, 2]

function distribute(total: number, weights: number[]) {
  const sum = weights.reduce((a, b) => a + b, 0)
  const exact = weights.map((weight) => total * weight / sum)
  const values = exact.map(Math.floor)
  const remainder = total - values.reduce((a, b) => a + b, 0)
  const order = exact.map((value, index) => ({ index, fraction: value - values[index] }))
    .sort((a, b) => b.fraction - a.fraction)
  for (const { index } of order.slice(0, remainder)) values[index]++
  return values
}

const sampleDays = new Map<ProductId, TrafficDay[]>()
const belongsToSubproduct = (user: number, index: number, size: number) =>
  user % size === index || user % (size * 2 - 1) === index

for (const [seed, product] of products.entries()) {
  if (product.id === 'ea') continue
  const days = Array.from({ length: 120 }, (_, index): TrafficDay => {
    const date = offsetDate(today, index - 119)
    const weekday = date.getDay()
    const wave = 1 + Math.sin(index * 0.63 + seed) * 0.12
    const count = Math.round(product.dailyUsers * wave * (weekday === 0 || weekday === 6 ? 0.36 : 1) * (0.8 + index / 600))
    const users = Array.from({ length: count }, (_, user) => (user * 7 + index * 31 + seed * 17) % product.audience)
    const subproducts = product.subproducts.map((_, subproductIndex): TrafficSlice => {
      const size = product.subproducts.length
      const visitors = users.filter((user) => belongsToSubproduct(user, subproductIndex, size))
      const visits = Math.round(visitors.length * (1.3 + subproductIndex * 0.16 + Math.sin(index * 0.3 + subproductIndex) * 0.1))
      const pv = Math.round(visits * product.pagesPerVisit * (1.2 - subproductIndex * 0.15))
      return {
        users: visitors,
        visits,
        pv,
        minutes: visits * product.minutesPerVisit * (0.7 + subproductIndex * 0.2) * (1 + Math.sin(index * 0.4 + subproductIndex) * 0.08),
        hours: distribute(pv, hourlyWeights),
      }
    })
    if (subproducts.length) {
      return {
        date: dateKey(date),
        users: [...new Set(subproducts.flatMap((subproduct) => subproduct.users))],
        visits: subproducts.reduce((sum, subproduct) => sum + subproduct.visits, 0),
        pv: subproducts.reduce((sum, subproduct) => sum + subproduct.pv, 0),
        minutes: subproducts.reduce((sum, subproduct) => sum + subproduct.minutes, 0),
        hours: hourlyWeights.map((_, hour) => subproducts.reduce((sum, subproduct) => sum + subproduct.hours[hour], 0)),
        subproducts,
      }
    }
    const visits = Math.round(count * (1.45 + Math.sin(index * 0.3 + seed) * 0.12))
    const pv = Math.round(visits * product.pagesPerVisit)
    return {
      date: dateKey(date),
      users,
      visits,
      pv,
      minutes: visits * product.minutesPerVisit * (1 + Math.sin(index * 0.4) * 0.08),
      hours: distribute(pv, hourlyWeights),
      subproducts,
    }
  })
  sampleDays.set(product.id, days)
}

const uniqueUsers = (days: DailyTraffic[]) => new Set(days.flatMap((day) => day.users)).size
const percent = (value: number, total: number) => total ? +(value / total * 100).toFixed(1) : 0

function summarizeTraffic(days: DailyTraffic[], state: PeriodState) {
  const to = state.period === 'custom' ? state.to! : trafficCoverage.to
  const from = state.period === 'custom'
    ? state.from!
    : dateKey(offsetDate(today, -({ 天: 1, 周: 7, 月: 30 }[state.period] - 1)))
  const selected = days.filter((day) => day.date >= from && day.date <= to)
  const uv = uniqueUsers(selected)
  const pv = selected.reduce((sum, day) => sum + day.pv, 0)
  const visits = selected.reduce((sum, day) => sum + day.visits, 0)
  const endDate = new Date(`${to}T00:00:00`)
  const monthStart = dateKey(offsetDate(endDate, -29))
  const weekStart = dateKey(offsetDate(endDate, -6))
  const month = days.filter((day) => day.date >= monthStart && day.date <= to)
  const week = month.filter((day) => day.date >= weekStart)
  const mau = uniqueUsers(month)
  const wau = uniqueUsers(week)
  const averageDAU = month.length ? month.reduce((sum, day) => sum + day.users.length, 0) / month.length : 0
  const completeStickiness = monthStart >= trafficCoverage.from && to <= trafficCoverage.to
  return {
    from, to, uv, pv, visits, mau, wau,
    dau: days.find((day) => day.date === to)?.users.length ?? 0,
    averageDAU: +averageDAU.toFixed(1),
    dauMau: completeStickiness ? percent(averageDAU, mau) : null,
    wauMau: completeStickiness ? percent(wau, mau) : null,
    avgMinutes: visits ? +(selected.reduce((sum, day) => sum + day.minutes, 0) / visits).toFixed(1) : 0,
    partial: from < trafficCoverage.from || to > trafficCoverage.to,
    selected,
    hours: hourlyWeights.map((_, hour) => selected.reduce((sum, day) => sum + day.hours[hour], 0)),
  }
}

function subproductDays(days: TrafficDay[], index: number): DailyTraffic[] {
  return days.map((day) => ({ date: day.date, ...day.subproducts[index] }))
}

export function productTraffic(product: Product, state: PeriodState, subproductId?: string) {
  const days = sampleDays.get(product.id) ?? []
  const index = product.subproducts.findIndex((subproduct) => subproduct.id === subproductId)
  if (subproductId !== undefined && index < 0) {
    throw new Error(`Unknown subproduct "${subproductId}" for ${product.name}`)
  }
  const traffic = summarizeTraffic(index < 0 ? days : subproductDays(days, index), state)
  return {
    ...traffic,
    subproducts: index < 0 ? product.subproducts.map((subproduct, subproductIndex) => {
      const summary = summarizeTraffic(subproductDays(days, subproductIndex), state)
      return {
        ...subproduct,
        uv: summary.uv,
        pv: summary.pv,
        visits: summary.visits,
        avgMinutes: summary.avgMinutes,
        dauMau: summary.dauMau,
        wauMau: summary.wauMau,
        share: percent(summary.pv, traffic.pv),
      }
    }) : [],
  }
}

export interface ProductTrafficUser {
  id: string
  name: string
  teamId: string
  pv: number
  visits: number
  minutes: number
  lastUse: string | null
}

export interface ProductPageTraffic {
  id: string
  name: string
  scopeId: string
  scopeName: string
  path: string
  pv: number
  uv: number
  share: number
  lastUse: string | null
  dailyPV: number[]
  users: { user: ProductTrafficUser; pv: number; lastUse: string }[]
}

export function productTrafficDetails(product: Product, state: PeriodState, subproductId?: string) {
  if (product.id === 'ea') throw new Error('EA uses its own activity data')
  const traffic = productTraffic(product, state, subproductId)
  const index = product.subproducts.findIndex(subproduct => subproduct.id === subproductId)
  const leaves = teams.filter(team => !teamChildren(team.id).length)
  const userByNumber = new Map<number, ProductTrafficUser>()
  for (let id = 0; id < product.audience; id++) {
    if (index >= 0 && !belongsToSubproduct(id, index, product.subproducts.length)) continue
    const teamId = leaves[(id * 17 + Math.floor(id / 10)) % leaves.length].id
    userByNumber.set(id, {
      id: `${product.id}-${String(id + 1).padStart(4, '0')}`,
      name: `${teamId}成员${String(id + 1).padStart(4, '0')}`,
      teamId, pv: 0, visits: 0, minutes: 0, lastUse: null,
    })
  }
  const scopes = product.subproducts.length
    ? product.subproducts.map((scope, index) => ({ ...scope, index })).filter(scope => index < 0 || scope.index === index)
    : [{ id: product.id, name: product.name, index: -1 }]
  const dates = new Map(traffic.selected.map((day, index) => [day.date, index]))
  const pageKinds = [{ id: 'overview', name: '总览' }, { id: 'list', name: '列表' }, { id: 'detail', name: '详情' }]
  type PageAccumulator = Omit<ProductPageTraffic, 'users'> & { users: Map<number, ProductPageTraffic['users'][number]> }
  const pages: PageAccumulator[] = scopes.flatMap(scope => pageKinds.map(kind => ({
    id: `${scope.id}/${kind.id}`, name: `${scope.name} · ${kind.name}`, scopeId: scope.id, scopeName: scope.name,
    path: `/${scope.id}/${kind.id}`, pv: 0, uv: 0, share: 0, lastUse: null,
    dailyPV: traffic.selected.map(() => 0),
    users: new Map<number, { user: ProductTrafficUser; pv: number; lastUse: string }>(),
  })))
  for (const day of sampleDays.get(product.id)!) {
    const dateIndex = dates.get(day.date)
    if (dateIndex === undefined) continue
    for (const [scopeIndex, scope] of scopes.entries()) {
      const slice = scope.index < 0 ? day : day.subproducts[scope.index]
      if (!slice.users.length) continue
      // Allocate existing daily totals, rather than inventing unrelated detail counts.
      const extras = distribute(slice.visits - slice.users.length, slice.users.map(id => id % 5 + 1))
      const visits = extras.map(value => value + 1)
      const additionalPV = distribute(slice.pv - slice.visits, visits)
      for (const [userIndex, id] of slice.users.entries()) {
        const user = userByNumber.get(id)!
        const pv = visits[userIndex] + additionalPV[userIndex]
        user.visits += visits[userIndex]
        user.pv += pv
        user.minutes += slice.minutes * visits[userIndex] / slice.visits
        user.lastUse = day.date
        const pagePV = distribute(pv, [5 + id % 3, 3 + (id + 1) % 3, 1 + id % 2])
        for (const [kindIndex, count] of pagePV.entries()) {
          if (!count) continue
          const page = pages[scopeIndex * pageKinds.length + kindIndex]
          page.pv += count
          page.dailyPV[dateIndex] += count
          page.lastUse = day.date
          const visitor = page.users.get(id)
          if (visitor) { visitor.pv += count; visitor.lastUse = day.date }
          else page.users.set(id, { user, pv: count, lastUse: day.date })
        }
      }
    }
  }
  return {
    traffic,
    users: [...userByNumber.values()],
    pages: pages.filter(page => page.pv > 0).map((page): ProductPageTraffic => ({
      ...page, uv: page.users.size, share: percent(page.pv, traffic.pv),
      users: [...page.users.values()].sort((a, b) => b.pv - a.pv || a.user.id.localeCompare(b.user.id)),
    })).sort((a, b) => b.pv - a.pv || a.id.localeCompare(b.id)),
  }
}
