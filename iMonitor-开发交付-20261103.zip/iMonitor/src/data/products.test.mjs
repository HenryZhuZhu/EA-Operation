import assert from 'node:assert/strict'
import test from 'node:test'
import { moduleUrl } from './testLoader.mjs'

const { products, findProduct, findSubproduct, productTraffic, productTrafficDetails, trafficCoverage } =
  await import(await moduleUrl(new URL('./products.ts', import.meta.url)))

const state = (period, from = null, to = null) => ({ period, from, to })
const monitored = products.filter((product) => product.id !== 'ea')
const scopes = monitored.flatMap((product) => [
  { product, subproductId: undefined },
  ...product.subproducts.map((subproduct) => ({ product, subproductId: subproduct.id })),
])
const sum = (values) => values.reduce((total, value) => total + value, 0)

test('UV and PV drilldowns exactly reconcile with every overview scope and period', () => {
  for (const { product, subproductId } of scopes) {
    for (const period of ['天', '周', '月']) {
      const detail = productTrafficDetails(product, state(period), subproductId)
      const overview = productTraffic(product, state(period), subproductId)
      assert.deepEqual(detail.traffic, overview)
      const active = detail.users.filter(user => user.pv > 0)
      assert.equal(active.length, overview.uv)
      assert.equal(sum(detail.users.map(user => user.pv)), overview.pv)
      assert.equal(sum(detail.users.map(user => user.visits)), overview.visits)
      assert.ok(Math.abs(sum(detail.users.map(user => user.minutes)) - sum(overview.selected.map(day => day.minutes))) < 1e-6)
      assert.equal(sum(detail.pages.map(page => page.pv)), overview.pv)
      assert.equal(new Set(detail.pages.flatMap(page => page.users.map(row => row.user.id))).size, overview.uv)
      for (const page of detail.pages) {
        assert.equal(page.uv, page.users.length)
        assert.equal(sum(page.users.map(user => user.pv)), page.pv)
        assert.equal(sum(page.dailyPV), page.pv)
        assert.equal(page.dailyPV.length, overview.selected.length)
        assert.ok(page.users.every(row => row.pv > 0 && row.lastUse >= overview.from && row.lastUse <= overview.to))
      }
      for (const user of detail.users) {
        assert.ok(user.pv >= user.visits)
        assert.equal(user.pv > 0, user.lastUse !== null)
        assert.ok(user.pv === 0 || user.lastUse >= overview.from && user.lastUse <= overview.to)
      }
    }
  }
})

test('platform detail rows preserve child identities and sum PV while de-duplicating users', () => {
  for (const product of monitored.filter(product => product.subproducts.length)) {
    const platform = productTrafficDetails(product, state('月'))
    const users = new Map(platform.users.map(user => [user.id, user]))
    const counts = new Map()
    for (const child of product.subproducts) {
      const detail = productTrafficDetails(product, state('月'), child.id)
      assert.ok(detail.users.length < platform.users.length)
      for (const user of detail.users) {
        assert.equal(users.get(user.id).name, user.name)
        assert.equal(users.get(user.id).teamId, user.teamId)
        counts.set(user.id, (counts.get(user.id) ?? 0) + user.pv)
      }
      assert.deepEqual(platform.pages.filter(page => page.scopeId === child.id).map(page => [page.id, page.pv, page.uv]),
        detail.pages.map(page => [page.id, page.pv, page.uv]))
    }
    for (const user of platform.users) assert.equal(counts.get(user.id) ?? 0, user.pv)
  }
})

test('details support inclusive custom, partial and empty ranges without changing sample counts', () => {
  for (const { product, subproductId } of scopes) {
    const month = productTrafficDetails(product, state('月'), subproductId)
    assert.deepEqual(productTrafficDetails(product, state('custom', month.traffic.from, month.traffic.to), subproductId), month)
    const partial = productTrafficDetails(product, state('custom', '2000-01-01', trafficCoverage.from), subproductId)
    assert.equal(partial.traffic.partial, true)
    assert.equal(sum(partial.pages.map(page => page.pv)), partial.traffic.pv)
    const empty = productTrafficDetails(product, state('custom', '2000-01-01', '2000-01-02'), subproductId)
    assert.equal(empty.traffic.uv, 0)
    assert.equal(empty.traffic.pv, 0)
    assert.equal(empty.pages.length, 0)
    assert.ok(empty.users.every(user => user.pv === 0 && user.visits === 0 && user.minutes === 0 && user.lastUse === null))
    assert.throws(() => productTrafficDetails(product, state('月'), 'invalid'), /Unknown subproduct/)
  }
  assert.throws(() => productTrafficDetails(findProduct('ea'), state('月')), /EA uses its own/)
})

test('iTest is a platform with four separately addressable subproducts', () => {
  assert.deepEqual(products.map((product) => product.id), ['ea', 'itest', 'de-wbs', 'dh-e-wbs', 'product-space'])
  const platform = findProduct('itest')
  assert.deepEqual(platform.subproducts.map((subproduct) => subproduct.name), ['Condition Table', 'Fuse Control Table', 'Test Methods', 'Test Management'])
  assert.equal(findSubproduct(platform, 'test-management').name, 'Test Management')
  assert.equal(findSubproduct(platform, 'unknown'), undefined)
  assert.ok(products.filter((product) => !['itest', 'product-space'].includes(product.id)).every((product) => product.subproducts.length === 0))
  assert.equal(findProduct('unknown'), undefined)
  assert.equal(findProduct(['itest']), undefined)
})

test('Product Space contains the seven modules identified in PDC planning materials', () => {
  const platform = findProduct('product-space')
  assert.deepEqual(platform.subproducts, [
    { id: 'personal-workspace', name: '个人工作台' },
    { id: 'department-dashboard', name: '部门看板' },
    { id: 'product-dashboard', name: '产品看板' },
    { id: 'product-info', name: '产品信息总览' },
    { id: 'project-members', name: '项目成员管理' },
    { id: 'sample-management', name: '送样管理' },
    { id: 'mbo', name: 'MBO' },
  ])
  for (const module of platform.subproducts) assert.equal(findSubproduct(platform, module.id), module)
})

test('day/week/month filter real sample rows and de-duplicate UV over the selected range', () => {
  for (const { product, subproductId } of scopes) {
    let previousPV = 0
    let previousUV = 0
    for (const [period, count] of [['天', 1], ['周', 7], ['月', 30]]) {
      const traffic = productTraffic(product, state(period), subproductId)
      assert.equal(traffic.selected.length, count)
      assert.equal(traffic.uv, new Set(traffic.selected.flatMap((day) => day.users)).size)
      assert.ok(traffic.uv <= product.audience)
      assert.ok(traffic.uv >= previousUV)
      assert.ok(traffic.pv > previousPV)
      assert.equal(traffic.pv, sum(traffic.selected.map((day) => day.pv)))
      assert.equal(traffic.visits, sum(traffic.selected.map((day) => day.visits)))
      assert.equal(sum(traffic.hours), traffic.pv)
      assert.ok(traffic.pv >= traffic.visits && traffic.visits >= traffic.uv)
      previousPV = traffic.pv
      previousUV = traffic.uv
    }
    const month = productTraffic(product, state('月'), subproductId)
    assert.ok(month.uv < sum(month.selected.map((day) => day.users.length)))
  }
})

test('each product and subproduct has distinct, deterministic samples', () => {
  const summaries = scopes.map(({ product, subproductId }) => {
    const first = productTraffic(product, state('月'), subproductId)
    assert.deepEqual(productTraffic(product, state('月'), subproductId), first)
    return `${first.uv}:${first.pv}`
  })
  assert.equal(new Set(summaries).size, scopes.length)
})

test('custom ranges are inclusive and match preset periods for identical dates', () => {
  for (const { product, subproductId } of scopes) {
    const month = productTraffic(product, state('月'), subproductId)
    assert.deepEqual(productTraffic(product, state('custom', month.from, month.to), subproductId), month)
    const day = productTraffic(product, state('custom', trafficCoverage.to, trafficCoverage.to), subproductId)
    assert.deepEqual(day, productTraffic(product, state('天'), subproductId))
    const historic = productTraffic(product, state('custom', month.from, month.selected[6].date), subproductId)
    assert.equal(historic.selected.length, 7)
    assert.equal(historic.selected[0].date, month.from)
    assert.equal(historic.selected[6].date, month.selected[6].date)
  }
})

test('stickiness uses average DAU and distinct rolling WAU/MAU, not selected-range UV', () => {
  for (const { product, subproductId } of scopes) {
    const month = productTraffic(product, state('月'), subproductId)
    const dau = sum(month.selected.map((day) => day.users.length)) / 30
    const wau = new Set(month.selected.slice(-7).flatMap((day) => day.users)).size
    assert.equal(month.averageDAU, +dau.toFixed(1))
    assert.equal(month.mau, month.uv)
    assert.equal(month.wau, wau)
    assert.equal(month.dauMau, +(dau / month.mau * 100).toFixed(1))
    assert.equal(month.wauMau, +(wau / month.mau * 100).toFixed(1))
    assert.ok(month.dauMau > 0 && month.dauMau <= 100)
    assert.ok(month.wauMau >= month.dauMau && month.wauMau <= 100)
    const day = productTraffic(product, state('天'), subproductId)
    assert.equal(day.dauMau, month.dauMau)
    assert.equal(day.wauMau, month.wauMau)
  }
})

for (const product of monitored.filter((item) => item.subproducts.length)) {
  test(`${product.name} aggregates all child scopes with cross-scope user de-duplication`, () => {
    for (const period of ['天', '周', '月']) {
      const traffic = productTraffic(product, state(period))
      const children = product.subproducts.map((subproduct) => productTraffic(product, state(period), subproduct.id))
      const union = (rows) => new Set(rows.flatMap((row) => row.users)).size
      assert.equal(traffic.uv, union(children.flatMap((child) => child.selected)))
      assert.equal(traffic.pv, sum(children.map((child) => child.pv)))
      assert.equal(traffic.visits, sum(children.map((child) => child.visits)))
      assert.ok(traffic.uv < sum(children.map((child) => child.uv)))
      const minutes = sum(children.flatMap((child) => child.selected.map((day) => day.minutes)))
      assert.equal(traffic.avgMinutes, +(minutes / traffic.visits).toFixed(1))
      for (let hour = 0; hour < 24; hour++) {
        assert.equal(traffic.hours[hour], sum(children.map((child) => child.hours[hour])))
      }
      for (const [index, day] of traffic.selected.entries()) {
        assert.equal(day.users.length, union(children.map((child) => child.selected[index])))
        assert.equal(day.pv, sum(children.map((child) => child.selected[index].pv)))
      }
    }
  })

  test(`${product.name} comparison rows exactly match independent child dashboards`, () => {
    const month = productTraffic(product, state('月'))
    const periods = [state('天'), state('周'), state('月'), state('custom', month.from, month.selected[9].date)]
    for (const period of periods) {
      const traffic = productTraffic(product, period)
      assert.equal(traffic.subproducts.length, product.subproducts.length)
      assert.ok(Math.abs(sum(traffic.subproducts.map((subproduct) => subproduct.share)) - 100) <= product.subproducts.length * 0.05 + 1e-8)
      for (const row of traffic.subproducts) {
        const child = productTraffic(product, period, row.id)
        for (const metric of ['uv', 'pv', 'visits', 'avgMinutes', 'dauMau', 'wauMau']) {
          assert.equal(row[metric], child[metric], `${row.name}: ${metric}`)
        }
        assert.equal(child.subproducts.length, 0)
        assert.ok(child.uv <= traffic.uv)
        assert.equal(row.share, +(child.pv / traffic.pv * 100).toFixed(1))
      }
    }
  })
}

test('invalid subproduct identifiers never silently return platform statistics', () => {
  assert.throws(() => productTraffic(findProduct('itest'), state('月'), 'unknown'), /Unknown subproduct/)
  assert.throws(() => productTraffic(findProduct('de-wbs'), state('月'), 'test-management'), /Unknown subproduct/)
  assert.throws(() => productTraffic(findProduct('product-space'), state('月'), 'test-management'), /Unknown subproduct/)
})

test('out-of-coverage ranges are explicit, empty ranges stay empty, and incomplete stickiness is withheld', () => {
  for (const { product, subproductId } of scopes) {
    const empty = productTraffic(product, state('custom', '2000-01-01', '2000-01-07'), subproductId)
    assert.equal(empty.selected.length, 0)
    assert.equal(empty.uv, 0)
    assert.equal(empty.pv, 0)
    assert.equal(empty.avgMinutes, 0)
    assert.equal(empty.dauMau, null)
    assert.equal(empty.wauMau, null)
    assert.equal(empty.partial, true)
    const partial = productTraffic(product, state('custom', '2000-01-01', trafficCoverage.from), subproductId)
    assert.equal(partial.selected.length, 1)
    assert.equal(partial.partial, true)
    assert.equal(partial.dauMau, null)
    assert.equal(partial.wauMau, null)
  }
})
