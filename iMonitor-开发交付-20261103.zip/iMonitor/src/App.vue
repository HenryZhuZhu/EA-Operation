<script setup lang="ts">
import { onMounted, ref, watch } from 'vue'
import { RouterView, useRoute } from 'vue-router'
import TopNav from '@/components/TopNav.vue'
import { periodState } from '@/stores/period'
import { loadLive } from '@/data/umami'

const route = useRoute()
const content = ref<HTMLElement | null>(null)

watch(() => route.fullPath, () => {
  content.value?.scrollTo({ top: 0, left: 0 })
}, { flush: 'post' })

// 接入真实数据：UMAMI.useMock=false 时拉取并覆盖演示数据
onMounted(() => loadLive(periodState.overview))
</script>

<template>
  <div class="app">
    <TopNav />
    <div class="content" ref="content">
      <!-- key 绑定路由，切换时重挂载以复现进场动画 -->
      <RouterView :key="route.fullPath" />
    </div>
  </div>
</template>
